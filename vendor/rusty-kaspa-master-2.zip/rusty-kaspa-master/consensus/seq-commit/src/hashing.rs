//! Hash functions for sequencing commitments.
//!
//! Commitment tree shape:
//!
//! ```text
//! SeqCommit(B)
//! └── H_seq
//!     ├── parent_seq_commit = SeqCommit(selected_parent(B))
//!     └── state_root
//!         └── H_seq
//!             ├── activity_root
//!             │   └── H_activity_root
//!             │       ├── inactivity_shortcut
//!             │       └── lanes_root
//!             │           └── SMT root over active lanes
//!             │
//!             └── payload_and_ctx_digest
//!                 └── H_seq
//!                     ├── context_hash
//!                     └── payload_root
//! ```
//!

use kaspa_hashes::{
    Hash, HasherBase, PayloadDigest, SeqCommitActiveLeaf, SeqCommitActivityLeaf, SeqCommitActivityRoot, SeqCommitLaneKey,
    SeqCommitLaneTip, SeqCommitMergesetContext, SeqCommitMerkleBranch, SeqCommitMinerPayloadLeaf,
};
use kaspa_merkle::{StreamingMerkleBuilder, calc_merkle_root_with_hasher};

use crate::types::{LaneId, LaneTipInput, MergesetContext, MinerPayloadLeafInput, SeqCommitInput, SeqState, SmtLeafInput};

/// Compute the SMT key for a lane: `H_lane_key(lane_id)`.
#[inline]
pub fn lane_key(lane_id: &LaneId) -> Hash {
    let mut hasher = SeqCommitLaneKey::new();
    hasher.update(lane_id);
    hasher.finalize()
}

/// Precomputed `lane_key(SUBNETWORK_ID_COINBASE)`.
pub const COINBASE_LANE_KEY: Hash = Hash::from_bytes([
    0x8a, 0xa7, 0x80, 0x27, 0xdb, 0x66, 0xa1, 0x6c, 0xb6, 0x96, 0x92, 0xee, 0x0a, 0xf5, 0xcb, 0x76, 0x73, 0x8e, 0xf8, 0x0a, 0xd1,
    0x4c, 0x9d, 0x13, 0x92, 0x0d, 0x7f, 0xa3, 0xcc, 0x40, 0xb9, 0xe4,
]);

/// Compute an activity leaf: `H_activity_leaf(tx_id || le_u16(version) || le_u32(merge_idx))`.
#[inline]
pub fn activity_leaf(tx_id: &Hash, version: u16, merge_idx: u32) -> Hash {
    let mut hasher = SeqCommitActivityLeaf::new();
    hasher.update(tx_id).update(version.to_le_bytes()).update(merge_idx.to_le_bytes());
    hasher.finalize()
}

/// Compute the activity digest for a lane's transactions in a mergeset block.
///
/// Merkle root over the activity leaves using `H_seq` (SeqCommitMerkleBranch).
/// Standard convention: a single-leaf tree returns the leaf itself.
#[inline]
pub fn activity_digest_lane(leaves: impl ExactSizeIterator<Item = Hash>) -> Hash {
    calc_merkle_root_with_hasher::<SeqCommitMerkleBranch>(leaves)
}

/// Streaming activity digest builder for no-heap environments (ZK guests).
///
/// Produces the same root as [`activity_digest_lane`] but processes leaves
/// one at a time without heap allocation.
pub type ActivityDigestBuilder = StreamingMerkleBuilder<SeqCommitMerkleBranch>;

/// Compute the next lane tip: `H_lane_tip(parent_ref || lane_key || activity_digest || context_hash)`.
#[inline]
pub fn lane_tip_next(input: &LaneTipInput) -> Hash {
    let mut hasher = SeqCommitLaneTip::new();
    hasher.update(input.parent_ref).update(input.lane_key).update(input.activity_digest).update(input.context_hash);
    hasher.finalize()
}

/// Compute the mergeset context hash:
/// `H_mergeset_context(le_u64(timestamp) || le_u64(daa_score) || le_u64(blue_score))`.
#[inline]
pub fn mergeset_context_hash(ctx: &MergesetContext) -> Hash {
    let mut hasher = SeqCommitMergesetContext::new();
    hasher.update(ctx.timestamp.to_le_bytes()).update(ctx.daa_score.to_le_bytes()).update(ctx.blue_score.to_le_bytes());
    hasher.finalize()
}

/// Compute the activity root: `H_activity_root(inactivity_shortcut, lanes_root)`.
#[inline]
pub fn activity_root_hash(inactivity_shortcut: &Hash, lanes_root: &Hash) -> Hash {
    let mut hasher = SeqCommitActivityRoot::new();
    hasher.update(inactivity_shortcut).update(lanes_root);
    hasher.finalize()
}

/// Compute the miner payload hash: `H_payload_digest(payload_bytes)`.
#[inline]
pub fn miner_payload_hash(payload: &[u8]) -> Hash {
    let mut hasher = PayloadDigest::new();
    hasher.update(payload);
    hasher.finalize()
}

/// Write blue_work into `hasher` with the same encoding as
/// `kaspa_consensus_core::hashing::HasherExtensions::write_blue_work`:
/// strip leading zeros from the big-endian bytes, then write
/// `le_u64(len) || stripped_bytes`.
///
/// Inlined here (rather than reusing the trait method) because
/// `kaspa-consensus-core` pulls in a std-only dependency tree and
/// `kaspa-seq-commit` must stay `no_std`-compatible. The
/// `miner_payload_leaf_matches_consensus_core_write_blue_work` test locks
/// the two encodings together.
#[inline]
fn write_blue_work_be<H: HasherBase>(hasher: &mut H, blue_work_be_bytes: &[u8]) {
    let start = blue_work_be_bytes.iter().copied().position(|byte| byte != 0).unwrap_or(blue_work_be_bytes.len());
    let stripped = &blue_work_be_bytes[start..];
    hasher.update((stripped.len() as u64).to_le_bytes()).update(stripped);
}

/// Compute a miner payload leaf: `H_miner_payload_leaf(block_hash || blue_work_bytes || H_miner_payload(payload))`.
#[inline]
pub fn miner_payload_leaf(input: MinerPayloadLeafInput<'_>) -> Hash {
    let payload_h = miner_payload_hash(input.payload);
    let mut hasher = SeqCommitMinerPayloadLeaf::new();
    hasher.update(input.block_hash);
    write_blue_work_be(&mut hasher, input.blue_work_be_bytes);
    hasher.update(payload_h);
    hasher.finalize()
}

/// Compute the miner payload root from payload leaves.
///
/// Merkle root using `H_seq` (SeqCommitMerkleBranch).
/// Standard convention: a single-leaf tree returns the leaf itself.
#[inline]
pub fn miner_payload_root(leaves: impl ExactSizeIterator<Item = Hash>) -> Hash {
    calc_merkle_root_with_hasher::<SeqCommitMerkleBranch>(leaves)
}

/// Compute the SMT leaf hash for an active lane:
/// `H_active_leaf(lane_tip_hash(32) || le_u64(blue_score))`.
#[inline]
pub fn smt_leaf_hash(input: &SmtLeafInput<'_>) -> Hash {
    let mut hasher = SeqCommitActiveLeaf::new();
    hasher.update(input.lane_tip).update(input.blue_score.to_le_bytes());
    hasher.finalize()
}

/// Compute the payload digest: `H_seq(context_hash, payload_root)`.
///
/// Combines the mergeset context and miner payload into a single hash
/// that can be stored and reused without access to block transactions.
#[inline]
pub fn payload_and_context_digest(context_hash: &Hash, payload_root: &Hash) -> Hash {
    let mut hasher = SeqCommitMerkleBranch::new();
    hasher.update(context_hash).update(payload_root);
    hasher.finalize()
}

/// Compute the seq-state root: `H_seq(activity_root, payload_and_ctx_digest)`.
#[inline]
pub fn seq_state_root(state: &SeqState<'_>) -> Hash {
    let mut hasher = SeqCommitMerkleBranch::new();
    hasher.update(state.activity_root).update(state.payload_and_ctx_digest);
    hasher.finalize()
}

/// Compute the final sequencing commitment: `H_seq(parent_seq_commit, state_root)`.
#[inline]
pub fn seq_commit(input: &SeqCommitInput<'_>) -> Hash {
    let mut hasher = SeqCommitMerkleBranch::new();
    hasher.update(input.parent_seq_commit).update(input.state_root);
    hasher.finalize()
}

#[cfg(test)]
mod tests {
    use super::*;
    use kaspa_consensus_core::{BlueWorkType, subnets::SUBNETWORK_ID_COINBASE};
    use kaspa_hashes::ZERO_HASH;

    fn h(b: u8) -> Hash {
        let mut bytes = [0u8; 32];
        bytes[0] = b;
        Hash::from_bytes(bytes)
    }

    #[test]
    fn test_lane_key_golden() {
        let expected = Hash::from_bytes([
            0x57, 0xc7, 0xe5, 0x2c, 0x76, 0x02, 0xb3, 0x66, 0xb3, 0xf6, 0x62, 0xad, 0xdc, 0x36, 0x12, 0x96, 0x77, 0xd4, 0x84, 0x4b,
            0x84, 0x04, 0x68, 0xcc, 0xaa, 0x96, 0x31, 0x10, 0x6b, 0xea, 0x88, 0x97,
        ]);
        assert_eq!(lane_key(&[0x42; 20]), expected);
    }

    #[test]
    fn test_lane_key_different_ids() {
        assert_ne!(lane_key(&[0x01; 20]), lane_key(&[0x02; 20]));
    }

    #[test]
    fn test_coinbase_lane_key_constant() {
        assert_eq!(COINBASE_LANE_KEY, lane_key(&SUBNETWORK_ID_COINBASE.into_bytes()));
    }

    #[test]
    fn test_activity_leaf_golden() {
        let expected = Hash::from_bytes([
            0x4e, 0xf4, 0x3f, 0x31, 0x6e, 0xcf, 0x61, 0x6c, 0x69, 0x34, 0xb5, 0x66, 0xae, 0x41, 0x05, 0x5e, 0x97, 0x12, 0xf1, 0x08,
            0x9b, 0x91, 0x4f, 0x33, 0x18, 0x6c, 0xdc, 0x9d, 0x55, 0x19, 0x11, 0x21,
        ]);
        assert_eq!(activity_leaf(&h(1), 0, 0), expected);
    }

    #[test]
    fn test_activity_leaf_different_indices() {
        assert_ne!(activity_leaf(&h(1), 0, 0), activity_leaf(&h(1), 0, 1));
    }

    #[test]
    fn test_activity_leaf_different_tx_ids() {
        assert_ne!(activity_leaf(&h(1), 0, 0), activity_leaf(&h(2), 0, 0));
    }

    #[test]
    fn test_activity_leaf_different_versions() {
        assert_ne!(activity_leaf(&h(1), 0, 0), activity_leaf(&h(1), 1, 0));
    }

    #[test]
    fn test_activity_digest_lane_empty() {
        assert_eq!(activity_digest_lane(core::iter::empty()), ZERO_HASH);
    }

    #[test]
    fn test_activity_digest_lane_single() {
        let leaf = h(1);
        let root = activity_digest_lane(core::iter::once(leaf));
        // Standard Merkle convention: a one-leaf tree is the leaf itself.
        assert_eq!(root, leaf);
    }

    #[test]
    fn test_activity_digest_lane_two() {
        let a = h(1);
        let b = h(2);
        let root = activity_digest_lane([a, b].into_iter());
        let expected = {
            let mut hasher = SeqCommitMerkleBranch::new();
            hasher.update(a).update(b);
            hasher.finalize()
        };
        assert_eq!(root, expected);
    }

    #[test]
    fn test_lane_tip_next_golden() {
        let expected = Hash::from_bytes([
            0x38, 0x79, 0x35, 0x76, 0xd5, 0x45, 0xd2, 0x95, 0x2d, 0xf3, 0x1b, 0x7c, 0x57, 0x19, 0x3a, 0x49, 0x2f, 0x9c, 0x5b, 0x8c,
            0x09, 0xdd, 0xae, 0xb2, 0x27, 0x4e, 0x4e, 0x23, 0xed, 0xbc, 0x3f, 0x43,
        ]);
        let lk = lane_key(&[0x55; 20]);
        let input = LaneTipInput { parent_ref: &h(1), lane_key: &lk, activity_digest: &h(2), context_hash: &h(3) };
        assert_eq!(lane_tip_next(&input), expected);
    }

    #[test]
    fn test_lane_tip_next_different_parents() {
        let lk = lane_key(&[0x55; 20]);
        let a = LaneTipInput { parent_ref: &h(1), lane_key: &lk, activity_digest: &h(2), context_hash: &h(3) };
        let b = LaneTipInput { parent_ref: &h(10), lane_key: &lk, activity_digest: &h(2), context_hash: &h(3) };
        assert_ne!(lane_tip_next(&a), lane_tip_next(&b));
    }

    #[test]
    fn test_mergeset_context_hash_determinism() {
        let ctx = MergesetContext { timestamp: 1000, daa_score: 500, blue_score: 250 };
        assert_eq!(mergeset_context_hash(&ctx), mergeset_context_hash(&ctx));
    }

    #[test]
    fn test_mergeset_context_hash_different_inputs() {
        let a = MergesetContext { timestamp: 1000, daa_score: 500, blue_score: 250 };
        let b = MergesetContext { timestamp: 1001, daa_score: 500, blue_score: 250 };
        let c = MergesetContext { timestamp: 1000, daa_score: 501, blue_score: 250 };
        let d = MergesetContext { timestamp: 1000, daa_score: 500, blue_score: 251 };
        let ha = mergeset_context_hash(&a);
        assert_ne!(ha, mergeset_context_hash(&b));
        assert_ne!(ha, mergeset_context_hash(&c));
        assert_ne!(ha, mergeset_context_hash(&d));
    }

    #[test]
    fn test_activity_root_hash_golden() {
        let result = activity_root_hash(&h(7), &h(9));
        assert_eq!(result, activity_root_hash(&h(7), &h(9)));
        assert_ne!(result, ZERO_HASH);
    }

    #[test]
    fn test_activity_root_hash_different_inputs() {
        let base = activity_root_hash(&h(7), &h(9));
        assert_ne!(base, activity_root_hash(&h(8), &h(9)));
        assert_ne!(base, activity_root_hash(&h(7), &h(10)));
        // Order matters (domain-separated, but sanity-check).
        assert_ne!(base, activity_root_hash(&h(9), &h(7)));
    }

    /// The activity-root domain separates `(inactivity_shortcut, lanes_root)` from
    /// the raw active-lanes SMT root.
    #[test]
    fn activity_root_identity_vs_wrap_diverges() {
        let lanes_root = h(42);
        let shortcut = ZERO_HASH;
        assert_ne!(lanes_root, activity_root_hash(&shortcut, &lanes_root));
    }

    #[test]
    fn test_miner_payload_hash_golden() {
        let expected = Hash::from_bytes([
            0xc0, 0xf2, 0x0a, 0x17, 0x77, 0xe1, 0x75, 0xc5, 0x0a, 0x6b, 0x97, 0xaf, 0xba, 0xc5, 0x7a, 0xae, 0x05, 0x5e, 0xba, 0xb3,
            0xdd, 0x77, 0x74, 0xe5, 0x9a, 0xeb, 0x4c, 0x77, 0x6c, 0x2a, 0x7d, 0x3a,
        ]);
        assert_eq!(miner_payload_hash(b"hello miner"), expected);
    }

    #[test]
    fn test_miner_payload_hash_different_payloads() {
        assert_ne!(miner_payload_hash(b"abc"), miner_payload_hash(b"def"));
    }

    #[test]
    fn test_miner_payload_leaf_golden() {
        let expected = Hash::from_bytes([
            0xec, 0x32, 0x62, 0x9c, 0xbc, 0xf2, 0xf6, 0xcf, 0xee, 0xbc, 0x34, 0xca, 0x13, 0x74, 0xfe, 0x6f, 0x36, 0x57, 0x93, 0xb8,
            0x02, 0x3e, 0xad, 0x3b, 0xfe, 0x5e, 0xda, 0xe0, 0xd8, 0x15, 0xd8, 0xba,
        ]);
        let bw = BlueWorkType::from_u64(0x0123);
        let input = MinerPayloadLeafInput { block_hash: &h(1), blue_work_be_bytes: &bw.to_be_bytes(), payload: b"coinbase data" };
        assert_eq!(miner_payload_leaf(input), expected);
    }

    /// Preimage parity: captures the raw bytes fed into a hasher by
    /// `write_blue_work_be` and `HasherExtensions::write_blue_work` and
    /// compares them directly. If either encoding ever drifts, this test
    /// breaks before any hash collision could mask the change.
    #[test]
    fn write_blue_work_be_preimage_matches_consensus_core() {
        use alloc::vec::Vec;
        use kaspa_consensus_core::hashing::HasherExtensions;

        #[derive(Default)]
        struct ByteBuffer(Vec<u8>);

        impl HasherBase for ByteBuffer {
            fn update<A: AsRef<[u8]>>(&mut self, data: A) -> &mut Self {
                self.0.extend_from_slice(data.as_ref());
                self
            }
        }

        // Values spanning every width: zero (empty stripped bytes), 1-byte,
        // 2-byte, 8-byte (u64::MAX), 16-byte (u128::MAX), 17-byte (first bit
        // past the u128 boundary), and the full 24-byte width.
        let over_u128: BlueWorkType = {
            let mut bytes = [0u8; 24];
            bytes[7] = 0x01; // first byte past the low 16 bytes
            BlueWorkType::from_be_bytes(bytes)
        };
        let all_ones = BlueWorkType::from_be_bytes([0xFF; 24]);
        for bw in [
            BlueWorkType::ZERO,
            BlueWorkType::from_u64(1),
            BlueWorkType::from_u64(0x0123),
            BlueWorkType::from_u64(u64::MAX),
            BlueWorkType::from_u128(u128::MAX),
            over_u128,
            all_ones,
        ] {
            let mut ours = ByteBuffer::default();
            write_blue_work_be(&mut ours, &bw.to_be_bytes());

            let mut theirs = ByteBuffer::default();
            theirs.write_blue_work(bw);

            assert_eq!(ours.0, theirs.0, "preimage diverged for {bw:?}");
        }
    }

    #[test]
    fn test_miner_payload_leaf_includes_all_inputs() {
        let bw1 = BlueWorkType::from_u64(1);
        let bw2 = BlueWorkType::from_u64(2);
        let base =
            miner_payload_leaf(MinerPayloadLeafInput { block_hash: &h(1), blue_work_be_bytes: &bw1.to_be_bytes(), payload: b"data" });
        assert_ne!(
            base,
            miner_payload_leaf(MinerPayloadLeafInput { block_hash: &h(2), blue_work_be_bytes: &bw1.to_be_bytes(), payload: b"data" })
        );
        assert_ne!(
            base,
            miner_payload_leaf(MinerPayloadLeafInput { block_hash: &h(1), blue_work_be_bytes: &bw2.to_be_bytes(), payload: b"data" })
        );
        assert_ne!(
            base,
            miner_payload_leaf(MinerPayloadLeafInput { block_hash: &h(1), blue_work_be_bytes: &bw1.to_be_bytes(), payload: b"other" })
        );
    }

    #[test]
    fn test_miner_payload_root_empty() {
        assert_eq!(miner_payload_root(core::iter::empty()), ZERO_HASH);
    }

    #[test]
    fn test_miner_payload_root_single() {
        let leaf = h(1);
        let root = miner_payload_root(core::iter::once(leaf));
        // Standard Merkle convention: a one-leaf tree is the leaf itself.
        assert_eq!(root, leaf);
    }

    #[test]
    fn test_smt_leaf_hash_golden() {
        let result = smt_leaf_hash(&SmtLeafInput { lane_tip: &h(2), blue_score: 100 });
        // Verify determinism
        let result2 = smt_leaf_hash(&SmtLeafInput { lane_tip: &h(2), blue_score: 100 });
        assert_eq!(result, result2);
        assert_ne!(result, ZERO_HASH);
    }

    #[test]
    fn test_smt_leaf_hash_different_inputs() {
        let base = smt_leaf_hash(&SmtLeafInput { lane_tip: &h(2), blue_score: 100 });
        assert_ne!(base, smt_leaf_hash(&SmtLeafInput { lane_tip: &h(20), blue_score: 100 }));
        assert_ne!(base, smt_leaf_hash(&SmtLeafInput { lane_tip: &h(2), blue_score: 200 }));
    }

    #[test]
    fn test_seq_state_root_golden() {
        let expected = Hash::from_bytes([
            0x20, 0xd1, 0x35, 0x77, 0x5a, 0x39, 0xbe, 0x49, 0xfe, 0x34, 0x70, 0x9a, 0x55, 0xb0, 0xc7, 0xeb, 0x39, 0x05, 0xf5, 0xc9,
            0xbe, 0x27, 0xd1, 0xdc, 0x11, 0x50, 0xb8, 0xaf, 0x23, 0x9e, 0x56, 0xd9,
        ]);
        let (ar, ch, pr) = (h(1), h(2), h(3));
        let pd = payload_and_context_digest(&ch, &pr);
        assert_eq!(seq_state_root(&SeqState { activity_root: &ar, payload_and_ctx_digest: &pd }), expected);
    }

    #[test]
    fn test_seq_state_root_structure() {
        let (ar, ch, pr) = (h(1), h(2), h(3));
        let pd = payload_and_context_digest(&ch, &pr);
        let state = SeqState { activity_root: &ar, payload_and_ctx_digest: &pd };
        let expected = {
            let mut hasher = SeqCommitMerkleBranch::new();
            hasher.update(state.activity_root).update(state.payload_and_ctx_digest);
            hasher.finalize()
        };
        assert_eq!(seq_state_root(&state), expected);
    }

    #[test]
    fn test_seq_commit_golden() {
        let expected = Hash::from_bytes([
            0x7e, 0x9e, 0x79, 0x76, 0x99, 0x56, 0x7a, 0xb5, 0xcb, 0xcc, 0xc5, 0xa7, 0xe7, 0x20, 0xc6, 0x27, 0x09, 0x9d, 0xf8, 0x31,
            0x86, 0xe1, 0xd1, 0xe1, 0xca, 0xe8, 0x8d, 0x86, 0x46, 0xc0, 0x63, 0xdf,
        ]);
        let (p, s) = (h(1), h(2));
        assert_eq!(seq_commit(&SeqCommitInput { parent_seq_commit: &p, state_root: &s }), expected);
    }

    #[test]
    fn test_seq_commit_structure() {
        let (p, s) = (h(1), h(2));
        let input = SeqCommitInput { parent_seq_commit: &p, state_root: &s };
        let expected = {
            let mut hasher = SeqCommitMerkleBranch::new();
            hasher.update(input.parent_seq_commit).update(input.state_root);
            hasher.finalize()
        };
        assert_eq!(seq_commit(&input), expected);
    }

    #[test]
    fn test_seq_commit_different_inputs() {
        let (h1, h2, h3) = (h(1), h(2), h(3));
        let a = seq_commit(&SeqCommitInput { parent_seq_commit: &h1, state_root: &h2 });
        let b = seq_commit(&SeqCommitInput { parent_seq_commit: &h2, state_root: &h1 });
        let c = seq_commit(&SeqCommitInput { parent_seq_commit: &h1, state_root: &h3 });
        assert_ne!(a, b);
        assert_ne!(a, c);
    }

    #[test]
    fn test_end_to_end_commitment() {
        let lane_id: LaneId = [0x01; 20];
        let tx_id = h(42);
        let parent_commit = h(99);

        let al = activity_leaf(&tx_id, 0, 0);
        let ad = activity_digest_lane(core::iter::once(al));
        let ctx = mergeset_context_hash(&MergesetContext { timestamp: 1_700_000_000, daa_score: 100_000, blue_score: 50_000 });

        let lk = lane_key(&lane_id);
        let tip = lane_tip_next(&LaneTipInput { parent_ref: &parent_commit, lane_key: &lk, activity_digest: &ad, context_hash: &ctx });
        let smt_leaf = smt_leaf_hash(&SmtLeafInput { lane_tip: &tip, blue_score: 50_000 });

        let h1 = h(1);
        let bw = BlueWorkType::from_u64(0x0100);
        let mpl =
            miner_payload_leaf(MinerPayloadLeafInput { block_hash: &h1, blue_work_be_bytes: &bw.to_be_bytes(), payload: b"coinbase" });
        let mpr = miner_payload_root(core::iter::once(mpl));

        let pd = payload_and_context_digest(&ctx, &mpr);
        let activity_root = activity_root_hash(&ZERO_HASH, &smt_leaf);
        let state_root = seq_state_root(&SeqState { activity_root: &activity_root, payload_and_ctx_digest: &pd });
        let commitment = seq_commit(&SeqCommitInput { parent_seq_commit: &parent_commit, state_root: &state_root });
        assert_ne!(commitment, parent_commit);
    }
}
