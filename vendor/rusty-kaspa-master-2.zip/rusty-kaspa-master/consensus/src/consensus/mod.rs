pub mod cache_policy_builder;
pub mod ctl;
pub mod factory;
pub mod services;
pub mod storage;
pub mod test_consensus;

#[cfg(feature = "devnet-prealloc")]
mod utxo_set_override;

use crate::{
    config::Config,
    errors::{BlockProcessResult, RuleError},
    model::{
        services::reachability::ReachabilityService,
        stores::{
            DB,
            acceptance_data::AcceptanceDataStoreReader,
            block_transactions::BlockTransactionsStoreReader,
            ghostdag::{GhostdagData, GhostdagStoreReader},
            headers::{CompactHeaderData, HeaderStoreReader},
            headers_selected_tip::HeadersSelectedTipStoreReader,
            past_pruning_points::PastPruningPointsStoreReader,
            pruning::PruningStoreReader,
            relations::RelationsStoreReader,
            selected_chain::SelectedChainStore,
            statuses::StatusesStoreReader,
            tips::{TipsStore, TipsStoreReader},
            utxo_set::{UtxoSetStore, UtxoSetStoreReader},
            virtual_state::VirtualState,
        },
    },
    pipeline::{
        ProcessingCounters,
        body_processor::BlockBodyProcessor,
        deps_manager::{BlockProcessingMessage, BlockResultSender, BlockTask, VirtualStateProcessingMessage},
        header_processor::HeaderProcessor,
        pruning_processor::processor::{PruningProcessingMessage, PruningProcessor},
        virtual_processor::{VirtualStateProcessor, errors::PruningImportResult},
    },
    processes::{
        ghostdag::ordering::SortableBlock,
        window::{WindowManager, WindowType},
    },
};
use kaspa_consensus_core::{
    BlockHashSet, BlueWorkType, ChainPath, HashMapCustomHasher,
    acceptance_data::{AcceptanceData, MergedBlockContext, MergesetBlockAcceptanceData},
    api::{
        BlockValidationFutures, ConsensusApi, ConsensusStats, ImportLaneBatchIterator, SeqCommitLaneProof,
        args::{TransactionValidationArgs, TransactionValidationBatchArgs},
        stats::BlockCount,
    },
    block::{Block, BlockTemplate, TemplateBuildMode, TemplateTransactionSelector, VirtualStateApproxId},
    blockhash::BlockHashExtensions,
    blockstatus::BlockStatus,
    coinbase::MinerData,
    daa_score_timestamp::DaaScoreTimestamp,
    errors::{
        coinbase::CoinbaseResult,
        consensus::{ConsensusError, ConsensusResult},
        difficulty::DifficultyError,
        pruning::PruningImportError,
        tx::{TxResult, TxRuleError},
    },
    header::Header,
    mass::{ContextualMasses, NonContextualMasses},
    merkle::calc_hash_merkle_root,
    mining_rules::MiningRules,
    muhash::MuHashExtensions,
    network::NetworkType,
    pruning::{PruningPointProof, PruningPointTrustedData, PruningPointsList, PruningProofMetadata},
    trusted::{ExternalGhostdagData, TrustedBlock},
    tx::{
        ComputeCommit, MutableTransaction, Transaction, TransactionId, TransactionIndexType, TransactionOutpoint,
        TransactionQueryResult, TransactionType, UtxoEntry,
    },
};
use kaspa_consensus_notify::root::ConsensusNotificationRoot;

use crossbeam_channel::{
    Receiver as CrossbeamReceiver, Sender as CrossbeamSender, bounded as bounded_crossbeam, unbounded as unbounded_crossbeam,
};
use itertools::Itertools;
use kaspa_consensusmanager::{SessionLock, SessionReadGuard};

use kaspa_core::info;
#[cfg(feature = "test-smt-pruning-diagnostics")]
use kaspa_database::prelude::StoreResult;
use kaspa_database::prelude::StoreResultExt;
use kaspa_hashes::Hash;
use kaspa_muhash::MuHash;
use kaspa_smt_store::processor::SmtReadBounds;
#[cfg(feature = "test-smt-pruning-diagnostics")]
use kaspa_smt_store::processor::StaleSmtEntriesCount;
use kaspa_txscript::caches::TxScriptCacheCounters;
use kaspa_utils::arc::ArcExtensions;
use rayon::iter::{IntoParallelRefIterator, ParallelIterator};
use rocksdb::WriteBatch;

use self::{services::ConsensusServices, storage::ConsensusStorage};
use kaspa_consensus_core::api::SeqCommitLaneEntry;
use std::{
    cmp,
    cmp::Reverse,
    collections::{BinaryHeap, HashSet, VecDeque},
    future::Future,
    iter::once,
    ops::Deref,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    thread::{self, JoinHandle},
};
use tokio::sync::oneshot;

use crate::model::stores::selected_chain::SelectedChainStoreReader;

pub struct Consensus {
    // DB
    db: Arc<DB>,

    // Channels
    block_sender: CrossbeamSender<BlockProcessingMessage>,

    // Processors
    pub(super) header_processor: Arc<HeaderProcessor>,
    pub(super) body_processor: Arc<BlockBodyProcessor>,
    pub(super) virtual_processor: Arc<VirtualStateProcessor>,
    pub(super) pruning_processor: Arc<PruningProcessor>,

    // Storage
    pub(super) storage: Arc<ConsensusStorage>,

    // Services and managers
    pub(super) services: Arc<ConsensusServices>,

    // Pruning lock
    pruning_lock: SessionLock,

    // Notification management
    notification_root: Arc<ConsensusNotificationRoot>,

    // Counters
    counters: Arc<ProcessingCounters>,

    // Config
    config: Arc<Config>,

    // Other
    creation_timestamp: u64,

    // Signals
    is_consensus_exiting: Arc<AtomicBool>,
}

impl Deref for Consensus {
    type Target = ConsensusStorage;

    fn deref(&self) -> &Self::Target {
        &self.storage
    }
}

impl Consensus {
    pub fn new(
        db: Arc<DB>,
        config: Arc<Config>,
        pruning_lock: SessionLock,
        notification_root: Arc<ConsensusNotificationRoot>,
        counters: Arc<ProcessingCounters>,
        tx_script_cache_counters: Arc<TxScriptCacheCounters>,
        creation_timestamp: u64,
        mining_rules: Arc<MiningRules>,
    ) -> Self {
        let params = &config.params;
        let perf_params = &config.perf;
        let is_consensus_exiting: Arc<AtomicBool> = Arc::new(AtomicBool::new(false));

        //
        // Storage layer
        //

        let storage = ConsensusStorage::new(db.clone(), config.clone());

        //
        // Services and managers
        //

        let services = ConsensusServices::new(
            db.clone(),
            storage.clone(),
            config.clone(),
            tx_script_cache_counters,
            is_consensus_exiting.clone(),
        );

        //
        // Processor channels
        //

        let (sender, receiver): (CrossbeamSender<BlockProcessingMessage>, CrossbeamReceiver<BlockProcessingMessage>) =
            unbounded_crossbeam();
        let (body_sender, body_receiver): (CrossbeamSender<BlockProcessingMessage>, CrossbeamReceiver<BlockProcessingMessage>) =
            unbounded_crossbeam();
        let (virtual_sender, virtual_receiver): (
            CrossbeamSender<VirtualStateProcessingMessage>,
            CrossbeamReceiver<VirtualStateProcessingMessage>,
        ) = unbounded_crossbeam();
        let (pruning_sender, pruning_receiver): (
            CrossbeamSender<PruningProcessingMessage>,
            CrossbeamReceiver<PruningProcessingMessage>,
        ) = bounded_crossbeam(2);

        //
        // Thread-pools
        //

        // Pool for header and body processors
        let block_processors_pool = Arc::new(
            rayon::ThreadPoolBuilder::new()
                .num_threads(perf_params.block_processors_num_threads)
                .thread_name(|i| format!("block-pool-{i}"))
                .build()
                .unwrap(),
        );
        // We need a dedicated thread-pool for the virtual processor to avoid possible deadlocks probably caused by the
        // combined usage of `par_iter` (in virtual processor) and `rayon::spawn` (in header/body processors).
        // See for instance https://github.com/rayon-rs/rayon/issues/690
        let virtual_pool = Arc::new(
            rayon::ThreadPoolBuilder::new()
                .num_threads(perf_params.virtual_processor_num_threads)
                .thread_name(|i| format!("virtual-pool-{i}"))
                .build()
                .unwrap(),
        );

        //
        // Pipeline processors
        //

        let header_processor = Arc::new(HeaderProcessor::new(
            receiver,
            body_sender,
            block_processors_pool.clone(),
            params,
            db.clone(),
            &storage,
            &services,
            pruning_lock.clone(),
            counters.clone(),
        ));

        let body_processor = Arc::new(BlockBodyProcessor::new(
            body_receiver,
            virtual_sender,
            block_processors_pool,
            params,
            db.clone(),
            &storage,
            &services,
            pruning_lock.clone(),
            notification_root.clone(),
            counters.clone(),
        ));

        let virtual_processor = Arc::new(VirtualStateProcessor::new(
            virtual_receiver,
            pruning_sender,
            pruning_receiver.clone(),
            virtual_pool,
            params,
            db.clone(),
            &storage,
            &services,
            pruning_lock.clone(),
            notification_root.clone(),
            counters.clone(),
            mining_rules,
        ));

        let pruning_processor = Arc::new(PruningProcessor::new(
            pruning_receiver,
            db.clone(),
            &storage,
            &services,
            pruning_lock.clone(),
            config.clone(),
            is_consensus_exiting.clone(),
        ));

        // Ensure the relations stores are initialized
        header_processor.init();
        // Ensure that some pruning point is registered
        virtual_processor.init();

        // Ensure that genesis was processed
        if config.process_genesis {
            header_processor.process_genesis();
            body_processor.process_genesis();
            virtual_processor.process_genesis();
        }

        let this = Self {
            db,
            block_sender: sender,
            header_processor,
            body_processor,
            virtual_processor,
            pruning_processor,
            storage,
            services,
            pruning_lock,
            notification_root,
            counters,
            config,
            creation_timestamp,
            is_consensus_exiting,
        };

        // Run database upgrades if any
        this.run_database_upgrades();

        this
    }

    /// A procedure for calling database upgrades which are self-contained (i.e., do not require knowing the DB version)
    fn run_database_upgrades(&self) {
        // Upgrade to initialize the new retention root field correctly
        self.retention_root_database_upgrade();
        self.consensus_transitional_flags_upgrade();
    }

    fn retention_root_database_upgrade(&self) {
        let mut pruning_point_store = self.pruning_point_store.write();
        if pruning_point_store.retention_period_root().optional().unwrap().is_none() {
            let mut batch = rocksdb::WriteBatch::default();
            if self.config.is_archival {
                // The retention checkpoint is what was previously known as history root
                let retention_checkpoint = pruning_point_store.retention_checkpoint().unwrap();
                pruning_point_store.set_retention_period_root(&mut batch, retention_checkpoint).unwrap();
            } else {
                // For non-archival nodes the retention root was the pruning point
                let pruning_point = pruning_point_store.pruning_point().unwrap();
                pruning_point_store.set_retention_period_root(&mut batch, pruning_point).unwrap();
            }
            self.db.write(batch).unwrap();
        }
    }

    fn consensus_transitional_flags_upgrade(&self) {
        // Write the defaults to the internal storage so they will remain in cache
        // *For a new staging consensus these flags will be updated again explicitly*
        let mut batch = rocksdb::WriteBatch::default();
        let mut pruning_meta_write = self.storage.pruning_meta_stores.write();
        if pruning_meta_write.is_anticone_fully_synced() {
            pruning_meta_write.set_body_missing_anticone(&mut batch, vec![]).unwrap();
        }
        if pruning_meta_write.pruning_utxoset_stable_flag() {
            pruning_meta_write.set_pruning_utxoset_stable_flag(&mut batch, true).unwrap();
        }
        if pruning_meta_write.pruning_smt_stable_flag() {
            pruning_meta_write.set_pruning_smt_stable_flag(&mut batch, true).unwrap();
        }
        self.db.write(batch).unwrap();
    }

    pub fn run_processors(&self) -> Vec<JoinHandle<()>> {
        // Spawn the asynchronous processors.
        let header_processor = self.header_processor.clone();
        let body_processor = self.body_processor.clone();
        let virtual_processor = self.virtual_processor.clone();
        let pruning_processor = self.pruning_processor.clone();

        vec![
            thread::Builder::new().name("header-processor".to_string()).spawn(move || header_processor.worker()).unwrap(),
            thread::Builder::new().name("body-processor".to_string()).spawn(move || body_processor.worker()).unwrap(),
            thread::Builder::new().name("virtual-processor".to_string()).spawn(move || virtual_processor.worker()).unwrap(),
            thread::Builder::new().name("pruning-processor".to_string()).spawn(move || pruning_processor.worker()).unwrap(),
        ]
    }

    /// Acquires a consensus session, blocking data-pruning from occurring until released
    pub fn acquire_session(&self) -> SessionReadGuard<'_> {
        self.pruning_lock.blocking_read()
    }

    fn validate_and_insert_block_impl(
        &self,
        task: BlockTask,
    ) -> (
        impl Future<Output = BlockProcessResult<BlockStatus>> + 'static,
        impl Future<Output = BlockProcessResult<BlockStatus>> + 'static,
    ) {
        let (btx, brx): (BlockResultSender, _) = oneshot::channel();
        let (vtx, vrx): (BlockResultSender, _) = oneshot::channel();
        self.block_sender.send(BlockProcessingMessage::Process(task, btx, vtx)).unwrap();
        self.counters.blocks_submitted.fetch_add(1, Ordering::Relaxed);
        (async { brx.await.unwrap() }, async { vrx.await.unwrap() })
    }

    pub fn body_tips(&self) -> BlockHashSet {
        self.body_tips_store.read().get().unwrap().read().clone()
    }

    pub fn block_status(&self, hash: Hash) -> BlockStatus {
        self.statuses_store.read().get(hash).unwrap()
    }

    pub fn session_lock(&self) -> SessionLock {
        self.pruning_lock.clone()
    }

    pub fn notification_root(&self) -> Arc<ConsensusNotificationRoot> {
        self.notification_root.clone()
    }

    pub fn processing_counters(&self) -> &Arc<ProcessingCounters> {
        &self.counters
    }

    pub fn signal_exit(&self) {
        self.is_consensus_exiting.store(true, Ordering::Relaxed);
        self.block_sender.send(BlockProcessingMessage::Exit).unwrap();
    }

    pub fn shutdown(&self, wait_handles: Vec<JoinHandle<()>>) {
        self.signal_exit();
        // Wait for async consensus processors to exit
        for handle in wait_handles {
            handle.join().unwrap();
        }
    }

    /// Validates that a valid block *header* exists for `hash`
    fn validate_block_exists(&self, hash: Hash) -> Result<(), ConsensusError> {
        if match self.statuses_store.read().get(hash).optional().unwrap() {
            Some(status) => status.is_valid(),
            None => false,
        } {
            Ok(())
        } else {
            Err(ConsensusError::HeaderNotFound(hash))
        }
    }

    fn estimate_network_hashes_per_second_impl(&self, ghostdag_data: &GhostdagData, window_size: usize) -> ConsensusResult<u64> {
        let window = match self.services.window_manager.block_window(ghostdag_data, WindowType::VaryingWindow(window_size)) {
            Ok(w) => w,
            Err(RuleError::InsufficientDaaWindowSize(s)) => return Err(DifficultyError::InsufficientWindowData(s).into()),
            Err(e) => panic!("unexpected error: {e}"),
        };
        Ok(self.services.window_manager.estimate_network_hashes_per_second(window)?)
    }

    fn pruning_point_compact_headers(&self) -> Vec<(Hash, CompactHeaderData)> {
        // PRUNE SAFETY: index is monotonic and past pruning point headers are expected permanently
        let (pruning_point, pruning_index) = self.pruning_point_store.read().pruning_point_and_index().unwrap();
        (0..pruning_index)
            .map(|index| self.past_pruning_points_store.get(index).unwrap())
            .chain(once(pruning_point))
            .map(|hash| (hash, self.headers_store.get_compact_header_data(hash).unwrap()))
            .collect_vec()
    }

    /// See: intrusive_pruning_point_update implementation below for details
    pub fn intrusive_pruning_point_store_writes(
        &self,
        new_pruning_point: Hash,
        syncer_sink: Hash,
        pruning_points_to_add: VecDeque<Hash>,
    ) -> ConsensusResult<()> {
        let mut batch = WriteBatch::default();
        let mut pruning_point_write = self.pruning_point_store.write();
        let old_pp_index = pruning_point_write.pruning_point_index().unwrap();
        let retention_period_root = pruning_point_write.retention_period_root().unwrap();

        let new_pp_index = old_pp_index + pruning_points_to_add.len() as u64;
        pruning_point_write.set_batch(&mut batch, new_pruning_point, new_pp_index).unwrap();
        for (i, &past_pp) in pruning_points_to_add.iter().rev().enumerate() {
            self.past_pruning_points_store.insert_batch(&mut batch, old_pp_index + i as u64 + 1, past_pp).unwrap();
        }

        // For archival nodes, keep the retention root in place
        if !self.config.is_archival {
            let adjusted_retention_period_root =
                self.pruning_processor.advance_retention_period_root(retention_period_root, new_pruning_point);
            pruning_point_write.set_retention_period_root(&mut batch, adjusted_retention_period_root).unwrap();
        }

        // Update virtual state based to the new pruning point
        // Updating of the utxoset is done separately as it requires downloading the new utxoset in its entirety.
        let virtual_parents = vec![new_pruning_point];
        let virtual_state = Arc::new(VirtualState {
            parents: virtual_parents.clone(),
            ghostdag_data: self.services.ghostdag_manager.ghostdag(&virtual_parents),
            ..VirtualState::default()
        });
        self.virtual_stores.write().state.set_batch(&mut batch, virtual_state).unwrap();
        // Remove old body tips and insert pruning point as the current tip
        self.body_tips_store.write().delete_all_tips(&mut batch).unwrap();
        self.body_tips_store.write().init_batch(&mut batch, &virtual_parents).unwrap();
        // Update selected_chain
        self.selected_chain_store.write().init_with_pruning_point(&mut batch, new_pruning_point).unwrap();
        // It is important to set these flags to false together with writing the batch, in case the node crashes suddenly before syncing starts
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        pruning_meta_write.set_pruning_utxoset_stable_flag(&mut batch, false).unwrap();
        pruning_meta_write.set_pruning_smt_stable_flag(&mut batch, false).unwrap();
        drop(pruning_meta_write);
        // Store the currently bodyless anticone from the POV of the syncer, for trusted body validation at a later stage.
        let mut anticone = self.services.dag_traversal_manager.anticone(new_pruning_point, [syncer_sink].into_iter(), None)?;
        // Add the pruning point itself which is also missing a body
        anticone.push(new_pruning_point);
        self.pruning_meta_stores.write().set_body_missing_anticone(&mut batch, anticone).unwrap();
        self.db.write(batch).unwrap();
        drop(pruning_point_write);
        Ok(())
    }

    /// Verify that the new pruning point can be safely imported
    /// and return all new pruning point on path to it that needs to be updated in consensus
    fn get_and_verify_path_to_new_pruning_point(&self, new_pruning_point: Hash, syncer_sink: Hash) -> ConsensusResult<VecDeque<Hash>> {
        // Let B.sp denote the selected parent of a block B, let f be the finality depth, and let p be the pruning depth.
        // The new pruning point P can be "finalized" into consensus if:
        // 1) P satisfies P.blue_score>Nf and selected_parent(P).blue_score<=NF
        // where N is some integer (i.e. it is a valid pruning point based on score)
        let Ok(candidate_ghostdag_data) = self.get_ghostdag_data(new_pruning_point) else {
            return Err(ConsensusError::General(
                "Catchup cannot be continued since the syncer pruning point could not be confirmed to be a valid pruning point",
            ));
        };
        let Ok(selected_parent_ghostdag_data) = self.get_ghostdag_data(candidate_ghostdag_data.selected_parent) else {
            return Err(ConsensusError::General(
                "Catchup cannot be continued since the syncer pruning point could not be confirmed to be a valid pruning point",
            ));
        };
        self.services
            .pruning_point_manager
            .is_pruning_sample(
                candidate_ghostdag_data.blue_score,
                selected_parent_ghostdag_data.blue_score,
                self.config.params.finality_depth(),
            )
            .then_some(())
            .ok_or(ConsensusError::General("the alleged pruning point is not a valid pruning point, aborting catchup attempt"))?;

        // 2) There are sufficient headers built on top of it, specifically,
        // a header is validated whose blue_score is greater than P.B+p:
        let syncer_pp_bscore = self.get_header(new_pruning_point).unwrap().blue_score;
        let syncer_virtual_bscore = self.get_header(syncer_sink).unwrap().blue_score;
        if syncer_virtual_bscore < syncer_pp_bscore + self.config.pruning_depth() {
            return Err(ConsensusError::General("declared pruning point is not of sufficient depth"));
        }
        // 3) The syncer pruning point is on the selected chain from that header.
        if !self.services.reachability_service.is_chain_ancestor_of(new_pruning_point, syncer_sink) {
            return Err(ConsensusError::General("new pruning point is not in the past of syncer sink"));
        }
        info!("Setting {new_pruning_point} as the pruning point");
        // 4) The pruning points declared on headers on that path must be consistent with those already known by the node:
        let pruning_point_read = self.pruning_point_store.read();
        let old_pruning_point = pruning_point_read.pruning_point().unwrap();

        // Note that the function below also updates the pruning samples,
        // and implicitly confirms any pruning point pointed at en route to virtual is a pruning sample.
        // it is emphasized that updating pruning samples for individual blocks is not harmful
        // even if the verification ultimately does not succeed.
        let mut pruning_points_to_add =
            self.services.pruning_point_manager.pruning_points_on_path_to_syncer_sink(old_pruning_point, syncer_sink).map_err(
                |e: PruningImportError| {
                    ConsensusError::GeneralOwned(format!("pruning points en route to syncer sink do not form a valid chain: {}", e))
                },
            )?;
        // next we filter the returned list so it contains only the pruning point that must be introduced to consensus

        // Remove the excess pruning points before the old pruning point
        while let Some(past_pp) = pruning_points_to_add.pop_back() {
            if past_pp == old_pruning_point {
                break;
            }
        }
        if pruning_points_to_add.is_empty() {
            return Err(ConsensusError::General("old pruning points is inconsistent with synced headers"));
        }
        // Remove the excess pruning points beyond the new pruning_point
        while let Some(&future_pp) = pruning_points_to_add.front() {
            if future_pp == new_pruning_point {
                break;
            }
            // Here we only pop_front after checking as we want the new pruning_point to stay in the list
            pruning_points_to_add.pop_front();
        }
        if pruning_points_to_add.is_empty() {
            return Err(ConsensusError::General("new pruning point is inconsistent with synced headers"));
        }
        Ok(pruning_points_to_add)
    }

    fn validate_transaction_for_non_contextual_masses(&self, transaction: &Transaction) -> TxResult<()> {
        if transaction.is_coinbase() {
            return Ok(());
        }

        if transaction.inputs.len() > self.config.params.max_tx_inputs {
            return Err(TxRuleError::TooManyInputs(transaction.inputs.len(), self.config.params.max_tx_inputs));
        }

        if transaction.outputs.len() > self.config.params.max_tx_outputs {
            return Err(TxRuleError::TooManyOutputs(transaction.outputs.len(), self.config.params.max_tx_outputs));
        }

        if ComputeCommit::version_expects_compute_budget_field(transaction.version) {
            for (i, input) in transaction.inputs.iter().enumerate() {
                if let Some(sig_op_count) = input.compute_commit.sig_op_count() {
                    return Err(TxRuleError::SigopCountInV1(i, sig_op_count));
                }
            }
        } else {
            for (i, input) in transaction.inputs.iter().enumerate() {
                if let Some(compute_budget) = input.compute_commit.compute_budget() {
                    return Err(TxRuleError::ComputeBudgetInV0(i, compute_budget));
                }
            }
        }

        Ok(())
    }

    #[cfg(feature = "test-smt-pruning-diagnostics")]
    #[doc(hidden)]
    /// Diagnostic invariant helper: count versioned SMT entries at or below a
    /// pruning cutoff. Used by integration tests to catch stale pruning data.
    pub fn count_stale_smt_entries(&self, cutoff_blue_score: u64) -> StoreResult<StaleSmtEntriesCount> {
        self.storage.smt_stores.count_entries_at_or_below(cutoff_blue_score)
    }

    #[cfg(feature = "test-smt-pruning-diagnostics")]
    #[doc(hidden)]
    /// Diagnostic invariant helper: return whether the pruning checkpoint has
    /// caught up with the retention-period root, which marks pruning complete.
    pub fn is_pruning_stable(&self) -> StoreResult<bool> {
        let pruning_point_read = self.pruning_point_store.read();
        Ok(pruning_point_read.retention_checkpoint()? == pruning_point_read.retention_period_root()?)
    }
}

impl ConsensusApi for Consensus {
    fn build_block_template(
        &self,
        miner_data: MinerData,
        tx_selector: Box<dyn TemplateTransactionSelector>,
        build_mode: TemplateBuildMode,
    ) -> Result<BlockTemplate, RuleError> {
        self.virtual_processor.build_block_template(miner_data, tx_selector, build_mode)
    }

    fn validate_and_insert_block(&self, block: Block) -> BlockValidationFutures {
        let (block_task, virtual_state_task) = self.validate_and_insert_block_impl(BlockTask::Ordinary { block });
        BlockValidationFutures { block_task: Box::pin(block_task), virtual_state_task: Box::pin(virtual_state_task) }
    }

    fn validate_and_insert_trusted_block(&self, tb: TrustedBlock) -> BlockValidationFutures {
        let (block_task, virtual_state_task) = self.validate_and_insert_block_impl(BlockTask::Trusted { block: tb.block });
        BlockValidationFutures { block_task: Box::pin(block_task), virtual_state_task: Box::pin(virtual_state_task) }
    }

    fn validate_mempool_transaction(&self, transaction: &mut MutableTransaction, args: &TransactionValidationArgs) -> TxResult<()> {
        self.virtual_processor.validate_mempool_transaction(transaction, args)?;
        Ok(())
    }

    fn validate_mempool_transactions_in_parallel(
        &self,
        transactions: &mut [MutableTransaction],
        args: &TransactionValidationBatchArgs,
    ) -> Vec<TxResult<()>> {
        self.virtual_processor.validate_mempool_transactions_in_parallel(transactions, args)
    }

    fn populate_mempool_transaction(&self, transaction: &mut MutableTransaction) -> TxResult<()> {
        self.virtual_processor.populate_mempool_transaction(transaction)?;
        Ok(())
    }

    fn populate_mempool_transactions_in_parallel(&self, transactions: &mut [MutableTransaction]) -> Vec<TxResult<()>> {
        self.virtual_processor.populate_mempool_transactions_in_parallel(transactions)
    }

    fn calculate_transaction_non_contextual_masses(&self, transaction: &Transaction) -> TxResult<NonContextualMasses> {
        self.validate_transaction_for_non_contextual_masses(transaction)?;
        Ok(self.services.mass_calculator.calc_non_contextual_masses(transaction))
    }

    fn calculate_transaction_contextual_masses(&self, transaction: &MutableTransaction) -> Option<ContextualMasses> {
        self.services.mass_calculator.calc_contextual_masses(&transaction.as_verifiable())
    }

    fn get_stats(&self) -> ConsensusStats {
        // This method is designed to return stats asap and not depend on locks which
        // might take time to acquire
        ConsensusStats {
            block_counts: self.estimate_block_count(),
            // This call acquires the tips store read lock which is expected to be fast. If this
            // turns out to be not fast enough then we should maintain an atomic integer holding this value
            num_tips: self.get_tips_len() as u64,
            virtual_stats: self.lkg_virtual_state.load().as_ref().into(),
        }
    }

    fn get_virtual_daa_score(&self) -> u64 {
        self.lkg_virtual_state.load().daa_score
    }

    fn get_virtual_bits(&self) -> u32 {
        self.lkg_virtual_state.load().bits
    }

    fn get_virtual_past_median_time(&self) -> u64 {
        self.lkg_virtual_state.load().past_median_time
    }

    fn get_virtual_merge_depth_root(&self) -> Option<Hash> {
        // TODO: consider saving the merge depth root as part of virtual state
        let pruning_point = self.pruning_point_store.read().pruning_point().unwrap();
        let virtual_state = self.lkg_virtual_state.load();
        let virtual_ghostdag_data = &virtual_state.ghostdag_data;
        let root = self.services.depth_manager.calc_merge_depth_root(virtual_ghostdag_data, pruning_point);
        if root.is_origin() { None } else { Some(root) }
    }

    fn get_virtual_merge_depth_blue_work_threshold(&self) -> BlueWorkType {
        // PRUNE SAFETY: merge depth root is never close to being pruned (in terms of block depth)
        self.get_virtual_merge_depth_root().map_or(BlueWorkType::ZERO, |root| self.ghostdag_store.get_blue_work(root).unwrap())
    }

    fn get_sink(&self) -> Hash {
        self.lkg_virtual_state.load().ghostdag_data.selected_parent
    }

    fn get_sink_timestamp(&self) -> u64 {
        self.headers_store.get_timestamp(self.get_sink()).unwrap()
    }

    fn get_sink_blue_score(&self) -> u64 {
        self.headers_store.get_blue_score(self.get_sink()).unwrap()
    }

    fn get_sink_daa_score_timestamp(&self) -> DaaScoreTimestamp {
        let sink = self.get_sink();
        let compact = self.headers_store.get_compact_header_data(sink).unwrap();
        DaaScoreTimestamp { daa_score: compact.daa_score, timestamp: compact.timestamp }
    }

    /// Returns the merge context of `hash`, if the block was already merged by a virtual chain block.
    ///
    /// Return semantics:
    /// - `Err` if `hash` is unknown or outside the retained context required for this query.
    /// - `Ok(None)` if `hash` is known and retained, but is not yet in `past(sink)`.
    /// - `Ok(Some(..))` with the merging chain block context otherwise.
    fn get_merged_block_context(&self, hash: Hash) -> ConsensusResult<Option<MergedBlockContext>> {
        let _guard = self.pruning_lock.blocking_read();

        // Verify the block exists and can be assumed to have relations and reachability data
        self.validate_block_exists(hash)?;

        // Verify that the block is in future(retention root), where Ghostdag data is complete
        if !self.services.reachability_service.is_dag_ancestor_of(self.get_retention_period_root(), hash) {
            return Err(ConsensusError::General("the queried hash does not have retention root in its past"));
        }

        let sink = self.get_sink();

        // Optimization: verify that the block is in past(sink), otherwise the search will fail anyway
        // (means the block was not merged yet by a virtual chain block)
        if !self.services.reachability_service.is_dag_ancestor_of(hash, sink) {
            return Ok(None);
        }

        let mut heap: BinaryHeap<Reverse<SortableBlock>> = BinaryHeap::new();
        let mut visited = BlockHashSet::new();

        for child in self.get_block_children(hash).unwrap() {
            if visited.insert(child) {
                let blue_work = self.ghostdag_store.get_blue_work(child).unwrap();
                heap.push(Reverse(SortableBlock::new(child, blue_work)));
            }
        }

        while let Some(Reverse(SortableBlock { hash: decedent, .. })) = heap.pop() {
            if self.services.reachability_service.is_chain_ancestor_of(decedent, sink) {
                let decedent_data = self.get_ghostdag_data(decedent).unwrap();

                return Ok(if decedent_data.mergeset_blues.contains(&hash) {
                    Some(MergedBlockContext { merging_chain_block_hash: decedent, is_blue: true })
                } else if decedent_data.mergeset_reds.contains(&hash) {
                    Some(MergedBlockContext { merging_chain_block_hash: decedent, is_blue: false })
                } else {
                    // Note: because we are doing a topological BFS up (from `hash` towards virtual), the first chain block
                    // found must also be our merging block, so hash will be either in blues or in reds, rendering this line
                    // unreachable.
                    kaspa_core::warn!("DAG topology inconsistency: {decedent} is expected to be a merging block of {hash}");
                    None
                });
            }

            for child in self.get_block_children(decedent).unwrap() {
                if visited.insert(child) {
                    let blue_work = self.ghostdag_store.get_blue_work(child).unwrap();
                    heap.push(Reverse(SortableBlock::new(child, blue_work)));
                }
            }
        }

        Ok(None)
    }

    fn get_virtual_state_approx_id(&self) -> VirtualStateApproxId {
        self.lkg_virtual_state.load().to_virtual_state_approx_id()
    }

    fn get_retention_period_root(&self) -> Hash {
        self.pruning_point_store.read().retention_period_root().unwrap()
    }

    /// Estimates the number of blocks and headers stored in the node database.
    ///
    /// This is an estimation based on the DAA score difference between the node's `retention root` and `virtual`'s DAA score,
    /// as such, it does not include non-daa blocks, and does not include headers stored as part of the pruning proof.
    fn estimate_block_count(&self) -> BlockCount {
        // PRUNE SAFETY: retention root is always a current or past pruning point which its header is kept permanently
        let retention_period_root_score = self.headers_store.get_daa_score(self.get_retention_period_root()).unwrap();
        let virtual_score = self.get_virtual_daa_score();
        // TODO(relaxed): change virtual's 0 daa initialization, and revert to normal subtraction
        let header_count = self
            .headers_store
            .get_daa_score(self.get_headers_selected_tip())
            .optional()
            .unwrap()
            .unwrap_or(virtual_score)
            .max(virtual_score)
            .saturating_sub(retention_period_root_score);
        let block_count = virtual_score.saturating_sub(retention_period_root_score);
        BlockCount { header_count, block_count }
    }

    fn get_virtual_chain_from_block(&self, low: Hash, chain_path_added_limit: Option<usize>) -> ConsensusResult<ChainPath> {
        // Calculate chain changes between the given `low` and the current sink hash (up to `limit` amount of block hashes).
        // Note:
        // 1) that we explicitly don't
        // do the calculation against the virtual itself so that we
        // won't later need to remove it from the result.
        // 2) supplying `None` as `chain_path_added_limit` will result in the full chain path, with optimized performance.
        let _guard = self.pruning_lock.blocking_read();

        // Verify that the block exists
        self.validate_block_exists(low)?;

        // Verify that retention root is on chain(block)
        self.services
            .reachability_service
            .is_chain_ancestor_of(self.get_retention_period_root(), low)
            .then_some(())
            .ok_or(ConsensusError::General("the queried hash does not have retention root on its chain"))?;

        Ok(self.services.dag_traversal_manager.calculate_chain_path(low, self.get_sink(), chain_path_added_limit))
    }

    /// Returns a Vec of header samples since genesis
    /// ordered by ascending daa_score, first entry is genesis
    fn get_chain_block_samples(&self) -> Vec<DaaScoreTimestamp> {
        // We need consistency between the past pruning points, selected chain and header store reads
        let _guard = self.pruning_lock.blocking_read();

        // Sorted from genesis to latest pruning_point_headers
        let pp_headers = self.pruning_point_compact_headers();
        let step_divisor: usize = 3; // The number of extra samples we'll get from blocks after last pp header
        let prealloc_len = pp_headers.len() + step_divisor + 1;

        let mut sample_headers;

        // Part 1: Add samples from pruning point headers:
        if self.config.net.network_type == NetworkType::Mainnet {
            // For mainnet, we add extra data (16 pp headers) from before checkpoint genesis.
            // Source: https://github.com/kaspagang/kaspad-py-explorer/blob/main/src/tx_timestamp_estimation.ipynb
            // For context see also: https://github.com/kaspagang/kaspad-py-explorer/blob/main/src/genesis_proof.ipynb
            const POINTS: &[DaaScoreTimestamp] = &[
                DaaScoreTimestamp { daa_score: 0, timestamp: 1636298787842 },
                DaaScoreTimestamp { daa_score: 87133, timestamp: 1636386662010 },
                DaaScoreTimestamp { daa_score: 176797, timestamp: 1636473700804 },
                DaaScoreTimestamp { daa_score: 264837, timestamp: 1636560706885 },
                DaaScoreTimestamp { daa_score: 355974, timestamp: 1636650005662 },
                DaaScoreTimestamp { daa_score: 445152, timestamp: 1636737841327 },
                DaaScoreTimestamp { daa_score: 536709, timestamp: 1636828600930 },
                DaaScoreTimestamp { daa_score: 624635, timestamp: 1636912614350 },
                DaaScoreTimestamp { daa_score: 712234, timestamp: 1636999362832 },
                DaaScoreTimestamp { daa_score: 801831, timestamp: 1637088292662 },
                DaaScoreTimestamp { daa_score: 890716, timestamp: 1637174890675 },
                DaaScoreTimestamp { daa_score: 978396, timestamp: 1637260956454 },
                DaaScoreTimestamp { daa_score: 1068387, timestamp: 1637349078269 },
                DaaScoreTimestamp { daa_score: 1139626, timestamp: 1637418723538 },
                DaaScoreTimestamp { daa_score: 1218320, timestamp: 1637495941516 },
                DaaScoreTimestamp { daa_score: 1312860, timestamp: 1637609671037 },
            ];
            sample_headers = Vec::<DaaScoreTimestamp>::with_capacity(prealloc_len + POINTS.len());
            sample_headers.extend_from_slice(POINTS);
        } else {
            sample_headers = Vec::<DaaScoreTimestamp>::with_capacity(prealloc_len);
        }

        for header in pp_headers.iter() {
            sample_headers.push(DaaScoreTimestamp { daa_score: header.1.daa_score, timestamp: header.1.timestamp });
        }

        // Part 2: Add samples from recent chain blocks
        let sc_read = self.storage.selected_chain_store.read();
        let high_index = sc_read.get_tip().unwrap().0;
        // The last pruning point is always expected in the selected chain store. However if due to some reason
        // this is not the case, we prefer not crashing but rather avoid sampling (hence set low index to high index)
        let low_index = sc_read.get_by_hash(pp_headers.last().unwrap().0).optional().unwrap().unwrap_or(high_index);
        let step_size = cmp::max((high_index - low_index) / (step_divisor as u64), 1);

        // We chain `high_index` to make sure we sample sink, and dedup to avoid sampling it twice
        for index in (low_index + step_size..=high_index).step_by(step_size as usize).chain(once(high_index)).dedup() {
            let compact = self
                .storage
                .headers_store
                .get_compact_header_data(sc_read.get_by_index(index).expect("store lock is acquired"))
                .unwrap();
            sample_headers.push(DaaScoreTimestamp { daa_score: compact.daa_score, timestamp: compact.timestamp });
        }

        sample_headers
    }
    fn get_transactions_by_accepting_daa_score(
        &self,
        accepting_daa_score: u64,
        tx_ids: Option<Vec<TransactionId>>,
        tx_type: TransactionType,
    ) -> ConsensusResult<TransactionQueryResult> {
        // We need consistency between the acceptance store and the block transaction store,
        let _guard = self.pruning_lock.blocking_read();
        let accepting_block = self
            .virtual_processor
            .find_accepting_chain_block_hash_at_daa_score(accepting_daa_score, self.get_retention_period_root())?;
        self.get_transactions_by_accepting_block(accepting_block, tx_ids, tx_type)
    }

    fn get_transactions_by_block_acceptance_data(
        &self,
        accepting_block: Hash,
        block_acceptance_data: MergesetBlockAcceptanceData,
        tx_ids: Option<Vec<TransactionId>>,
        tx_type: TransactionType,
    ) -> ConsensusResult<TransactionQueryResult> {
        // Need consistency between the acceptance store and the block transaction store.
        let _guard = self.pruning_lock.blocking_read();

        match tx_type {
            TransactionType::Transaction => {
                if let Some(tx_ids) = tx_ids {
                    let mut tx_ids_filter = HashSet::with_capacity(tx_ids.len());
                    tx_ids_filter.extend(tx_ids);

                    Ok(TransactionQueryResult::Transaction(Arc::new(
                        self.get_block_transactions(
                            block_acceptance_data.block_hash,
                            Some(
                                block_acceptance_data
                                    .accepted_transactions
                                    .into_iter()
                                    .filter_map(|atx| {
                                        if tx_ids_filter.contains(&atx.transaction_id) { Some(atx.index_within_block) } else { None }
                                    })
                                    .collect(),
                            ),
                        )?,
                    )))
                } else {
                    Ok(TransactionQueryResult::Transaction(Arc::new(self.get_block_transactions(
                        block_acceptance_data.block_hash,
                        Some(block_acceptance_data.accepted_transactions.iter().map(|atx| atx.index_within_block).collect()),
                    )?)))
                }
            }
            TransactionType::SignableTransaction => Ok(TransactionQueryResult::SignableTransaction(Arc::new(
                self.virtual_processor.get_populated_transactions_by_block_acceptance_data(
                    tx_ids,
                    block_acceptance_data,
                    accepting_block,
                )?,
            ))),
        }
    }

    fn get_transactions_by_accepting_block(
        &self,
        accepting_block: Hash,
        tx_ids: Option<Vec<TransactionId>>,
        tx_type: TransactionType,
    ) -> ConsensusResult<TransactionQueryResult> {
        // need consistency between the acceptance store and the block transaction store,
        let _guard = self.pruning_lock.blocking_read();

        match tx_type {
            TransactionType::Transaction => {
                let accepting_block_mergeset_acceptance_data_iter = self
                    .acceptance_data_store
                    .get(accepting_block)
                    .map_err(|_| ConsensusError::MissingData(accepting_block))?
                    .unwrap_or_clone()
                    .into_iter();

                if let Some(tx_ids) = tx_ids {
                    let mut tx_ids_filter = HashSet::with_capacity(tx_ids.len());
                    tx_ids_filter.extend(tx_ids);

                    Ok(TransactionQueryResult::Transaction(Arc::new(
                        accepting_block_mergeset_acceptance_data_iter
                            .flat_map(|mbad| {
                                self.get_block_transactions(
                                    mbad.block_hash,
                                    Some(
                                        mbad.accepted_transactions
                                            .into_iter()
                                            .filter_map(|atx| {
                                                if tx_ids_filter.contains(&atx.transaction_id) {
                                                    Some(atx.index_within_block)
                                                } else {
                                                    None
                                                }
                                            })
                                            .collect(),
                                    ),
                                )
                            })
                            .flatten()
                            .collect::<Vec<_>>(),
                    )))
                } else {
                    Ok(TransactionQueryResult::Transaction(Arc::new(
                        accepting_block_mergeset_acceptance_data_iter
                            .flat_map(|mbad| {
                                self.get_block_transactions(
                                    mbad.block_hash,
                                    Some(mbad.accepted_transactions.iter().map(|atx| atx.index_within_block).collect()),
                                )
                            })
                            .flatten()
                            .collect::<Vec<_>>(),
                    )))
                }
            }
            TransactionType::SignableTransaction => Ok(TransactionQueryResult::SignableTransaction(Arc::new(
                self.virtual_processor.get_populated_transactions_by_accepting_block(tx_ids, accepting_block)?,
            ))),
        }
    }

    fn get_virtual_parents(&self) -> BlockHashSet {
        self.lkg_virtual_state.load().parents.iter().copied().collect()
    }

    fn get_virtual_parents_len(&self) -> usize {
        self.lkg_virtual_state.load().parents.len()
    }

    fn get_virtual_utxos(
        &self,
        from_outpoint: Option<TransactionOutpoint>,
        chunk_size: usize,
        skip_first: bool,
    ) -> Vec<(TransactionOutpoint, UtxoEntry)> {
        let virtual_stores = self.virtual_stores.read();
        let iter = virtual_stores.utxo_set.seek_iterator(from_outpoint, chunk_size, skip_first);
        iter.map(|item| item.unwrap()).collect()
    }

    fn get_tips(&self) -> Vec<Hash> {
        self.body_tips_store.read().get().unwrap().read().iter().copied().collect_vec()
    }

    fn get_tips_len(&self) -> usize {
        self.body_tips_store.read().get().unwrap().read().len()
    }

    fn get_pruning_point_utxos(
        &self,
        expected_pruning_point: Hash,
        from_outpoint: Option<TransactionOutpoint>,
        chunk_size: usize,
        skip_first: bool,
    ) -> ConsensusResult<Vec<(TransactionOutpoint, UtxoEntry)>> {
        if self.pruning_point_store.read().pruning_point().unwrap() != expected_pruning_point {
            return Err(ConsensusError::UnexpectedPruningPoint);
        }
        let pruning_meta_read = self.pruning_meta_stores.read();
        let iter = pruning_meta_read.utxo_set.seek_iterator(from_outpoint, chunk_size, skip_first);
        let utxos = iter.map(|item| item.unwrap()).collect();
        drop(pruning_meta_read);

        // We recheck the expected pruning point in case it was switched just before the utxo set read.
        // NOTE: we rely on order of operations by pruning processor. See extended comment therein.
        if self.pruning_point_store.read().pruning_point().unwrap() != expected_pruning_point {
            return Err(ConsensusError::UnexpectedPruningPoint);
        }

        Ok(utxos)
    }

    fn modify_coinbase_payload(&self, payload: Vec<u8>, miner_data: &MinerData) -> CoinbaseResult<Vec<u8>> {
        self.services.coinbase_manager.modify_coinbase_payload(payload, miner_data)
    }

    fn calc_transaction_hash_merkle_root(&self, txs: &[Transaction]) -> Hash {
        calc_hash_merkle_root(txs.iter())
    }

    fn validate_pruning_proof(
        &self,
        proof: &PruningPointProof,
        proof_metadata: &PruningProofMetadata,
    ) -> Result<(), PruningImportError> {
        self.services.pruning_proof_manager.validate_pruning_point_proof(proof, proof_metadata)
    }

    fn apply_pruning_proof(
        &self,
        proof: PruningPointProof,
        trusted_set: &[TrustedBlock],
        header_only_chain_segment: &[Arc<Header>],
    ) -> PruningImportResult<()> {
        self.services.pruning_proof_manager.apply_proof(proof, trusted_set, header_only_chain_segment)
    }

    fn import_pruning_points(&self, pruning_points: PruningPointsList) -> PruningImportResult<()> {
        self.services.pruning_proof_manager.import_pruning_points(&pruning_points)
    }

    fn append_imported_pruning_point_utxos(&self, utxoset_chunk: &[(TransactionOutpoint, UtxoEntry)], current_multiset: &mut MuHash) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        pruning_meta_write.utxo_set.write_many(utxoset_chunk).unwrap();

        // Parallelize processing using the context of an existing thread pool.
        let inner_multiset = self.virtual_processor.install(|| {
            utxoset_chunk.par_iter().map(|(outpoint, entry)| MuHash::from_utxo(outpoint, entry)).reduce(MuHash::new, |mut a, b| {
                a.combine(&b);
                a
            })
        });

        current_multiset.combine(&inner_multiset);
    }

    fn import_pruning_point_utxo_set(&self, new_pruning_point: Hash, imported_utxo_multiset: MuHash) -> PruningImportResult<()> {
        self.virtual_processor.import_pruning_point_utxo_set(new_pruning_point, imported_utxo_multiset)
    }

    fn import_pruning_point_smt(
        &self,
        new_pruning_point: Hash,
        metadata: kaspa_consensus_core::api::SmtExportMetadata,
        inactivity_shortcut_block: Hash,
        lane_batches: ImportLaneBatchIterator<'_>,
    ) -> PruningImportResult<()> {
        use crate::model::stores::smt_metadata::SmtBlockMetadata;
        use kaspa_hashes::ZERO_HASH;
        use kaspa_smt_store::streaming_import::streaming_import;

        let kaspa_consensus_core::api::SmtExportMetadata { lanes_root, payload_and_ctx_digest, active_lanes_count, .. } = metadata;
        let expected_lane_count = active_lanes_count;

        // `inactivity_shortcut_block` was already resolved by the caller during metadata verification.
        let row = SmtBlockMetadata::new(payload_and_ctx_digest, inactivity_shortcut_block, active_lanes_count);

        let result = self.virtual_processor.install(|| {
            streaming_import(
                &self.db,
                &self.storage.smt_stores,
                ZERO_HASH,
                expected_lane_count,
                lanes_root,
                // Chunks arrive pre-sized (up to SMT_CHUNK_SIZE) from the wire-level chunker —
                // forwarded as-is, no re-batching.
                lane_batches,
                4096,
            )
            .map_err(|e| PruningImportError::SmtStoreError(format!("{e}")))
        })?;

        if result.root != lanes_root {
            return Err(PruningImportError::SmtRootMismatch { expected: lanes_root, computed: result.root });
        }

        let actual_count = result.lanes_imported;
        if actual_count != expected_lane_count {
            return Err(PruningImportError::SmtStoreError(format!(
                "active lanes count mismatch: expected {expected_lane_count}, got {actual_count}"
            )));
        }

        // The wire's metadata was already authenticated by the caller via `verify_smt_metadata`.
        let mut batch = rocksdb::WriteBatch::default();
        self.storage.smt_metadata_store.insert_batch(&mut batch, new_pruning_point, row).unwrap();
        self.db.write(batch).unwrap();

        info!("Imported SMT state for pruning point {}: {} lanes, root {}", new_pruning_point, actual_count, lanes_root);
        Ok(())
    }

    fn get_pruning_point_smt_metadata(
        &self,
        expected_pruning_point: Hash,
    ) -> ConsensusResult<kaspa_consensus_core::api::SmtExportMetadata> {
        self.virtual_processor.get_pruning_point_smt_metadata(expected_pruning_point)
    }

    fn inactivity_shortcut_block_for_pov(&self, pov_block: Hash) -> ConsensusResult<Hash> {
        self.virtual_processor.inactivity_shortcut_block_for_pov(pov_block)
    }

    fn open_pruning_point_smt_lane_stream(
        &self,
        expected_pruning_point: Hash,
    ) -> ConsensusResult<Box<dyn Iterator<Item = ConsensusResult<kaspa_consensus_core::api::ImportLane>> + Send + 'static>> {
        use kaspa_consensus_core::api::{ImportLane, SMT_PROOF_INTERVAL};

        let pp = self.pruning_point_store.read().pruning_point().unwrap();
        if pp != expected_pruning_point {
            return Err(ConsensusError::UnexpectedPruningPoint);
        }
        let max_score = self.storage.headers_store.get_blue_score(pp).unwrap();
        // KIP-21: IBD streams only the active-lanes window `[pp - finality_depth, pp]`.
        let min_score = max_score.saturating_sub(self.config.params.finality_depth());

        let smt_stores = self.storage.smt_stores.clone();
        let vp = self.virtual_processor.clone();

        let is_canonical = {
            let vp = vp.clone();
            move |bh| vp.is_smt_canonical(bh, pp)
        };
        // Clip the scan window to `[pp.blue_score - finality, pp.blue_score]`.
        // Entries above `pp.blue_score` belong to blocks in pp's future and
        // must not be part of the SMT state exported for this pruning point.
        let raw = smt_stores.lane_version.iter_all_canonical_owned(None, min_score, Some(max_score), is_canonical);

        let sl = self.session_lock().clone();
        let pps = self.pruning_point_store.clone();
        let smt_stores_proof = smt_stores.clone();
        let mut idx: u64 = 0;
        let mapped = raw.map(move |res| -> ConsensusResult<ImportLane> {
            let (lane_key, verified) = res.map_err(|e| ConsensusError::GeneralOwned(format!("SMT lane iter: {e}")))?;
            let proof = if (idx as usize).is_multiple_of(SMT_PROOF_INTERVAL) {
                let _g = sl.blocking_read();
                let upp = pps.read().pruning_point().unwrap();
                if upp != pp {
                    return Err(ConsensusError::UnexpectedPruningPoint);
                }
                let vp_proof = vp.clone();
                Some(
                    smt_stores_proof
                        .prove_lane(&lane_key, SmtReadBounds::new(max_score, min_score), move |bh| vp_proof.is_smt_canonical(bh, pp))
                        .map_err(|e| ConsensusError::GeneralOwned(format!("prove_lane: {e}")))?,
                )
            } else {
                None
            };
            idx += 1;
            Ok(ImportLane { lane_key, lane_tip: *verified.data(), blue_score: verified.blue_score(), proof })
        });

        // Chain a one-shot tail so a fully drained stream verifies that
        // pruning did not advance before the stream completed.
        let sl = self.session_lock().clone();
        let pps = self.pruning_point_store.clone();
        let final_check = std::iter::once_with(move || {
            let _g = sl.blocking_read();
            let upp = pps.read().pruning_point().unwrap();
            if upp != pp { Some(Err(ConsensusError::UnexpectedPruningPoint)) } else { None }
        })
        .flatten();

        Ok(Box::new(mapped.chain(final_check)))
    }

    fn validate_pruning_points(&self, syncer_virtual_selected_parent: Hash) -> ConsensusResult<()> {
        let hst = self.storage.headers_selected_tip_store.read().get().unwrap().hash;
        let (synced_pruning_point, synced_pp_index) = self.pruning_point_store.read().pruning_point_and_index().unwrap();
        if !self.services.pruning_point_manager.is_valid_pruning_point(synced_pruning_point, hst) {
            return Err(ConsensusError::General("pruning point does not coincide with the synced header selected tip"));
        }
        if !self.services.pruning_point_manager.is_valid_pruning_point(synced_pruning_point, syncer_virtual_selected_parent) {
            return Err(ConsensusError::General("pruning point does not coincide with the syncer's sink (virtual selected parent)"));
        }
        self.services
            .pruning_point_manager
            .are_pruning_points_in_valid_chain(synced_pruning_point, synced_pp_index, syncer_virtual_selected_parent)
            .map_err(|e| ConsensusError::GeneralOwned(format!("past pruning points do not form a valid chain: {}", e)))
    }

    fn is_chain_ancestor_of(&self, low: Hash, high: Hash) -> ConsensusResult<bool> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(low)?;
        self.validate_block_exists(high)?;
        Ok(self.services.reachability_service.is_chain_ancestor_of(low, high))
    }

    // max_blocks has to be greater than the merge set size limit
    fn get_hashes_between(&self, low: Hash, high: Hash, max_blocks: usize) -> ConsensusResult<(Vec<Hash>, Hash)> {
        let _guard = self.pruning_lock.blocking_read();
        assert!(max_blocks as u64 > self.config.mergeset_size_limit());
        self.validate_block_exists(low)?;
        self.validate_block_exists(high)?;

        Ok(self.services.sync_manager.antipast_hashes_between(low, high, Some(max_blocks)))
    }

    fn get_header(&self, hash: Hash) -> ConsensusResult<Arc<Header>> {
        self.headers_store.get_header(hash).optional().unwrap().ok_or(ConsensusError::HeaderNotFound(hash))
    }

    fn get_headers_selected_tip(&self) -> Hash {
        self.headers_selected_tip_store.read().get().unwrap().hash
    }

    fn get_antipast_from_pov(&self, hash: Hash, context: Hash, max_traversal_allowed: Option<u64>) -> ConsensusResult<Vec<Hash>> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(hash)?;
        self.validate_block_exists(context)?;
        Ok(self.services.dag_traversal_manager.antipast(hash, std::iter::once(context), max_traversal_allowed)?)
    }

    fn get_anticone(&self, hash: Hash) -> ConsensusResult<Vec<Hash>> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(hash)?;
        let virtual_state = self.lkg_virtual_state.load();
        Ok(self.services.dag_traversal_manager.anticone(hash, virtual_state.parents.iter().copied(), None)?)
    }

    fn get_pruning_point_proof(&self) -> Arc<PruningPointProof> {
        // PRUNE SAFETY: proof is cached before the prune op begins and the
        // pruning point cannot move during the prune so the cache remains valid
        self.services.pruning_proof_manager.get_pruning_point_proof()
    }

    fn create_virtual_selected_chain_block_locator(&self, low: Option<Hash>, high: Option<Hash>) -> ConsensusResult<Vec<Hash>> {
        let _guard = self.pruning_lock.blocking_read();
        if let Some(low) = low {
            self.validate_block_exists(low)?;
        }

        if let Some(high) = high {
            self.validate_block_exists(high)?;
        }

        Ok(self.services.sync_manager.create_virtual_selected_chain_block_locator(low, high)?)
    }

    fn pruning_point_headers(&self) -> Vec<Arc<Header>> {
        // PRUNE SAFETY: index is monotonic and past pruning point headers are expected permanently
        let (pruning_point, pruning_index) = self.pruning_point_store.read().pruning_point_and_index().unwrap();
        (0..pruning_index)
            .map(|index| self.past_pruning_points_store.get(index).unwrap())
            .chain(once(pruning_point))
            .map(|hash| self.headers_store.get_header(hash).unwrap())
            .collect_vec()
    }

    fn get_pruning_point_anticone_and_trusted_data(&self) -> ConsensusResult<Arc<PruningPointTrustedData>> {
        // PRUNE SAFETY: anticone and trusted data are cached before the prune op begins and the
        // pruning point cannot move during the prune so the cache remains valid
        self.services.pruning_proof_manager.get_pruning_point_anticone_and_trusted_data()
    }

    fn get_block(&self, hash: Hash) -> ConsensusResult<Block> {
        if match self.statuses_store.read().get(hash).optional().unwrap() {
            Some(status) => !status.has_block_body(),
            None => true,
        } {
            return Err(ConsensusError::BlockNotFound(hash));
        }

        Ok(Block {
            header: self.headers_store.get_header(hash).optional().unwrap().ok_or(ConsensusError::BlockNotFound(hash))?,
            transactions: self.block_transactions_store.get(hash).optional().unwrap().ok_or(ConsensusError::BlockNotFound(hash))?,
        })
    }

    fn get_block_transactions(&self, hash: Hash, indices: Option<Vec<TransactionIndexType>>) -> ConsensusResult<Vec<Transaction>> {
        let transactions = self.block_transactions_store.get(hash).optional().unwrap().ok_or(ConsensusError::BlockNotFound(hash))?;
        let tx_len = transactions.len();

        if let Some(indices) = indices {
            if tx_len < indices.len() {
                return Err(ConsensusError::TransactionQueryTooLarge(indices.len(), hash, transactions.len()));
            }

            let res = transactions
                .unwrap_or_clone()
                .into_iter()
                .enumerate()
                .filter(|(index, _tx)| indices.contains(&(*index as TransactionIndexType)))
                .map(|(_, tx)| tx)
                .collect::<Vec<_>>();

            if res.len() != indices.len() {
                Err(ConsensusError::TransactionIndexOutOfBounds(*indices.iter().max().unwrap(), tx_len, hash))
            } else {
                Ok(res)
            }
        } else {
            Ok(transactions.unwrap_or_clone())
        }
    }

    fn get_block_body(&self, hash: Hash) -> ConsensusResult<Arc<Vec<Transaction>>> {
        if match self.statuses_store.read().get(hash).optional().unwrap() {
            Some(status) => !status.has_block_body(),
            None => true,
        } {
            return Err(ConsensusError::BlockNotFound(hash));
        }

        self.block_transactions_store.get(hash).optional().unwrap().ok_or(ConsensusError::BlockNotFound(hash))
    }

    fn get_block_even_if_header_only(&self, hash: Hash) -> ConsensusResult<Block> {
        let Some(status) = self.statuses_store.read().get(hash).optional().unwrap().filter(|&status| status.has_block_header()) else {
            return Err(ConsensusError::HeaderNotFound(hash));
        };
        Ok(Block {
            header: self.headers_store.get_header(hash).optional().unwrap().ok_or(ConsensusError::HeaderNotFound(hash))?,
            transactions: if status.is_header_only() {
                Default::default()
            } else {
                self.block_transactions_store.get(hash).optional().unwrap().unwrap_or_default()
            },
        })
    }

    fn get_ghostdag_data(&self, hash: Hash) -> ConsensusResult<ExternalGhostdagData> {
        match self.get_block_status(hash) {
            None => return Err(ConsensusError::HeaderNotFound(hash)),
            Some(BlockStatus::StatusInvalid) => return Err(ConsensusError::InvalidBlock(hash)),
            _ => {}
        };
        let ghostdag = self.ghostdag_store.get_data(hash).optional().unwrap().ok_or(ConsensusError::MissingData(hash))?;
        Ok((&*ghostdag).into())
    }

    fn get_block_children(&self, hash: Hash) -> Option<Vec<Hash>> {
        self.services
            .relations_service
            .get_children(hash)
            .optional()
            .unwrap()
            .map(|children| children.read().iter().copied().collect_vec())
    }

    fn get_block_parents(&self, hash: Hash) -> Option<Arc<Vec<Hash>>> {
        self.services.relations_service.get_parents(hash).optional().unwrap()
    }

    fn get_block_status(&self, hash: Hash) -> Option<BlockStatus> {
        self.statuses_store.read().get(hash).optional().unwrap()
    }

    fn get_block_acceptance_data(&self, hash: Hash) -> ConsensusResult<Arc<AcceptanceData>> {
        self.acceptance_data_store.get(hash).optional().unwrap().ok_or(ConsensusError::MissingData(hash))
    }

    fn get_blocks_acceptance_data(
        &self,
        hashes: &[Hash],
        merged_blocks_limit: Option<usize>,
    ) -> ConsensusResult<Vec<Arc<AcceptanceData>>> {
        // Note: merged_blocks_limit will limit after the sum of merged blocks is breached along the supplied hash's acceptance data
        // and not limit the acceptance data within a queried hash. i.e. It has mergeset_size_limit granularity, this is to guarantee full acceptance data coverage.
        if merged_blocks_limit.is_none() {
            return hashes
                .iter()
                .copied()
                .map(|hash| self.acceptance_data_store.get(hash).optional().unwrap().ok_or(ConsensusError::MissingData(hash)))
                .collect::<ConsensusResult<Vec<_>>>();
        }
        let merged_blocks_limit = merged_blocks_limit.unwrap(); // we handle `is_none`, so may unwrap.
        let mut num_of_merged_blocks = 0usize;

        hashes
            .iter()
            .copied()
            .map_while(|hash| {
                let entry = self.acceptance_data_store.get(hash).optional().unwrap().ok_or(ConsensusError::MissingData(hash));
                num_of_merged_blocks += entry.as_ref().map_or(0, |entry| entry.len());
                if num_of_merged_blocks > merged_blocks_limit { None } else { Some(entry) }
            })
            .collect::<ConsensusResult<Vec<_>>>()
    }

    fn is_chain_block(&self, hash: Hash) -> ConsensusResult<bool> {
        self.is_chain_ancestor_of(hash, self.get_sink())
    }

    fn get_seq_commit_lane_proof(&self, block_hash: Hash, lane_key: Hash) -> ConsensusResult<SeqCommitLaneProof> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(block_hash)?;

        // Genesis has no selected parent; reject before we try to dereference one.
        if block_hash == self.config.params.genesis.hash {
            return Err(ConsensusError::BlockIsGenesis(block_hash));
        }

        // Canonicality: must be a selected-parent-chain block (ancestor of or equal to sink).
        let sink = self.get_sink();
        if !self.services.reachability_service.is_chain_ancestor_of(block_hash, sink) {
            return Err(ConsensusError::BlockNotInSelectedChain(block_hash));
        }

        // Depth: block must be at or after the current pruning point. Blocks before
        // the pruning point may have had their SMT versions pruned.
        let pruning_point = self.pruning_point_store.read().pruning_point().unwrap();
        if !self.services.reachability_service.is_chain_ancestor_of(pruning_point, block_hash) {
            return Err(ConsensusError::BlockTooDeep(block_hash));
        }

        let header = self.headers_store.get_header(block_hash).unwrap();

        // KIP-21 activity_root only exists post-Toccata. Drop the gate after all
        // nets activate.
        if !self.config.params.toccata_activation.is_active(header.daa_score) {
            return Err(ConsensusError::GeneralOwned(format!("toccata is not active at block {block_hash}")));
        }

        let selected_parent = header.post_toccata_chainblock_selected_parent();
        let parent_header = self.headers_store.get_header(selected_parent).unwrap();

        let finality_depth = self.config.params.finality_depth();
        let current_bounds = SmtReadBounds::for_pov(header.blue_score, finality_depth);
        let virtual_processor = self.virtual_processor.clone();
        let is_canonical = |bh| virtual_processor.is_smt_canonical(bh, block_hash);

        let smt_proof = self
            .storage
            .smt_stores
            .prove_lane(&lane_key, current_bounds, is_canonical)
            .map_err(|e| ConsensusError::GeneralOwned(format!("prove_lane: {e}")))?;

        let lane = self
            .storage
            .smt_stores
            .get_lane(lane_key, current_bounds, is_canonical)
            .map(|v| SeqCommitLaneEntry { tip: *v.data(), blue_score: v.blue_score() });

        let metadata =
            self.storage.smt_metadata_store.get(block_hash).map_err(|e| ConsensusError::GeneralOwned(format!("smt_metadata: {e}")))?;

        // Toccata is active (checked above), so the metadata carries a concrete
        // shortcut block. Its header must exist: block_hash was verified to be a
        // chain block between the pruning point and sink, so its shortcut block
        // lies on the chain segment [pp - F, sink] which is not pruned (and we
        // hold the pruning lock read guard). Fold to seq_commit via the virtual
        // processor.
        let inactivity_shortcut_block = metadata.inactivity_shortcut_block();
        let inactivity_shortcut = self.virtual_processor.inactivity_shortcut(inactivity_shortcut_block);

        let parent_seq_commit = parent_header.accepted_id_merkle_root;

        // In debug builds, verify the proof is consistent with the stored lanes_root
        // and that metadata chains to the header's seq_commit.
        debug_assert!({
            use kaspa_hashes::SeqCommitActiveNode;
            use kaspa_seq_commit::{
                hashing::smt_leaf_hash,
                types::SmtLeafInput,
                verify::{SmtMetadata, verify_smt_metadata},
            };
            let lanes_root = self.storage.smt_stores.get_lanes_root(current_bounds, is_canonical);
            let leaf = lane.as_ref().map(|l| smt_leaf_hash(&SmtLeafInput { lane_tip: &l.tip, blue_score: l.blue_score }));
            let computed_root = smt_proof.as_proof().compute_root::<SeqCommitActiveNode>(&lane_key, leaf).unwrap();
            let payload_and_ctx_digest = metadata.payload_and_ctx_digest();
            let md = SmtMetadata {
                lanes_root: &lanes_root,
                payload_and_ctx_digest: &payload_and_ctx_digest,
                parent_seq_commit: &parent_seq_commit,
            };
            computed_root == lanes_root
                && verify_smt_metadata(&md, inactivity_shortcut, header.accepted_id_merkle_root, parent_seq_commit).is_ok()
        });

        Ok(SeqCommitLaneProof {
            smt_proof,
            lane,
            payload_and_ctx_digest: metadata.payload_and_ctx_digest(),
            parent_seq_commit,
            inactivity_shortcut,
        })
    }

    fn get_missing_block_body_hashes(&self, high: Hash) -> ConsensusResult<Vec<Hash>> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(high)?;
        Ok(self.services.sync_manager.get_missing_block_body_hashes(high)?)
    }
    /// Returns the set of blocks in the anticone of the current pruning point
    /// which (may) lack a block body due to being in a transitional state
    /// If not in a transitional state this list is supposed to be empty
    fn get_body_missing_anticone(&self) -> Vec<Hash> {
        self.pruning_meta_stores.read().get_body_missing_anticone()
    }

    fn clear_body_missing_anticone_set(&self) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        let mut batch = rocksdb::WriteBatch::default();
        pruning_meta_write.set_body_missing_anticone(&mut batch, vec![]).unwrap();
        self.db.write(batch).unwrap();
    }

    fn pruning_point(&self) -> Hash {
        self.pruning_point_store.read().pruning_point().unwrap()
    }

    fn create_block_locator_from_pruning_point(&self, high: Hash, limit: usize) -> ConsensusResult<Vec<Hash>> {
        let _guard = self.pruning_lock.blocking_read();
        self.validate_block_exists(high)?;
        // Keep the pruning point read guard throughout building the locator
        let pruning_point_read = self.pruning_point_store.read();
        let pruning_point = pruning_point_read.pruning_point().unwrap();
        Ok(self.services.sync_manager.create_block_locator_from_pruning_point(high, pruning_point, Some(limit))?)
    }

    fn estimate_network_hashes_per_second(&self, start_hash: Option<Hash>, window_size: usize) -> ConsensusResult<u64> {
        let _guard = self.pruning_lock.blocking_read();
        match start_hash {
            Some(hash) => {
                self.validate_block_exists(hash)?;
                let ghostdag_data = self.ghostdag_store.get_data(hash).unwrap();
                // The selected parent header is used within to check for sampling activation, so we verify its existence first
                if !self.headers_store.has(ghostdag_data.selected_parent).unwrap() {
                    return Err(ConsensusError::DifficultyError(DifficultyError::InsufficientWindowData(0)));
                }
                self.estimate_network_hashes_per_second_impl(&ghostdag_data, window_size)
            }
            None => {
                let virtual_state = self.lkg_virtual_state.load();
                self.estimate_network_hashes_per_second_impl(&virtual_state.ghostdag_data, window_size)
            }
        }
    }

    fn are_pruning_points_violating_finality(&self, pp_list: PruningPointsList) -> bool {
        self.virtual_processor.are_pruning_points_violating_finality(pp_list)
    }

    fn creation_timestamp(&self) -> u64 {
        self.creation_timestamp
    }

    fn finality_point(&self) -> Hash {
        self.virtual_processor.virtual_finality_point(&self.lkg_virtual_state.load().ghostdag_data, self.pruning_point())
    }

    /// The utxoset is an additive structure,
    /// to make room for the gradual aggregation of a new utxoset,
    /// first the old one must be cleared.
    /// Likewise, clearing the old utxoset is also a gradual process.
    /// The utxo stable flag guarantees that a full utxoset is never mistaken for
    /// an incomplete or partially deleted one.
    fn clear_pruning_utxo_set(&self) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        let mut batch = rocksdb::WriteBatch::default();
        // Currently under the conditions in which this function is called, this flag should already be false.
        // We lower it down regardless as it is conceptually true to do so.
        pruning_meta_write.set_pruning_utxoset_stable_flag(&mut batch, false).unwrap();
        self.db.write(batch).unwrap();
        pruning_meta_write.utxo_set.clear().unwrap();
    }

    fn clear_pruning_smt_stores(&self) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        let mut batch = rocksdb::WriteBatch::default();
        pruning_meta_write.set_pruning_smt_stable_flag(&mut batch, false).unwrap();
        self.db.write(batch).unwrap();
        self.storage.smt_stores.clear_all();
        self.storage.smt_metadata_store.delete_all().unwrap();
    }

    fn set_pruning_smt_stable_flag(&self, val: bool) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        let mut batch = rocksdb::WriteBatch::default();
        pruning_meta_write.set_pruning_smt_stable_flag(&mut batch, val).unwrap();
        self.db.write(batch).unwrap();
    }

    fn is_pruning_smt_stable(&self) -> bool {
        self.pruning_meta_stores.read().pruning_smt_stable_flag()
    }

    /// The usual flow consists of the pruning point naturally updating during pruning, and hence maintains consistency by default
    /// During pruning catchup, we need to manually update the pruning point and
    /// make sure that consensus looks "as if" it has just moved to a new pruning point.
    fn intrusive_pruning_point_update(&self, new_pruning_point: Hash, syncer_sink: Hash) -> ConsensusResult<()> {
        let pruning_points_to_add = self.get_and_verify_path_to_new_pruning_point(new_pruning_point, syncer_sink)?;

        // If all has gone well, we can finally update pruning point and other stores.
        self.intrusive_pruning_point_store_writes(new_pruning_point, syncer_sink, pruning_points_to_add)
    }

    fn set_pruning_utxoset_stable_flag(&self, val: bool) {
        let mut pruning_meta_write = self.pruning_meta_stores.write();
        let mut batch = rocksdb::WriteBatch::default();

        pruning_meta_write.set_pruning_utxoset_stable_flag(&mut batch, val).unwrap();
        self.db.write(batch).unwrap();
    }

    fn is_pruning_utxoset_stable(&self) -> bool {
        let pruning_meta_read = self.pruning_meta_stores.read();
        pruning_meta_read.pruning_utxoset_stable_flag()
    }

    fn is_pruning_point_anticone_fully_synced(&self) -> bool {
        let pruning_meta_read = self.pruning_meta_stores.read();
        pruning_meta_read.is_anticone_fully_synced()
    }

    fn is_consensus_in_transitional_ibd_state(&self) -> bool {
        let pruning_meta_read = self.pruning_meta_stores.read();
        pruning_meta_read.is_in_transitional_ibd_state()
    }

    fn get_n_last_pruning_points(&self, n: usize) -> Vec<Hash> {
        let (_pruning_point, pruning_index) = self.pruning_point_store.read().pruning_point_and_index().unwrap();
        (0..=pruning_index).rev().take(n).map(|ind| self.past_pruning_points_store.get(ind).unwrap()).collect_vec()
    }
}
