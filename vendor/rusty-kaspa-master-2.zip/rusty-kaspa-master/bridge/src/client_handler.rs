use crate::{
    hasher::{calculate_target, generate_iceriver_job_params, generate_job_header, generate_large_job_params, serialize_block_header},
    jsonrpc_event::JsonRpcEvent,
    mining_state::{GetMiningState, Job, MiningState},
    prom::*,
    share_handler::{KaspaApiTrait, ShareHandler},
    stratum_context::StratumContext,
};
use num_bigint::BigUint;
use num_traits::Zero;
use parking_lot::Mutex;
use regex::Regex;
use std::collections::HashMap;
use std::sync::Arc;
use std::sync::atomic::{AtomicI32, Ordering};
use std::time::{Duration, Instant};
use tracing::{debug, error, warn};

static BIG_JOB_REGEX: once_cell::sync::Lazy<Regex> =
    once_cell::sync::Lazy::new(|| Regex::new(r".*(BzMiner|IceRiverMiner).*").unwrap());

const BALANCE_DELAY: Duration = Duration::from_secs(60);
const CLIENT_TIMEOUT: Duration = Duration::from_secs(20);

static GLOBAL_NEXT_EXTRANONCE: AtomicI32 = AtomicI32::new(0);

pub struct ClientHandler {
    clients: Arc<Mutex<HashMap<i32, Arc<StratumContext>>>>,
    client_counter: AtomicI32,
    min_share_diff: f64,
    _extranonce_size: i8, // Kept for backward compatibility, but now auto-detected per client
    _max_extranonce: i32, // Kept for backward compatibility
    last_template_time: Arc<Mutex<Instant>>,
    last_balance_check: Arc<Mutex<Instant>>,
    share_handler: Arc<ShareHandler>,
    instance_id: String, // Instance identifier for logging
}

impl ClientHandler {
    pub fn new(share_handler: Arc<ShareHandler>, min_share_diff: f64, extranonce_size: i8, instance_id: String) -> Self {
        let max_extranonce = if extranonce_size > 0 { (2_f64.powi(8 * extranonce_size.min(3) as i32) - 1.0) as i32 } else { 0 };

        Self {
            clients: Arc::new(Mutex::new(HashMap::new())),
            client_counter: AtomicI32::new(0),
            min_share_diff,
            _extranonce_size: extranonce_size,
            _max_extranonce: max_extranonce,
            last_template_time: Arc::new(Mutex::new(Instant::now())),
            last_balance_check: Arc::new(Mutex::new(Instant::now())),
            share_handler,
            instance_id,
        }
    }

    pub fn on_connect(&self, ctx: Arc<StratumContext>) {
        let idx = self.client_counter.fetch_add(1, Ordering::Relaxed);

        // Don't assign extranonce here - will be assigned in handle_subscribe based on detected miner type
        // Leave extranonce empty initially
        *ctx.extranonce.lock() = String::new();

        ctx.set_id(idx);
        self.clients.lock().insert(idx, Arc::clone(&ctx));

        debug!(
            "{} [CONNECTION] Client {} connected (ID: {}), extranonce will be assigned after miner type detection",
            self.instance_id, ctx.remote_addr, idx
        );

        // Create stats after 5 seconds (give time for authorize)
        let share_handler = Arc::clone(&self.share_handler);
        let ctx_clone = Arc::clone(&ctx);
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_secs(5)).await;
            if !ctx_clone.wallet_addr.lock().is_empty() {
                share_handler.get_create_stats(&ctx_clone);
            }
        });
    }

    /// Sync Prometheus session metrics for an authorized worker (hashrate/uptime labels).
    pub fn sync_worker_prom_metrics(&self, ctx: &StratumContext) {
        if ctx.wallet_addr.lock().is_empty() {
            return;
        }
        self.share_handler.get_create_stats(ctx);
    }

    /// Assign extranonce to a client based on detected miner type
    /// Called from handle_subscribe after miner type is detected
    pub fn assign_extranonce_for_miner(&self, ctx: &StratumContext, remote_app: &str) {
        use std::sync::atomic::Ordering;

        // Detect miner type and determine required extranonce size
        // Bitmain (GodMiner) requires extranonce_size = 0 (no extranonce)
        // IceRiver, BzMiner, Goldshell require extranonce_size = 2
        let remote_app_lower = remote_app.to_lowercase();
        let is_bitmain =
            remote_app_lower.contains("godminer") || remote_app_lower.contains("bitmain") || remote_app_lower.contains("antminer");

        let required_extranonce_size = if is_bitmain { 0 } else { 2 };

        let extranonce = if required_extranonce_size > 0 {
            // Calculate max extranonce for size 2
            let max_extranonce = (2_f64.powi(16) - 1.0) as i32; // 2 bytes = 16 bits = 65535

            let next = GLOBAL_NEXT_EXTRANONCE
                .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |val| if val < max_extranonce { Some(val + 1) } else { Some(0) });

            if next.is_err() || next.unwrap() >= max_extranonce {
                warn!("wrapped extranonce! new clients may be duplicating work...");
            }

            let extranonce_val = next.unwrap_or(0);
            let extranonce_str = format!("{:0width$x}", extranonce_val, width = (required_extranonce_size * 2) as usize);
            debug!(
                "[AUTO-EXTRANONCE] Assigned extranonce '{}' (value: {}, size: {} bytes) to {} miner '{}'",
                extranonce_str,
                extranonce_val,
                required_extranonce_size,
                if is_bitmain { "Bitmain" } else { "IceRiver/BzMiner/Goldshell" },
                remote_app
            );
            extranonce_str
        } else {
            debug!("[AUTO-EXTRANONCE] Assigned empty extranonce (size: 0 bytes) to Bitmain miner '{}'", remote_app);
            String::new()
        };

        *ctx.extranonce.lock() = extranonce.clone();

        debug!(
            "[AUTO-EXTRANONCE] Client {} extranonce set to '{}' (detected miner: '{}', type: {})",
            ctx.remote_addr,
            extranonce,
            remote_app,
            if is_bitmain { "Bitmain" } else { "IceRiver/BzMiner/Goldshell" }
        );
    }

    pub fn on_disconnect(&self, ctx: &StratumContext) {
        ctx.disconnect();
        let mut clients = self.clients.lock();
        if let Some(id) = ctx.id() {
            debug!("removing client {}", id);
            clients.remove(&id);
            debug!("removed client {}", id);
        }
        let wallet_addr = ctx.wallet_addr.lock().clone();
        let worker_name = ctx.worker_name.lock().clone();
        let remote_app = ctx.remote_app.lock().clone();

        let is_unauthed = wallet_addr.is_empty() && worker_name.is_empty();
        if !is_unauthed {
            record_disconnect(&WorkerContext::from_stratum(&self.instance_id, ctx, &remote_app));
        }
    }

    pub fn disconnect_all(&self) {
        let clients = {
            let guard = self.clients.lock();
            guard.values().cloned().collect::<Vec<_>>()
        };

        for client in clients {
            client.disconnect();
        }

        self.clients.lock().clear();
    }

    /// Send an immediate job to a specific client (for use after authorization)
    /// This ensures IceRiver and other ASICs get a job immediately, not waiting for polling
    pub async fn send_immediate_job_to_client<T: KaspaApiTrait + Send + Sync + ?Sized + 'static>(
        &self,
        client: Arc<StratumContext>,
        kaspa_api: Arc<T>,
    ) {
        // Check if client has wallet address
        let _wallet_addr_str = {
            let wallet_addr = client.wallet_addr.lock();
            if wallet_addr.is_empty() {
                debug!("send_immediate_job: client {} has no wallet address yet, skipping", client.remote_addr);
                return;
            }
            wallet_addr.clone()
        };

        if !client.connected() {
            debug!("send_immediate_job: client {} not connected, skipping", client.remote_addr);
            return;
        }

        let client_clone = Arc::clone(&client);
        let kaspa_api_clone = Arc::clone(&kaspa_api);
        let share_handler = Arc::clone(&self.share_handler);
        let min_diff = self.min_share_diff;
        let instance_id = self.instance_id.clone();

        tokio::spawn(async move {
            // Get per-client mining state from context
            let state = GetMiningState(&client_clone);

            // Get client info
            let (wallet_addr, remote_app, canxium_addr) = {
                let wallet = client_clone.wallet_addr.lock().clone();
                let app = client_clone.remote_app.lock().clone();
                let canx = client_clone.canxium_addr.lock().clone();
                (wallet, app, canx)
            };

            debug!("send_immediate_job: fetching block template for client {} (wallet: {})", client_clone.remote_addr, wallet_addr);

            // Get block template
            let template_result = kaspa_api_clone.get_block_template(&wallet_addr, &remote_app, &canxium_addr).await;

            let block = match template_result {
                Ok(block) => {
                    debug!("send_immediate_job: successfully fetched block template for client {}", client_clone.remote_addr);

                    // === LOG NEW BLOCK TEMPLATE HEADER === (moved to debug level)
                    debug!("=== NEW BLOCK TEMPLATE RECEIVED ===");
                    debug!("  blue_score: {}", block.header.blue_score);
                    debug!("  bits: {} (0x{:08x})", block.header.bits, block.header.bits);
                    debug!("  timestamp: {}", block.header.timestamp);
                    debug!("  version: {}", block.header.version);
                    debug!("  daa_score: {}", block.header.daa_score);

                    // Track and log what changed from previous header
                    if let Some(old_header) = state.get_last_header() {
                        debug!("=== HEADER CHANGES ===");
                        debug!("  blue_score_changed: {}", old_header.blue_score != block.header.blue_score);
                        debug!("    old: {}, new: {}", old_header.blue_score, block.header.blue_score);
                        debug!("  bits_changed: {}", old_header.bits != block.header.bits);
                        debug!("    old: 0x{:08x}, new: 0x{:08x}", old_header.bits, block.header.bits);
                        debug!("  timestamp_changed: {}", old_header.timestamp != block.header.timestamp);
                        debug!("    delta: {} ms", block.header.timestamp - old_header.timestamp);
                        debug!("  daa_score_changed: {}", old_header.daa_score != block.header.daa_score);
                        debug!("  version_changed: {}", old_header.version != block.header.version);
                    } else {
                        debug!("=== FIRST HEADER === (no previous header to compare)");
                    }

                    // Store this header for next comparison
                    state.set_last_header((*block.header).clone());

                    block
                }
                Err(e) => {
                    if e.to_string().contains("Could not decode address") {
                        record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::InvalidAddressFmt.as_str());
                        error!("send_immediate_job: failed fetching block template, malformed address: {}", e);
                        client_clone.disconnect();
                    } else {
                        record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::FailedBlockFetch.as_str());
                        error!("send_immediate_job: failed fetching block template: {}", e);
                    }
                    return;
                }
            };

            // Calculate target
            let big_diff = calculate_target(block.header.bits as u64);
            state.set_big_diff(big_diff);

            // Serialize header - now returns Hash type directly
            // The "Odd number of digits" error typically indicates a malformed hex string
            // in one of the hash fields. This can happen if the block data from the node
            // contains an invalid hash representation.
            let pre_pow_hash = match serialize_block_header(&block) {
                Ok(h) => h,
                Err(e) => {
                    let error_msg = e.to_string();
                    record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::BadDataFromMiner.as_str());
                    error!("send_immediate_job: failed to serialize block header: {}", error_msg);

                    // Log block header details for debugging
                    debug!("Block header version: {}", block.header.version);
                    debug!("Block header timestamp: {}", block.header.timestamp);
                    debug!("Block header bits: {}", block.header.bits);

                    // Skip this block and continue - the next block template should work
                    return;
                }
            };

            // Create Job struct with both block and pre_pow_hash
            let job = Job { block: block.clone(), pre_pow_hash };

            // Add job
            let job_id = state.add_job(job);
            let counter_after = state.current_job_counter();
            let stored_ids = state.get_stored_job_ids();
            debug!(
                "[JOB CREATION] send_immediate_job: created job ID {} for client {} (counter: {}, stored IDs: {:?})",
                job_id, client_clone.remote_addr, counter_after, stored_ids
            );

            // Initialize state if first time
            if !state.is_initialized() {
                state.set_initialized(true);
                let use_big_job = BIG_JOB_REGEX.is_match(&remote_app);
                state.set_use_big_job(use_big_job);

                // Initialize stratum diff
                use crate::hasher::KaspaDiff;
                let mut stratum_diff = KaspaDiff::new();
                let remote_app_clone = remote_app.clone();
                stratum_diff.set_diff_value_for_miner(min_diff, &remote_app_clone);
                state.set_stratum_diff(stratum_diff);

                update_worker_difficulty(&WorkerContext::from_stratum(&instance_id, &client_clone, &remote_app_clone), min_diff);

                let target = state.stratum_diff().map(|d| d.target_value.clone()).unwrap_or_else(BigUint::zero);
                let target_bytes = target.to_bytes_be();
                debug!(
                    "send_immediate_job: Initialized MiningState with difficulty: {}, target: {:x} ({} bytes, {} bits)",
                    min_diff,
                    target,
                    target_bytes.len(),
                    target_bytes.len() * 8
                );
            }

            // CRITICAL: Always send difficulty to each client (IceRiver expects this on every connection)
            // Even if state is already initialized, we need to send difficulty to this specific client
            // Use the actual current difficulty from state if available, otherwise use min_diff
            let current_diff = state.stratum_diff().map(|d| d.diff_value).unwrap_or(min_diff);

            // Update metric to ensure displayed difficulty matches what we're sending
            // (This handles the case where state was already initialized but metric wasn't updated)
            update_worker_difficulty(&WorkerContext::from_stratum(&instance_id, &client_clone, &remote_app), current_diff);

            debug!("[DIFFICULTY] ===== SENDING DIFFICULTY TO {} =====", client_clone.remote_addr);
            debug!("[DIFFICULTY] Difficulty value: {} (from state: {})", current_diff, state.stratum_diff().is_some());
            send_client_diff(&instance_id, &client_clone, &state, current_diff);
            share_handler.set_client_vardiff(&client_clone, min_diff);
            debug!("[DIFFICULTY] ===== DIFFICULTY SENT TO {} =====", client_clone.remote_addr);

            // Small delay to ensure difficulty is sent before job
            tokio::time::sleep(Duration::from_millis(100)).await;

            // Build job params - check if this is an IceRiver or Bitmain miner
            let remote_app_lower = remote_app.to_lowercase();
            let is_iceriver =
                remote_app_lower.contains("iceriver") || remote_app_lower.contains("icemining") || remote_app_lower.contains("icm");
            let is_bitmain =
                remote_app_lower.contains("godminer") || remote_app_lower.contains("bitmain") || remote_app_lower.contains("antminer");

            debug!("[JOB] ===== BUILDING JOB FOR {} =====", client_clone.remote_addr);
            debug!("[JOB] Job ID: {}", job_id);
            debug!("[JOB] Remote app: '{}'", remote_app);
            debug!("[JOB] Is IceRiver: {}, Is Bitmain: {}, use_big_job: {}", is_iceriver, is_bitmain, state.use_big_job());
            debug!("[JOB] Pre-PoW hash: {}", pre_pow_hash);
            debug!("[JOB] Block timestamp: {}", block.header.timestamp);

            let mut job_params = vec![serde_json::Value::String(job_id.to_string())];
            debug!("[JOB] Job params initialized with job_id: {}", job_id);
            if state.use_big_job() && !is_iceriver {
                // BzMiner format - single hex string (big endian hash)
                // Convert Hash to bytes for BzMiner format
                debug!("[JOB] Generating BzMiner format job params");
                let header_bytes = pre_pow_hash.as_bytes();
                let large_params = generate_large_job_params(&header_bytes, block.header.timestamp);
                debug!("[JOB] BzMiner job_data length: {} (expected 80)", large_params.len());
                debug!("[JOB] BzMiner job_data (first 20 chars): {}", &large_params[..large_params.len().min(20)]);
                debug!("[JOB] BzMiner job_data (full): {}", large_params);
                job_params.push(serde_json::Value::String(large_params));
            } else if is_iceriver {
                // IceRiver format - single hex string (uses Hash::to_string() to match working stratum code)
                // This matches Ghostpool and other working implementations
                debug!("[JOB] Generating IceRiver format job params");
                let iceriver_params = generate_iceriver_job_params(&pre_pow_hash, block.header.timestamp);
                debug!("[JOB] IceRiver job_data length: {} (expected 80)", iceriver_params.len());
                debug!("[JOB] IceRiver job_data (first 20 chars): {}", &iceriver_params[..iceriver_params.len().min(20)]);
                debug!("[JOB] IceRiver job_data (full): {}", iceriver_params);
                job_params.push(serde_json::Value::String(iceriver_params));
            } else {
                // Legacy format - array + number (for Bitmain and other miners)
                let header_bytes = pre_pow_hash.as_bytes();
                let job_header = generate_job_header(&header_bytes);
                debug!("send_immediate_job: using Legacy format, array size: {}", job_header.len());
                job_params.push(serde_json::Value::Array(job_header.iter().map(|&v| serde_json::Value::Number(v.into())).collect()));
                job_params.push(serde_json::Value::Number(block.header.timestamp.into()));
            }

            debug!("[JOB] ===== SENDING MINING.NOTIFY TO {} =====", client_clone.remote_addr);
            debug!("[JOB] Method: mining.notify");
            debug!("[JOB] Params count: {}", job_params.len());

            // Also log the raw job data for verification
            if let Some(serde_json::Value::String(job_data)) = job_params.get(1) {
                debug!("[JOB] Job data string length: {} chars", job_data.len());
                if job_data.len() == 80 {
                    let hash_part = &job_data[..64];
                    let timestamp_part = &job_data[64..];
                    debug!("[JOB] Hash part (64 hex): {}", hash_part);
                    debug!("[JOB] Timestamp part (16 hex): {}", timestamp_part);
                    debug!("[JOB] Full job_data: {}", job_data);
                } else {
                    let expected_for = if is_iceriver {
                        "IceRiver"
                    } else if is_bitmain {
                        "Bitmain"
                    } else {
                        "standard"
                    };
                    warn!("[JOB] WARNING - job_data length is {} (expected 80 for {})", job_data.len(), expected_for);
                }
            }

            let format_name = if is_iceriver {
                "IceRiver"
            } else if state.use_big_job() {
                "BzMiner"
            } else {
                "Legacy"
            };
            debug!(
                "[JOB] Sending job ID {} to {} (format: {}, params: {})",
                job_id,
                client_clone.remote_addr,
                format_name,
                job_params.len()
            );

            // IceRiver expects minimal notification format (method + params only, no id or jsonrpc)
            // Send job ID in mining.notify
            let send_result = if is_iceriver {
                // IceRiver expects minimal notification format (method + params only, no id or jsonrpc)
                client_clone.send_notification("mining.notify", job_params.clone()).await
            } else {
                // For non-IceRiver, use standard JSON-RPC format with job ID
                let notify_event = JsonRpcEvent {
                    jsonrpc: "2.0".to_string(),
                    method: "mining.notify".to_string(),
                    id: Some(serde_json::Value::Number(job_id.into())),
                    params: job_params.clone(),
                };
                client_clone.send(notify_event).await
            };

            if let Err(e) = send_result {
                if e.to_string().contains("disconnected") {
                    record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::Disconnected.as_str());
                    error!("[JOB] ERROR: Failed to send job {} - client disconnected", job_id);
                } else {
                    record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::FailedSendWork.as_str());
                    error!("[JOB] ERROR: Failed sending work packet {}: {}", job_id, e);
                }
                debug!("[JOB] ===== JOB SEND FAILED FOR {} =====", client_clone.remote_addr);
            } else {
                record_new_job(&WorkerContext::from_stratum(&instance_id, &client_clone, ""));
                debug!("[JOB] Successfully sent job ID {} to client {}", job_id, client_clone.remote_addr);
                debug!("[JOB] ===== JOB SENT SUCCESSFULLY TO {} =====", client_clone.remote_addr);
            }
        });
    }

    pub async fn new_block_available<T: KaspaApiTrait + Send + Sync + 'static>(&self, kaspa_api: Arc<T>) {
        // Rate limit templates (250ms minimum between sends)
        {
            let mut last_time = self.last_template_time.lock();
            if last_time.elapsed() < Duration::from_millis(250) {
                return;
            }
            *last_time = Instant::now();
        }

        let clients = {
            let clients_guard = self.clients.lock();
            clients_guard.values().cloned().collect::<Vec<_>>()
        };

        // Collect addresses for balance checking
        let mut addresses: Vec<String> = Vec::new();
        let mut client_count = 0;

        for client in clients {
            if !client.connected() {
                continue;
            }

            if client_count > 0 {
                tokio::time::sleep(Duration::from_micros(500)).await;
            }
            client_count += 1;

            // Collect wallet address for balance checking
            {
                let wallet_addr = client.wallet_addr.lock();
                if !wallet_addr.is_empty() {
                    addresses.push(wallet_addr.clone());
                }
            }

            let client_clone = Arc::clone(&client);
            let kaspa_api_clone = Arc::clone(&kaspa_api);
            let share_handler = Arc::clone(&self.share_handler);
            let min_diff = self.min_share_diff;
            let instance_id = self.instance_id.clone();

            tokio::spawn(async move {
                // Get per-client mining state from context
                let state = GetMiningState(&client_clone);

                // Check if client has wallet address
                let wallet_addr_str = {
                    let wallet_addr = client_clone.wallet_addr.lock();
                    if wallet_addr.is_empty() {
                        let connect_time = state.connect_time();
                        if let Ok(elapsed) = connect_time.elapsed()
                            && elapsed > CLIENT_TIMEOUT
                        {
                            warn!("client misconfigured, no miner address specified - disconnecting");
                            let wallet_str = wallet_addr.clone();
                            record_worker_error(&instance_id, &wallet_str, crate::errors::ErrorShortCode::NoMinerAddress.as_str());
                            drop(wallet_addr); // Drop before disconnect
                            client_clone.disconnect();
                        }
                        debug!("new_block_available: client {} has no wallet address yet, skipping", client_clone.remote_addr);
                        return;
                    }
                    wallet_addr.clone()
                };

                debug!(
                    "new_block_available: fetching block template for client {} (wallet: {})",
                    client_clone.remote_addr, wallet_addr_str
                );

                // Get block template
                let (wallet_addr, remote_app, canxium_addr) = {
                    let wallet = client_clone.wallet_addr.lock().clone();
                    let app = client_clone.remote_app.lock().clone();
                    let canx = client_clone.canxium_addr.lock().clone();
                    (wallet, app, canx)
                };

                let template_result = kaspa_api_clone.get_block_template(&wallet_addr, &remote_app, &canxium_addr).await;

                let block = match template_result {
                    Ok(block) => {
                        debug!("new_block_available: successfully fetched block template for client {}", client_clone.remote_addr);
                        block
                    }
                    Err(e) => {
                        if e.to_string().contains("Could not decode address") {
                            record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::InvalidAddressFmt.as_str());
                            error!("failed fetching new block template from kaspa, malformed address: {}", e);
                            client_clone.disconnect();
                        } else {
                            record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::FailedBlockFetch.as_str());
                            error!("failed fetching new block template from kaspa: {}", e);
                        }
                        return;
                    }
                };

                // Calculate target
                let big_diff = calculate_target(block.header.bits as u64);
                state.set_big_diff(big_diff);

                // Serialize header - now returns Hash type directly
                // The "Odd number of digits" error typically indicates a malformed hex string
                // in one of the hash fields. This can happen if the block data from the node
                // contains an invalid hash representation.
                let pre_pow_hash = match serialize_block_header(&block) {
                    Ok(h) => h,
                    Err(e) => {
                        let error_msg = e.to_string();
                        record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::BadDataFromMiner.as_str());
                        error!("failed to serialize block header: {}", error_msg);

                        // Log block header details for debugging
                        debug!("Block header version: {}", block.header.version);
                        debug!("Block header timestamp: {}", block.header.timestamp);
                        debug!("Block header bits: {}", block.header.bits);
                        debug!("Block header daa_score: {}", block.header.daa_score);
                        debug!("Block header blue_score: {}", block.header.blue_score);
                        debug!("Block header parents_by_level expanded_len: {}", block.header.parents_by_level.expanded_len());

                        // Skip this block and continue - the next block template should work
                        return;
                    }
                };

                // Create Job struct with both block and pre_pow_hash
                let job = Job { block: block.clone(), pre_pow_hash };

                // Add job
                let job_id = state.add_job(job);
                let counter_after = state.current_job_counter();
                let stored_ids = state.get_stored_job_ids();
                debug!(
                    "[JOB CREATION] new_block_available: created job ID {} for client {} (counter: {}, stored IDs: {:?})",
                    job_id, client_clone.remote_addr, counter_after, stored_ids
                );

                // Initialize state if first time (per-client state initialization)
                if !state.is_initialized() {
                    state.set_initialized(true);
                    let use_big_job = BIG_JOB_REGEX.is_match(&remote_app);
                    state.set_use_big_job(use_big_job);

                    // Send initial difficulty
                    use crate::hasher::KaspaDiff;
                    let mut stratum_diff = KaspaDiff::new();
                    // Use miner-specific calculation (IceRiver uses different formula)
                    let remote_app = client_clone.remote_app.lock().clone();
                    stratum_diff.set_diff_value_for_miner(min_diff, &remote_app);
                    state.set_stratum_diff(stratum_diff);

                    update_worker_difficulty(&WorkerContext::from_stratum(&instance_id, &client_clone, &remote_app), min_diff);

                    let target = state.stratum_diff().map(|d| d.target_value.clone()).unwrap_or_else(BigUint::zero);
                    let target_bytes = target.to_bytes_be();
                    debug!(
                        "Initialized per-client MiningState with difficulty: {}, target: {:x} ({} bytes, {} bits)",
                        min_diff,
                        target,
                        target_bytes.len(),
                        target_bytes.len() * 8
                    );
                    send_client_diff(&instance_id, &client_clone, &state, min_diff);
                    share_handler.set_client_vardiff(&client_clone, min_diff);
                } else {
                    // Check for vardiff update
                    if let Some(mut stratum_diff) = state.stratum_diff() {
                        let current_diff = stratum_diff.diff_value;
                        let mut var_diff = share_handler.get_client_vardiff(&client_clone);

                        // Recover from stale/recreated stats entries that can report 0.0 diff.
                        // Seed back to current state diff so UI/terminal does not stick at zero.
                        if var_diff <= 0.0 && current_diff > 0.0 {
                            share_handler.set_client_vardiff(&client_clone, current_diff);
                            share_handler.start_client_vardiff(&client_clone);
                            var_diff = current_diff;
                        }

                        if var_diff != current_diff {
                            debug!("changing diff from {} to {}", current_diff, var_diff);
                            // Use miner-specific calculation (IceRiver uses different formula)
                            let remote_app = client_clone.remote_app.lock().clone();
                            stratum_diff.set_diff_value_for_miner(var_diff, &remote_app);
                            state.set_stratum_diff(stratum_diff);

                            update_worker_difficulty(&WorkerContext::from_stratum(&instance_id, &client_clone, &remote_app), var_diff);

                            send_client_diff(&instance_id, &client_clone, &state, var_diff);
                            share_handler.start_client_vardiff(&client_clone);
                        }
                    }
                }

                // Build job params
                // Check if this is an IceRiver or Bitmain miner - they need single hex string format
                let remote_app = client_clone.remote_app.lock().clone();
                let remote_app_lower = remote_app.to_lowercase();
                let is_iceriver = remote_app_lower.contains("iceriver")
                    || remote_app_lower.contains("icemining")
                    || remote_app_lower.contains("icm");
                let is_bitmain = remote_app_lower.contains("godminer")
                    || remote_app_lower.contains("bitmain")
                    || remote_app_lower.contains("antminer");

                debug!(
                    "[JOB] new_block_available: client {}, is_iceriver: {}, is_bitmain: {}, use_big_job: {}",
                    client_clone.remote_addr,
                    is_iceriver,
                    is_bitmain,
                    state.use_big_job()
                );

                let mut job_params = vec![serde_json::Value::String(job_id.to_string())];
                if is_iceriver {
                    // IceRiver format - single hex string (uses Hash::to_string() to match working stratum code)
                    // This matches Ghostpool and other working implementations
                    debug!("[JOB] new_block_available: Generating IceRiver format job params");
                    let iceriver_params = generate_iceriver_job_params(&pre_pow_hash, block.header.timestamp);
                    debug!("[JOB] new_block_available: IceRiver job_data length: {} (expected 80)", iceriver_params.len());
                    job_params.push(serde_json::Value::String(iceriver_params));
                } else if state.use_big_job() && !is_iceriver {
                    // BzMiner format - single hex string (big endian hash)
                    // Convert Hash to bytes for BzMiner format
                    debug!("[JOB] new_block_available: Generating BzMiner format job params");
                    let header_bytes = pre_pow_hash.as_bytes();
                    let large_params = generate_large_job_params(&header_bytes, block.header.timestamp);
                    debug!("[JOB] new_block_available: BzMiner job_data length: {} (expected 80)", large_params.len());
                    job_params.push(serde_json::Value::String(large_params));
                } else {
                    // Legacy format - array + number (for Bitmain and other miners)
                    debug!("[JOB] new_block_available: Using Legacy format (array + timestamp)");
                    let header_bytes = pre_pow_hash.as_bytes();
                    let job_header = generate_job_header(&header_bytes);
                    job_params
                        .push(serde_json::Value::Array(job_header.iter().map(|&v| serde_json::Value::Number(v.into())).collect()));
                    job_params.push(serde_json::Value::Number(block.header.timestamp.into()));
                }

                // IceRiver expects minimal notification format (method + params only, no id or jsonrpc)
                // This matches StratumNotification format used by the stratum crate
                let is_iceriver_client = {
                    let remote_app = client_clone.remote_app.lock();
                    remote_app.contains("IceRiver")
                };
                let is_bitmain_client = {
                    let remote_app = client_clone.remote_app.lock();
                    let remote_app_lower = remote_app.to_lowercase();
                    remote_app_lower.contains("godminer")
                        || remote_app_lower.contains("bitmain")
                        || remote_app_lower.contains("antminer")
                };

                debug!(
                    "new_block_available: sending job ID {} to client {} (params count: {}, is_iceriver: {}, is_bitmain: {})",
                    job_id,
                    client_clone.remote_addr,
                    job_params.len(),
                    is_iceriver_client,
                    is_bitmain_client
                );

                // Send job ID in mining.notify
                // })
                let send_result = if is_iceriver_client {
                    // IceRiver expects minimal notification format (method + params only, no id or jsonrpc)
                    client_clone.send_notification("mining.notify", job_params.clone()).await
                } else {
                    // For non-IceRiver, use standard JSON-RPC format with job ID
                    let notify_event = JsonRpcEvent {
                        jsonrpc: "2.0".to_string(),
                        method: "mining.notify".to_string(),
                        id: Some(serde_json::Value::Number(job_id.into())),
                        params: job_params.clone(),
                    };
                    client_clone.send(notify_event).await
                };

                if let Err(e) = send_result {
                    if e.to_string().contains("disconnected") {
                        record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::Disconnected.as_str());
                        warn!("new_block_available: failed to send job {} - client disconnected", job_id);
                    } else {
                        record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::FailedSendWork.as_str());
                        error!("failed sending work packet {}: {}", job_id, e);
                        error!("new_block_available: failed to send job {} to client {}: {}", job_id, client_clone.remote_addr, e);
                    }
                } else {
                    record_new_job(&WorkerContext::from_stratum(&instance_id, &client_clone, ""));
                    debug!("new_block_available: successfully sent job ID {} to client {}", job_id, client_clone.remote_addr);
                }
            });
        }

        // Check balances periodically
        {
            let mut last_check = self.last_balance_check.lock();
            if last_check.elapsed() > BALANCE_DELAY && !addresses.is_empty() {
                *last_check = Instant::now();
                drop(last_check);

                // Fetch balances via kaspa_api
                let addresses_clone = addresses.clone();
                let kaspa_api_clone = Arc::clone(&kaspa_api);
                let instance_id = self.instance_id.clone();
                tokio::spawn(async move {
                    match kaspa_api_clone.get_balances_by_addresses(&addresses_clone).await {
                        Ok(balances) => {
                            // Record balances
                            crate::prom::record_balances(&instance_id, &balances);
                        }
                        Err(e) => {
                            warn!("failed to get balances from kaspa, prom stats will be out of date: {}", e);
                        }
                    }
                });
            }
        }
    }
}

// Send difficulty update to client
fn send_client_diff(instance_id: &str, client: &StratumContext, _state: &MiningState, diff: f64) {
    debug!("[DIFFICULTY] Building difficulty message for {}", client.remote_addr);

    let instance_id = instance_id.to_string();

    // Send diffValue directly as a number
    let diff_value =
        serde_json::Value::Number(serde_json::Number::from_f64(diff).unwrap_or_else(|| serde_json::Number::from(diff as u64)));

    let client_clone = client.clone();
    tokio::spawn(async move {
        debug!("[DIFFICULTY] Sending mining.set_difficulty to {}", client_clone.remote_addr);

        // Always use standard JSON-RPC format
        let diff_event = JsonRpcEvent {
            jsonrpc: "2.0".to_string(),
            method: "mining.set_difficulty".to_string(),
            id: None, // Go doesn't send ID for set_difficulty
            params: vec![diff_value],
        };

        let send_result = client_clone.send(diff_event).await;

        if let Err(e) = send_result {
            let wallet_addr = client_clone.wallet_addr.lock().clone();
            record_worker_error(&instance_id, &wallet_addr, crate::errors::ErrorShortCode::FailedSetDiff.as_str());
            error!("[DIFFICULTY] ERROR: Failed sending difficulty: {}", e);
            return;
        }
        debug!("[DIFFICULTY] Successfully sent difficulty {} to {}", diff, client_clone.remote_addr);
    });
}
