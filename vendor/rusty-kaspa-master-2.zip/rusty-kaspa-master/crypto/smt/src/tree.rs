//! Sparse Merkle Tree with Suffix-Only Leaf (SLO) optimization.
//!
//! # Two APIs
//!
//! - **In-memory** (`SparseMerkleTree<H, BTreeSmtStore>`): mutable `insert`/`remove`/`prove`.
//!   Used in tests and for RPC proof generation.
//!
//! - **Pure computation** ([`compute_root_update`]): top-down recursive algorithm that
//!   reads from an immutable `&impl SmtStore` and returns `(new_root, changed_nodes)`.
//!   Single-leaf subtrees are collapsed into one node instead of 256 branches.
//!   Used by consensus (`SmtProcessor::build`).

use alloc::collections::BTreeMap;
use alloc::vec::Vec;

use core::marker::PhantomData;
use kaspa_hashes::Hash;

use crate::proof::{OwnedSmtProof, ProofTerminal};
use crate::store::{BTreeSmtStore, BranchKey, CollapsedLeaf, LeafUpdate, Node, SmtStore, SortedLeafUpdates, SortedLeafUpdatesRef};
use crate::{DEPTH, SmtHasher, bit_at, hash_node};

/// A 256-bit Sparse Merkle Tree with incremental updates and cached root.
///
/// Generic over:
/// - `H`: internal node hasher (e.g., `SeqCommitActiveNode`)
/// - `S`: storage backend (default: [`BTreeSmtStore`])
pub struct SparseMerkleTree<H: SmtHasher, S: SmtStore = BTreeSmtStore> {
    store: S,
    root: Hash,
    _phantom: PhantomData<H>,
}

impl<H: SmtHasher> SparseMerkleTree<H, BTreeSmtStore> {
    /// Create a new empty sparse Merkle tree with the default in-memory store.
    pub fn new() -> Self {
        Self { store: BTreeSmtStore::new(), root: H::EMPTY_HASHES[DEPTH], _phantom: PhantomData }
    }
}

impl<H: SmtHasher> Default for SparseMerkleTree<H, BTreeSmtStore> {
    fn default() -> Self {
        Self::new()
    }
}

impl<H: SmtHasher, S: SmtStore> SparseMerkleTree<H, S> {
    /// Create a sparse Merkle tree from an existing store and root hash.
    pub fn from_root(store: S, root: Hash) -> Self {
        Self { store, root, _phantom: PhantomData }
    }

    /// Create a new empty sparse Merkle tree with a custom store.
    pub fn with_store(store: S) -> Self {
        Self { store, root: H::EMPTY_HASHES[DEPTH], _phantom: PhantomData }
    }

    /// Consume the tree and return the underlying store.
    pub fn into_store(self) -> S {
        self.store
    }

    /// Return the current root hash (cached, O(1)).
    pub fn root(&self) -> Hash {
        self.root
    }

    /// Generate an inclusion or non-inclusion proof for the given key.
    ///
    /// Walks from root to leaf reading stored branch nodes.
    /// Handles both `Internal` and `Collapsed` (SLO) nodes.
    pub fn prove(&self, key: &Hash) -> Result<OwnedSmtProof, S::Error> {
        let mut bitmap = [0u8; 32];
        let mut siblings = Vec::new();
        let mut terminal = ProofTerminal::Full;

        for depth in 0..DEPTH {
            let branch_key = BranchKey::new(depth as u8, key);
            let goes_right = bit_at(key, depth);

            match self.store.get_node(&branch_key)? {
                Some(Node::Internal(_)) => {
                    if depth == DEPTH - 1 {
                        // Leaf-parent (depth 255): children are leaves, not branch nodes.
                        // Use get_leaf instead of child_branch_key to avoid depth+1 overflow.
                        // Compute sibling key (differs only in the last bit).
                        let mut sib_bytes = key.as_bytes();
                        sib_bytes[depth / 8] ^= 0x80 >> (depth % 8);
                        let sibling_leaf_key = Hash::from_bytes(sib_bytes);
                        match self.store.get_leaf(&sibling_leaf_key)? {
                            None => {
                                bitmap[depth / 8] |= 1 << (depth % 8);
                            }
                            Some(leaf_hash) => {
                                siblings.push(hash_node::<H::CollapsedHasher>(sibling_leaf_key, leaf_hash));
                            }
                        }
                    } else {
                        // Read the sibling node directly.
                        let sibling_key = child_branch_key(&branch_key, !goes_right, depth);
                        match self.store.get_node(&sibling_key)? {
                            None => {
                                bitmap[depth / 8] |= 1 << (depth % 8);
                            }
                            Some(Node::Internal(hash)) => {
                                siblings.push(hash);
                            }
                            Some(Node::Collapsed(cl)) => {
                                siblings.push(hash_node::<H::CollapsedHasher>(cl.lane_key, cl.leaf_hash));
                            }
                        }
                    }
                }
                Some(Node::Collapsed(cl)) => {
                    if cl.lane_key == *key {
                        for d in depth..DEPTH {
                            bitmap[d / 8] |= 1 << (d % 8);
                        }
                        terminal = ProofTerminal::Collapsed { depth: depth as u8 };
                        break;
                    }
                    for d in depth..DEPTH {
                        bitmap[d / 8] |= 1 << (d % 8);
                    }
                    terminal = ProofTerminal::CollapsedOther { depth: depth as u8, leaf: cl };
                    break;
                }
                None => {
                    for d in depth..DEPTH {
                        bitmap[d / 8] |= 1 << (d % 8);
                    }
                    break;
                }
            }
        }

        Ok(OwnedSmtProof { bitmap, siblings, terminal })
    }
}

#[allow(clippy::len_without_is_empty)]
impl<H: SmtHasher> SparseMerkleTree<H, BTreeSmtStore> {
    /// Number of non-empty leaves.
    pub fn len(&self) -> usize {
        self.store.leaf_count()
    }

    /// Whether the tree has no leaves.
    pub fn is_empty(&self) -> bool {
        self.store.is_empty()
    }

    /// Look up the leaf hash for a key, or `None` if absent.
    pub fn get(&self, key: &Hash) -> Option<Hash> {
        self.store.get_leaf(key)
    }

    /// Check whether a key is present in the tree.
    pub fn contains_key(&self, key: &Hash) -> bool {
        self.store.get_leaf(key).is_some()
    }

    #[cfg(any(test, feature = "test-utils"))]
    /// Insert or update a leaf, incrementally updating the root via SLO.
    pub fn insert(&mut self, key: Hash, leaf_hash: Hash) {
        self.store.insert_leaf(key, leaf_hash);
        let sorted = SortedLeafUpdates::from_unsorted(core::iter::once(LeafUpdate { key, leaf_hash }));
        let (new_root, changes) = compute_root_update::<H, _>(&self.store, self.root, sorted).unwrap();
        for (bk, node) in &changes {
            self.store.insert_node(*bk, *node);
        }
        self.root = new_root;
    }

    #[cfg(any(test, feature = "test-utils"))]
    /// Remove a leaf by key, incrementally updating the root via SLO.
    pub fn remove(&mut self, key: &Hash) -> Option<Hash> {
        use kaspa_hashes::ZERO_HASH;
        let old = self.store.get_leaf(key);
        if old.is_some() {
            let sorted = SortedLeafUpdates::from_unsorted(core::iter::once(LeafUpdate { key: *key, leaf_hash: ZERO_HASH }));
            let (new_root, changes) = compute_root_update::<H, _>(&self.store, self.root, sorted).unwrap();
            for (bk, node) in &changes {
                self.store.insert_node(*bk, *node);
            }
            self.root = new_root;
            self.store.insert_leaf(*key, ZERO_HASH);
        }
        old
    }
}

/// Map of changed nodes: `BranchKey → Option<Node>`.
///
/// `None` means "this node was deleted".
pub type SmtNodeChanges = BTreeMap<BranchKey, Option<Node>>;

/// Result of computing a subtree — propagated upward during recursion.
enum NodeResult {
    /// Subtree is empty (no leaves).
    Empty,
    /// Subtree contains exactly one leaf (collapsed).
    Collapsed(CollapsedLeaf),
    /// Subtree contains two or more leaves (standard internal).
    Internal { hash: Hash },
}

impl NodeResult {
    /// Compute the hash this node contributes to its parent at the given `parent_depth`.
    ///
    /// Indexes `EMPTY_HASHES[DEPTH - 1 - parent_depth]`: safe because
    /// `parent_depth` ranges from 0 (root) to `DEPTH - 1` (leaf-parent),
    /// yielding indices 255..=0, all within the 257-element array.
    fn hash<H: SmtHasher>(&self, parent_depth: usize) -> Hash {
        match self {
            NodeResult::Empty => H::EMPTY_HASHES[DEPTH - 1 - parent_depth],
            NodeResult::Collapsed(cl) => hash_node::<H::CollapsedHasher>(cl.lane_key, cl.leaf_hash),
            NodeResult::Internal { hash } => *hash,
        }
    }
}

/// Compute the new SMT root and **only the changed nodes** for a set of leaf updates.
///
/// Uses top-down recursion with Suffix-Only Leaf (SLO) optimization:
/// collapsed single-leaf subtrees are represented as a single node instead of
/// a full 256-level branch chain, cutting writes from O(256) to O(1) per lone leaf.
///
/// Reads from an immutable `&impl SmtStore`. Does not mutate any state.
/// Returns `(new_root, changed_nodes)`.
pub fn compute_root_update<H: SmtHasher, S: SmtStore>(
    store: &S,
    current_root: Hash,
    leaf_updates: SortedLeafUpdates,
) -> Result<(Hash, SmtNodeChanges), S::Error> {
    let mut changes = SmtNodeChanges::new();
    let root = compute_root_update_into::<H, S>(store, current_root, leaf_updates, &mut changes)?;
    Ok((root, changes))
}

/// Like [`compute_root_update`] but writes into an externally-owned node map.
///
/// Pre-populated entries act as a proof cache: the local buffer is checked
/// before the immutable store.
pub fn compute_root_update_into<H: SmtHasher, S: SmtStore>(
    store: &S,
    current_root: Hash,
    leaf_updates: SortedLeafUpdates,
    changes: &mut SmtNodeChanges,
) -> Result<Hash, S::Error> {
    if leaf_updates.is_empty() {
        return Ok(current_root);
    }

    let result = compute_subtree::<H, S>(store, changes, leaf_updates.as_ref(), 0)?;

    // Convert the root-level NodeResult to a root hash
    match &result {
        NodeResult::Empty => Ok(H::empty_root()),
        NodeResult::Collapsed(cl) => Ok(hash_node::<H::CollapsedHasher>(cl.lane_key, cl.leaf_hash)),
        NodeResult::Internal { hash } => Ok(*hash),
    }
}

/// Read a node from the changes map first, then the store.
fn read_node<S: SmtStore>(store: &S, changes: &SmtNodeChanges, bk: &BranchKey) -> Result<Option<Node>, S::Error> {
    if let Some(&nk) = changes.get(bk) {
        return Ok(nk);
    }
    store.get_node(bk)
}

/// Compute the BranchKey for a child of `parent` on the given side.
///
/// # Overflow safety
/// `parent.depth + 1` is safe because this is never called at the leaf-parent
/// level (depth 255). In `prove()`, depth 255 is handled via `get_leaf` instead.
/// In `compute_subtree`, depth 255 is handled by the `depth == DEPTH - 1` early return.
fn child_branch_key(parent: &BranchKey, right: bool, depth: usize) -> BranchKey {
    debug_assert!(parent.depth < 255, "child_branch_key called at leaf-parent level");
    let child_depth = parent.depth + 1;
    let mut bytes = parent.node_key.as_bytes();
    if right {
        bytes[depth / 8] |= 0x80 >> (depth % 8);
    }
    BranchKey { depth: child_depth, node_key: Hash::from_bytes(bytes) }
}

fn leaf_result(update: Option<&LeafUpdate>) -> NodeResult {
    match update {
        Some(u) if u.leaf_hash != kaspa_hashes::ZERO_HASH => {
            NodeResult::Collapsed(CollapsedLeaf { lane_key: u.key, leaf_hash: u.leaf_hash })
        }
        _ => NodeResult::Empty,
    }
}

fn merged_node<H: SmtHasher>(left: &NodeResult, right: &NodeResult, depth: usize) -> (NodeResult, Option<Node>) {
    let result = match (left, right) {
        (NodeResult::Empty, NodeResult::Empty) => NodeResult::Empty,
        (NodeResult::Collapsed(cl), NodeResult::Empty) | (NodeResult::Empty, NodeResult::Collapsed(cl)) => NodeResult::Collapsed(*cl),
        _ => {
            let hash = hash_node::<H>(left.hash::<H>(depth), right.hash::<H>(depth));
            NodeResult::Internal { hash }
        }
    };

    let node = match &result {
        NodeResult::Empty => None,
        NodeResult::Collapsed(cl) => Some(Node::Collapsed(*cl)),
        NodeResult::Internal { hash } => Some(Node::Internal(*hash)),
    };

    (result, node)
}

fn record_change(changes: &mut SmtNodeChanges, subtree_key: BranchKey, existing: Option<Node>, new_node: Option<Node>) {
    if existing != new_node {
        changes.insert(subtree_key, new_node);
    }
}

fn expand_singleton(existing: Option<Node>, updates: SortedLeafUpdatesRef) -> (Option<Node>, SortedLeafUpdates) {
    match existing {
        Some(Node::Collapsed(cl)) => match updates.binary_search_by_key(&cl.lane_key) {
            Err(at) => {
                let mut expanded = Vec::with_capacity(updates.len() + 1);
                expanded.extend_from_slice(&updates.as_slice()[..at]);
                expanded.push(LeafUpdate { key: cl.lane_key, leaf_hash: cl.leaf_hash });
                expanded.extend_from_slice(&updates.as_slice()[at..]);
                (None, SortedLeafUpdates::from_sorted_vec(expanded))
            }
            Ok(_) => (None, SortedLeafUpdates::from_sorted_vec(updates.as_slice().to_vec())),
        },
        other => (other, SortedLeafUpdates::from_sorted_vec(updates.as_slice().to_vec())),
    }
}

/// Recursive top-down subtree computation.
///
/// `updates` must be sorted by key and non-empty.
/// `depth` is the current tree depth (0 = root, 255 = leaf parent).
fn compute_subtree<H: SmtHasher, S: SmtStore>(
    store: &S,
    changes: &mut SmtNodeChanges,
    updates: SortedLeafUpdatesRef<'_>,
    depth: usize,
) -> Result<NodeResult, S::Error> {
    debug_assert!(!updates.is_empty());
    let subtree_key = BranchKey::new(depth as u8, &updates.first().unwrap().key);

    let existing = read_node::<S>(store, changes, &subtree_key)?;

    if let Some(u) = updates.single()
        && existing.is_none()
    {
        if u.leaf_hash == kaspa_hashes::ZERO_HASH {
            return Ok(NodeResult::Empty);
        }
        let cl = CollapsedLeaf { lane_key: u.key, leaf_hash: u.leaf_hash };
        record_change(changes, subtree_key, existing, Some(Node::Collapsed(cl)));
        return Ok(NodeResult::Collapsed(cl));
    }

    if let Some(u) = updates.single()
        && let Some(Node::Collapsed(existing_cl)) = existing
        && u.key == existing_cl.lane_key
    {
        let new_node = if u.leaf_hash == kaspa_hashes::ZERO_HASH {
            None
        } else {
            Some(Node::Collapsed(CollapsedLeaf { lane_key: u.key, leaf_hash: u.leaf_hash }))
        };
        record_change(changes, subtree_key, existing, new_node);
        return Ok(leaf_result(Some(u)));
    }

    let (existing_for_write, updates) = expand_singleton(existing, updates);

    // Leaf-parent level: resolve directly from updates, no child nodes.
    // This early return guards `child_branch_key` and `read_sibling_result`
    // below from being called at depth 255 (which would overflow depth+1).
    if depth == DEPTH - 1 {
        debug_assert!(updates.len() <= 2);
        let left_result = leaf_result(updates.first_with_bit(depth, false));
        let right_result = leaf_result(updates.first_with_bit(depth, true));
        let (result, new_node) = merged_node::<H>(&left_result, &right_result, DEPTH - 1);
        record_change(changes, subtree_key, existing_for_write, new_node);
        return Ok(result);
    }

    let (left_updates, right_updates) = updates.partition_by_bit(depth);

    let left_result = if left_updates.is_empty() {
        read_sibling_result::<S>(store, changes, &subtree_key, false, depth)?
    } else {
        compute_subtree::<H, S>(store, changes, left_updates, depth + 1)?
    };

    let right_result = if right_updates.is_empty() {
        read_sibling_result::<S>(store, changes, &subtree_key, true, depth)?
    } else {
        compute_subtree::<H, S>(store, changes, right_updates, depth + 1)?
    };

    let (result, new_node) = merged_node::<H>(&left_result, &right_result, depth);

    // SLO promotion: when one child becomes Empty after this block's updates
    // and the other holds a single `Collapsed` leaf, `merged_node` promotes
    // that leaf upward — the parent (this depth) will hold the `Collapsed`,
    // and the surviving leaf's old position at depth+1 must be invalidated.
    //
    // The stale entry at depth+1 comes from one of:
    //   - `read_sibling_result` (no recursive write happened), so the prior
    //     block's `Collapsed` for this lane is still the canonical newest at
    //     (depth+1, child_key) in the store.
    //   - `compute_subtree(child)` recursion which would have written
    //     `Collapsed` at depth+1 via `record_change`.
    //
    // Either way, leaving the depth+1 entry intact creates a zombie: the
    // Collapsed at the parent depth shadows it for as long as that parent
    // stays a `Collapsed`, but the moment a future block re-splits this
    // subtree the read walk descends past the parent (now `Internal`) into
    // the child position and resurrects the duplicate.
    //
    // Force-emit a `None` at the originating child so any future descent
    // through here sees an empty subtree below the new parent Collapsed.
    if depth < DEPTH - 1
        && let NodeResult::Collapsed(cl) = result
    {
        let goes_right = bit_at(&cl.lane_key, depth);
        let child_key = child_branch_key(&subtree_key, goes_right, depth);
        // Direct insert (not record_change) — we want this tombstone
        // even if the child position currently holds the same Collapsed
        // (in which case `record_change`'s `existing == new_node` skip
        // would suppress the write, leaving the stale entry alive).
        changes.insert(child_key, None);
    }

    record_change(changes, subtree_key, existing_for_write, new_node);
    Ok(result)
}

/// Read an existing sibling node directly.
///
/// Called when one side of a branch has no updates. Reads the sibling
/// node by its own key (1 read) instead of extracting from the parent.
fn read_sibling_result<S: SmtStore>(
    store: &S,
    changes: &SmtNodeChanges,
    parent_key: &BranchKey,
    sibling_is_right: bool,
    depth: usize,
) -> Result<NodeResult, S::Error> {
    let sibling_key = child_branch_key(parent_key, sibling_is_right, depth);
    match read_node::<S>(store, changes, &sibling_key)? {
        None => Ok(NodeResult::Empty),
        Some(Node::Collapsed(cl)) => Ok(NodeResult::Collapsed(cl)),
        Some(Node::Internal(hash)) => Ok(NodeResult::Internal { hash }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::proof::SmtProofError;
    use alloc::vec;
    use kaspa_hashes::{HasherBase, SeqCommitActiveNode, ZERO_HASH};
    use rand::{Rng, SeedableRng, rngs::StdRng};

    type TestHasher = SeqCommitActiveNode;
    type Smt = SparseMerkleTree<TestHasher>;

    // ---- Helpers ----

    fn updates(entries: impl IntoIterator<Item = (Hash, Hash)>) -> SortedLeafUpdates {
        SortedLeafUpdates::from_unsorted(entries.into_iter().map(|(key, leaf_hash)| LeafUpdate { key, leaf_hash }))
    }

    fn test_key(seed: &[u8]) -> Hash {
        let mut h = TestHasher::default();
        h.update(b"test_key:");
        h.update(seed);
        h.finalize()
    }

    fn test_leaf(seed: &[u8]) -> Hash {
        let mut h = TestHasher::default();
        h.update(b"test_leaf:");
        h.update(seed);
        h.finalize()
    }

    fn key_from_bytes(bytes: [u8; 32]) -> Hash {
        Hash::from_bytes(bytes)
    }

    fn assert_inclusion(tree: &Smt, key: &Hash, leaf: Hash) {
        let root = tree.root();
        let proof = tree.prove(key).unwrap();
        assert!(proof.verify::<TestHasher>(key, Some(leaf), root).unwrap(), "inclusion proof failed for key {key}");
        assert_eq!(proof.compute_root::<TestHasher>(key, Some(leaf)).unwrap(), root, "compute_root mismatch for key {key}");
    }

    fn assert_non_inclusion(tree: &Smt, key: &Hash) {
        let root = tree.root();
        let proof = tree.prove(key).unwrap();
        assert!(proof.verify::<TestHasher>(key, None, root).unwrap(), "non-inclusion proof failed for key {key}");
    }

    // ========================================================================
    // compute_root_update tests
    // ========================================================================

    #[test]
    fn test_compute_root_update_empty() {
        let store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (root, changes) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([])).unwrap();
        assert_eq!(root, empty_root);
        assert!(changes.is_empty());
    }

    /// Helper: build SLO store from changes
    fn apply_changes(store: &mut BTreeSmtStore, changes: &SmtNodeChanges) {
        for (bk, node) in changes {
            store.insert_node(*bk, *node);
        }
    }

    #[test]
    fn test_compute_root_update_batch_matches_incremental() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        // Batch insert
        let store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (batch_root, _) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([(k1, l1), (k2, l2)])).unwrap();

        // Incremental: insert k1 then k2
        let mut store2 = BTreeSmtStore::new();
        let (root1, changes1) = compute_root_update::<TestHasher, _>(&store2, empty_root, updates([(k1, l1)])).unwrap();
        apply_changes(&mut store2, &changes1);
        let (root2, _) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k2, l2)])).unwrap();

        assert_eq!(batch_root, root2);
        assert_ne!(batch_root, empty_root);
    }

    #[test]
    fn test_compute_root_update_incremental() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        // Insert k1, persist to store
        let mut store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (root1, changes1) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([(k1, l1)])).unwrap();
        apply_changes(&mut store, &changes1);

        // Add k2 incrementally
        let (root2, changes2) = compute_root_update::<TestHasher, _>(&store, root1, updates([(k2, l2)])).unwrap();

        assert_ne!(root2, root1);
        // SLO: changes should be compact (collapsed nodes + internal at divergence)
        assert!(!changes2.is_empty());
    }

    #[test]
    fn test_compute_root_update_unchanged_no_propagation() {
        let k1 = test_key(b"1");
        let l1 = test_leaf(b"a");

        // Insert k1 via SLO
        let mut store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (root, changes) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([(k1, l1)])).unwrap();
        apply_changes(&mut store, &changes);

        // "Update" k1 with same value — no changes
        let (new_root, new_changes) = compute_root_update::<TestHasher, _>(&store, root, updates([(k1, l1)])).unwrap();

        assert_eq!(new_root, root, "same leaf value should produce same root");
        assert!(new_changes.is_empty(), "no nodes should change when leaf value is identical");
    }

    #[test]
    fn test_compute_root_update_only_changed_branches() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");
        let l1_new = test_leaf(b"a_new");

        // Insert k1 and k2
        let mut store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (root, changes) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([(k1, l1), (k2, l2)])).unwrap();
        apply_changes(&mut store, &changes);

        // Update only k1
        let (new_root, _new_changes) = compute_root_update::<TestHasher, _>(&store, root, updates([(k1, l1_new)])).unwrap();

        assert_ne!(new_root, root);
        // Verify: batch from scratch matches
        let store3 = BTreeSmtStore::new();
        let (expected, _) = compute_root_update::<TestHasher, _>(&store3, empty_root, updates([(k1, l1_new), (k2, l2)])).unwrap();
        assert_eq!(new_root, expected);
    }

    #[test]
    fn test_compute_root_update_expire_leaf() {
        let k1 = test_key(b"1");
        let l1 = test_leaf(b"a");

        // Insert k1 via SLO
        let mut store = BTreeSmtStore::new();
        let empty_root = TestHasher::empty_root();
        let (root, changes) = compute_root_update::<TestHasher, _>(&store, empty_root, updates([(k1, l1)])).unwrap();
        apply_changes(&mut store, &changes);

        // Expire k1
        let (new_root, _) = compute_root_update::<TestHasher, _>(&store, root, updates([(k1, ZERO_HASH)])).unwrap();

        assert_eq!(new_root, empty_root);
    }

    // ========================================================================
    // 1. Empty tree tests
    // ========================================================================

    #[test]
    fn test_empty_root() {
        let tree = Smt::new();
        let expected = TestHasher::empty_root();
        assert_eq!(tree.root(), expected);
        assert_ne!(tree.root(), ZERO_HASH, "empty root should not be ZERO_HASH");
    }

    #[test]
    fn test_empty_tree_properties() {
        let tree = Smt::new();
        assert_eq!(tree.len(), 0);
        assert!(tree.is_empty());
    }

    #[test]
    fn test_empty_tree_get_returns_none() {
        let tree = Smt::new();
        let key = test_key(b"any");
        assert_eq!(tree.get(&key), None);
        assert!(!tree.contains_key(&key));
    }

    #[test]
    fn test_empty_tree_remove_returns_none() {
        let mut tree = Smt::new();
        let key = test_key(b"any");
        assert_eq!(tree.remove(&key), None);
        assert_eq!(tree.root(), TestHasher::empty_root());
    }

    #[test]
    fn test_empty_tree_non_inclusion_proof() {
        let tree = Smt::new();
        let key = test_key(b"absent");
        assert_non_inclusion(&tree, &key);
    }

    #[test]
    fn test_empty_tree_proof_all_siblings_empty() {
        let tree = Smt::new();
        let key = test_key(b"x");
        let proof = tree.prove(&key).unwrap();
        assert_eq!(proof.non_empty_count(), 0);
        assert_eq!(proof.empty_count(), DEPTH);
        assert_eq!(proof.bitmap, [0xFF; 32]);
    }

    // ========================================================================
    // 2. Single element tests
    // ========================================================================

    #[test]
    fn test_single_insert_changes_root() {
        let mut tree = Smt::new();
        let empty_root = tree.root();
        tree.insert(test_key(b"k"), test_leaf(b"v"));
        assert_ne!(tree.root(), empty_root);
    }

    #[test]
    fn test_single_get() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        assert_eq!(tree.get(&key), Some(leaf));
        assert!(tree.contains_key(&key));
        assert_eq!(tree.len(), 1);
        assert!(!tree.is_empty());
    }

    #[test]
    fn test_single_inclusion_proof() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        assert_inclusion(&tree, &key, leaf);
    }

    #[test]
    fn test_single_non_inclusion_for_other_key() {
        let mut tree = Smt::new();
        tree.insert(test_key(b"present"), test_leaf(b"v"));
        let absent = test_key(b"absent");
        assert_non_inclusion(&tree, &absent);
    }

    #[test]
    fn test_single_delete_restores_empty() {
        let mut tree = Smt::new();
        let empty_root = tree.root();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"v"));
        assert_ne!(tree.root(), empty_root);
        tree.remove(&key);
        assert_eq!(tree.root(), empty_root);
        assert!(tree.is_empty());
    }

    #[test]
    fn test_single_insert_delete_reinsert() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        let root_after_insert = tree.root();
        tree.remove(&key);
        tree.insert(key, leaf);
        assert_eq!(tree.root(), root_after_insert);
    }

    #[test]
    fn test_single_update_changes_root() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"v1"));
        let root1 = tree.root();
        tree.insert(key, test_leaf(b"v2"));
        let root2 = tree.root();
        assert_ne!(root1, root2);
        assert_eq!(tree.len(), 1);
    }

    #[test]
    fn test_insert_zero_hash_is_remove() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"v"));
        assert_eq!(tree.len(), 1);
        tree.insert(key, ZERO_HASH);
        assert_eq!(tree.len(), 0);
        assert!(tree.is_empty());
        assert_eq!(tree.root(), TestHasher::empty_root());
    }

    // ========================================================================
    // 3. Multi-element tests
    // ========================================================================

    #[test]
    fn test_two_elements_both_retrievable() {
        let mut tree = Smt::new();
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");
        tree.insert(k1, l1);
        tree.insert(k2, l2);
        assert_eq!(tree.get(&k1), Some(l1));
        assert_eq!(tree.get(&k2), Some(l2));
        assert_eq!(tree.len(), 2);
    }

    #[test]
    fn test_two_elements_both_proofs_verify() {
        let mut tree = Smt::new();
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");
        tree.insert(k1, l1);
        tree.insert(k2, l2);
        assert_inclusion(&tree, &k1, l1);
        assert_inclusion(&tree, &k2, l2);
    }

    #[test]
    fn test_three_elements_all_proofs_verify() {
        let mut tree = Smt::new();
        let keys: Vec<Hash> = (0..3).map(|i| test_key(&[i])).collect();
        let leaves: Vec<Hash> = (0..3).map(|i| test_leaf(&[i])).collect();
        for (&k, &l) in keys.iter().zip(&leaves) {
            tree.insert(k, l);
        }
        for (&k, &l) in keys.iter().zip(&leaves) {
            assert_inclusion(&tree, &k, l);
        }
    }

    #[test]
    fn test_ten_elements_all_proofs_verify() {
        let mut tree = Smt::new();
        let entries: Vec<(Hash, Hash)> = (0u32..10).map(|i| (test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()))).collect();
        for &(k, l) in &entries {
            tree.insert(k, l);
        }
        for &(k, l) in &entries {
            assert_inclusion(&tree, &k, l);
        }
    }

    #[test]
    fn test_root_changes_with_each_insert() {
        let mut tree = Smt::new();
        let mut prev_root = tree.root();
        for i in 0u32..5 {
            tree.insert(test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()));
            let new_root = tree.root();
            assert_ne!(new_root, prev_root, "root didn't change after insert {i}");
            prev_root = new_root;
        }
    }

    #[test]
    fn test_different_values_different_roots() {
        let key = test_key(b"k");
        let mut tree1 = Smt::new();
        tree1.insert(key, test_leaf(b"v1"));
        let mut tree2 = Smt::new();
        tree2.insert(key, test_leaf(b"v2"));
        assert_ne!(tree1.root(), tree2.root());
    }

    #[test]
    fn test_different_keys_different_roots() {
        let leaf = test_leaf(b"same_leaf");
        let mut tree1 = Smt::new();
        tree1.insert(test_key(b"k1"), leaf);
        let mut tree2 = Smt::new();
        tree2.insert(test_key(b"k2"), leaf);
        assert_ne!(tree1.root(), tree2.root());
    }

    // ========================================================================
    // 4. Delete semantics
    // ========================================================================

    #[test]
    fn test_delete_returns_value() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        assert_eq!(tree.remove(&key), Some(leaf));
    }

    #[test]
    fn test_delete_nonexistent_noop() {
        let mut tree = Smt::new();
        tree.insert(test_key(b"present"), test_leaf(b"v"));
        let root_before = tree.root();
        assert_eq!(tree.remove(&test_key(b"absent")), None);
        assert_eq!(tree.root(), root_before);
    }

    #[test]
    fn test_delete_restores_previous_root() {
        let mut tree = Smt::new();
        let ka = test_key(b"a");
        let kb = test_key(b"b");
        tree.insert(ka, test_leaf(b"la"));
        let root_a_only = tree.root();
        tree.insert(kb, test_leaf(b"lb"));
        assert_ne!(tree.root(), root_a_only);
        tree.remove(&kb);
        assert_eq!(tree.root(), root_a_only);
    }

    #[test]
    fn test_delete_all_returns_to_empty() {
        let mut tree = Smt::new();
        let empty_root = tree.root();
        let keys: Vec<Hash> = (0u32..10).map(|i| test_key(&i.to_le_bytes())).collect();
        for (i, &k) in keys.iter().enumerate() {
            tree.insert(k, test_leaf(&(i as u32).to_le_bytes()));
        }
        assert_ne!(tree.root(), empty_root);
        for k in &keys {
            tree.remove(k);
        }
        assert_eq!(tree.root(), empty_root);
        assert!(tree.is_empty());
    }

    #[test]
    fn test_delete_middle_element() {
        let mut tree = Smt::new();
        let ka = test_key(b"a");
        let kb = test_key(b"b");
        let kc = test_key(b"c");
        let la = test_leaf(b"la");
        let lc = test_leaf(b"lc");
        tree.insert(ka, la);
        tree.insert(kb, test_leaf(b"lb"));
        tree.insert(kc, lc);
        tree.remove(&kb);
        assert_eq!(tree.len(), 2);
        assert_inclusion(&tree, &ka, la);
        assert_inclusion(&tree, &kc, lc);
        assert_non_inclusion(&tree, &kb);
    }

    #[test]
    fn test_non_inclusion_after_delete() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"v"));
        tree.remove(&key);
        assert_non_inclusion(&tree, &key);
    }

    // ========================================================================
    // 5. Determinism / order independence
    // ========================================================================

    #[test]
    fn test_insertion_order_independence() {
        let entries: Vec<(Hash, Hash)> = (0u32..20).map(|i| (test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()))).collect();

        let mut tree1 = Smt::new();
        for &(k, l) in &entries {
            tree1.insert(k, l);
        }

        let mut tree2 = Smt::new();
        for &(k, l) in entries.iter().rev() {
            tree2.insert(k, l);
        }

        assert_eq!(tree1.root(), tree2.root());
    }

    #[test]
    fn test_reconstruction_determinism() {
        let mut tree1 = Smt::new();
        let mut tree2 = Smt::new();
        for i in 0u32..10 {
            let k = test_key(&i.to_le_bytes());
            let l = test_leaf(&i.to_le_bytes());
            tree1.insert(k, l);
            tree2.insert(k, l);
        }
        assert_eq!(tree1.root(), tree2.root());
    }

    #[test]
    fn test_root_idempotent() {
        let mut tree = Smt::new();
        for i in 0u32..5 {
            tree.insert(test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()));
        }
        let r1 = tree.root();
        let r2 = tree.root();
        let r3 = tree.root();
        assert_eq!(r1, r2);
        assert_eq!(r2, r3);
    }

    #[test]
    fn test_insert_remove_insert_same_as_insert() {
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");

        let mut tree1 = Smt::new();
        tree1.insert(key, leaf);

        let mut tree2 = Smt::new();
        tree2.insert(key, leaf);
        tree2.remove(&key);
        tree2.insert(key, leaf);

        assert_eq!(tree1.root(), tree2.root());
    }

    // ========================================================================
    // 6. Inclusion proof tests
    // ========================================================================

    #[test]
    fn test_proof_for_every_element() {
        let mut tree = Smt::new();
        let entries: Vec<(Hash, Hash)> = (0u32..20).map(|i| (test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()))).collect();
        for &(k, l) in &entries {
            tree.insert(k, l);
        }
        for &(k, l) in &entries {
            assert_inclusion(&tree, &k, l);
        }
    }

    #[test]
    fn test_proof_after_update() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"v1"));
        let new_leaf = test_leaf(b"v2");
        tree.insert(key, new_leaf);
        assert_inclusion(&tree, &key, new_leaf);
    }

    #[test]
    fn test_proof_compute_root_matches_tree_root() {
        let mut tree = Smt::new();
        let entries: Vec<(Hash, Hash)> = (0u32..5).map(|i| (test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()))).collect();
        for &(k, l) in &entries {
            tree.insert(k, l);
        }
        let root = tree.root();
        for &(k, l) in &entries {
            let proof = tree.prove(&k).unwrap();
            assert_eq!(proof.compute_root::<TestHasher>(&k, Some(l)).unwrap(), root);
        }
    }

    #[test]
    fn test_inclusion_and_non_inclusion_coexist() {
        let mut tree = Smt::new();
        let present: Vec<(Hash, Hash)> = (0u32..5).map(|i| (test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()))).collect();
        let absent: Vec<Hash> = (100u32..105).map(|i| test_key(&i.to_le_bytes())).collect();
        for &(k, l) in &present {
            tree.insert(k, l);
        }
        for &(k, l) in &present {
            assert_inclusion(&tree, &k, l);
        }
        for k in &absent {
            assert_non_inclusion(&tree, k);
        }
    }

    #[test]
    fn test_proof_non_empty_count() {
        let mut tree = Smt::new();
        let k = test_key(b"solo");
        tree.insert(k, test_leaf(b"v"));
        let proof = tree.prove(&k).unwrap();
        assert_eq!(proof.non_empty_count(), 0);
        assert_eq!(proof.empty_count(), DEPTH);

        tree.insert(test_key(b"other"), test_leaf(b"w"));
        let proof = tree.prove(&k).unwrap();
        assert_eq!(proof.non_empty_count(), 1);
    }

    // ========================================================================
    // 7. Non-inclusion proof tests
    // ========================================================================

    #[test]
    fn test_non_inclusion_empty_tree() {
        let tree = Smt::new();
        assert_non_inclusion(&tree, &test_key(b"anything"));
    }

    #[test]
    fn test_non_inclusion_single_element_tree() {
        let mut tree = Smt::new();
        tree.insert(test_key(b"present"), test_leaf(b"v"));
        assert_non_inclusion(&tree, &test_key(b"absent"));
    }

    #[test]
    fn test_non_inclusion_multi_element_tree() {
        let mut tree = Smt::new();
        for i in 0u32..10 {
            tree.insert(test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()));
        }
        for i in 100u32..110 {
            assert_non_inclusion(&tree, &test_key(&i.to_le_bytes()));
        }
    }

    #[test]
    fn test_non_inclusion_after_deletion() {
        let mut tree = Smt::new();
        let key = test_key(b"will_delete");
        tree.insert(key, test_leaf(b"v"));
        tree.insert(test_key(b"stays"), test_leaf(b"w"));
        tree.remove(&key);
        assert_non_inclusion(&tree, &key);
    }

    #[test]
    fn test_non_inclusion_proof_is_different_from_inclusion() {
        let mut tree = Smt::new();
        let present_key = test_key(b"present");
        let present_leaf = test_leaf(b"v");
        let absent_key = test_key(b"absent");
        tree.insert(present_key, present_leaf);

        let root = tree.root();
        let inclusion_proof = tree.prove(&present_key).unwrap();
        let non_inclusion_proof = tree.prove(&absent_key).unwrap();

        assert!(inclusion_proof.verify::<TestHasher>(&present_key, Some(present_leaf), root).unwrap());
        assert!(non_inclusion_proof.verify::<TestHasher>(&absent_key, None, root).unwrap());
    }

    // ========================================================================
    // 8. Proof rejection tests
    // ========================================================================

    #[test]
    fn test_reject_wrong_leaf_hash() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, test_leaf(b"correct"));
        let root = tree.root();
        let proof = tree.prove(&key).unwrap();
        let wrong_leaf = test_leaf(b"wrong");
        assert!(!proof.verify::<TestHasher>(&key, Some(wrong_leaf), root).unwrap());
    }

    #[test]
    fn test_reject_wrong_root() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        let proof = tree.prove(&key).unwrap();
        let wrong_root = test_leaf(b"fake_root");
        assert!(!proof.verify::<TestHasher>(&key, Some(leaf), wrong_root).unwrap());
    }

    #[test]
    fn test_reject_wrong_key() {
        let mut tree = Smt::new();
        let key = test_key(b"correct_key");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        let root = tree.root();
        let proof = tree.prove(&key).unwrap();
        let wrong_key = test_key(b"wrong_key");
        assert!(!proof.verify::<TestHasher>(&wrong_key, Some(leaf), root).unwrap());
    }

    #[test]
    fn test_reject_tampered_sibling() {
        let mut tree = Smt::new();
        let k1 = test_key(b"k1");
        let k2 = test_key(b"k2");
        tree.insert(k1, test_leaf(b"v1"));
        tree.insert(k2, test_leaf(b"v2"));
        let root = tree.root();
        let mut proof = tree.prove(&k1).unwrap();

        assert!(!proof.siblings.is_empty(), "need at least one sibling to tamper");
        let mut tampered = proof.siblings[0].as_bytes();
        tampered[0] ^= 0xFF;
        proof.siblings[0] = Hash::from_bytes(tampered);

        assert!(!proof.verify::<TestHasher>(&k1, Some(test_leaf(b"v1")), root).unwrap());
    }

    #[test]
    fn test_reject_inclusion_as_non_inclusion() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        let leaf = test_leaf(b"v");
        tree.insert(key, leaf);
        let root = tree.root();
        let proof = tree.prove(&key).unwrap();
        assert!(!proof.verify::<TestHasher>(&key, None, root).unwrap());
    }

    #[test]
    fn test_reject_non_inclusion_as_inclusion() {
        let mut tree = Smt::new();
        tree.insert(test_key(b"other"), test_leaf(b"w"));
        let absent = test_key(b"absent");
        let root = tree.root();
        let proof = tree.prove(&absent).unwrap();
        let fake_leaf = test_leaf(b"fake");
        assert!(!proof.verify::<TestHasher>(&absent, Some(fake_leaf), root).unwrap());
    }

    // ========================================================================
    // 9. Boundary / edge cases
    // ========================================================================

    #[test]
    fn test_max_depth_divergence() {
        let bytes1 = [0u8; 32];
        let mut bytes2 = [0u8; 32];
        bytes2[31] = 0x01;
        let k1 = key_from_bytes(bytes1);
        let k2 = key_from_bytes(bytes2);

        assert!(!bit_at(&k1, 255));
        assert!(bit_at(&k2, 255));
        for d in 0..255 {
            assert_eq!(bit_at(&k1, d), bit_at(&k2, d), "keys should agree at depth {d}");
        }

        let l1 = test_leaf(b"left");
        let l2 = test_leaf(b"right");
        let mut tree = Smt::new();
        tree.insert(k1, l1);
        tree.insert(k2, l2);

        assert_inclusion(&tree, &k1, l1);
        assert_inclusion(&tree, &k2, l2);

        let proof1 = tree.prove(&k1).unwrap();
        assert_eq!(proof1.non_empty_count(), 1);
    }

    #[test]
    fn test_root_level_divergence() {
        let k1 = key_from_bytes([0x00; 32]);
        let mut bytes2 = [0u8; 32];
        bytes2[0] = 0x80;
        let k2 = key_from_bytes(bytes2);

        assert!(!bit_at(&k1, 0));
        assert!(bit_at(&k2, 0));

        let l1 = test_leaf(b"left");
        let l2 = test_leaf(b"right");
        let mut tree = Smt::new();
        tree.insert(k1, l1);
        tree.insert(k2, l2);

        assert_inclusion(&tree, &k1, l1);
        assert_inclusion(&tree, &k2, l2);

        let proof1 = tree.prove(&k1).unwrap();
        assert_eq!(proof1.non_empty_count(), 1);
    }

    #[test]
    fn test_shared_long_prefix() {
        let bytes1 = [0u8; 32];
        let mut bytes2 = [0u8; 32];
        bytes2[200 / 8] |= 1 << 7;

        let k1 = key_from_bytes(bytes1);
        let k2 = key_from_bytes(bytes2);

        for d in 0..200 {
            assert_eq!(bit_at(&k1, d), bit_at(&k2, d), "should agree at depth {d}");
        }
        assert_ne!(bit_at(&k1, 200), bit_at(&k2, 200));

        let mut tree = Smt::new();
        tree.insert(k1, test_leaf(b"v1"));
        tree.insert(k2, test_leaf(b"v2"));

        assert_inclusion(&tree, &k1, test_leaf(b"v1"));
        assert_inclusion(&tree, &k2, test_leaf(b"v2"));
    }

    #[test]
    fn test_zero_key_and_max_key() {
        let zero_key = key_from_bytes([0x00; 32]);
        let max_key = key_from_bytes([0xFF; 32]);
        let mut tree = Smt::new();
        tree.insert(zero_key, test_leaf(b"zero"));
        tree.insert(max_key, test_leaf(b"max"));

        assert_inclusion(&tree, &zero_key, test_leaf(b"zero"));
        assert_inclusion(&tree, &max_key, test_leaf(b"max"));
    }

    #[test]
    fn test_many_keys_same_first_byte() {
        let mut tree = Smt::new();
        let mut entries = Vec::new();
        for i in 0u32..20 {
            let mut bytes = [0u8; 32];
            bytes[0] = 0xAA;
            bytes[1..5].copy_from_slice(&i.to_le_bytes());
            let key = key_from_bytes(bytes);
            let leaf = test_leaf(&i.to_le_bytes());
            tree.insert(key, leaf);
            entries.push((key, leaf));
        }
        for &(k, l) in &entries {
            assert_inclusion(&tree, &k, l);
        }
    }

    #[test]
    fn test_alternating_bit_patterns() {
        let k1 = key_from_bytes([0xAA; 32]);
        let k2 = key_from_bytes([0x55; 32]);
        let mut tree = Smt::new();
        tree.insert(k1, test_leaf(b"aa"));
        tree.insert(k2, test_leaf(b"55"));
        assert_inclusion(&tree, &k1, test_leaf(b"aa"));
        assert_inclusion(&tree, &k2, test_leaf(b"55"));
    }

    // ========================================================================
    // 10. Stress tests
    // ========================================================================

    #[test]
    fn test_100_random_all_proofs_verify() {
        let mut rng = StdRng::seed_from_u64(42);
        let mut tree = Smt::new();
        let mut entries = Vec::new();

        for _ in 0..100 {
            let key = Hash::from_bytes(rng.r#gen());
            let leaf = Hash::from_bytes(rng.r#gen());
            tree.insert(key, leaf);
            entries.push((key, leaf));
        }

        let root = tree.root();
        for &(k, l) in &entries {
            let proof = tree.prove(&k).unwrap();
            assert!(proof.verify::<TestHasher>(&k, Some(l), root).unwrap(), "inclusion proof failed");
        }
    }

    #[test]
    fn test_100_random_non_inclusion() {
        let mut rng = StdRng::seed_from_u64(123);
        let mut tree = Smt::new();

        for _ in 0..100 {
            tree.insert(Hash::from_bytes(rng.r#gen()), Hash::from_bytes(rng.r#gen()));
        }

        let root = tree.root();

        let mut rng2 = StdRng::seed_from_u64(456);
        for _ in 0..100 {
            let absent_key = Hash::from_bytes(rng2.r#gen());
            if tree.contains_key(&absent_key) {
                continue;
            }
            let proof = tree.prove(&absent_key).unwrap();
            assert!(proof.verify::<TestHasher>(&absent_key, None, root).unwrap(), "non-inclusion proof failed");
        }
    }

    #[test]
    fn test_random_insert_delete_cycle() {
        let mut rng = StdRng::seed_from_u64(999);
        let mut tree = Smt::new();
        let mut live_keys: Vec<(Hash, Hash)> = Vec::new();

        for i in 0..200 {
            if i % 3 == 2 && !live_keys.is_empty() {
                let idx = rng.gen_range(0..live_keys.len());
                let (key, _) = live_keys.swap_remove(idx);
                tree.remove(&key);
            } else {
                let key = Hash::from_bytes(rng.r#gen());
                let leaf = Hash::from_bytes(rng.r#gen());
                tree.insert(key, leaf);
                live_keys.push((key, leaf));
            }
        }

        let root = tree.root();
        for &(k, l) in &live_keys {
            let proof = tree.prove(&k).unwrap();
            assert!(proof.verify::<TestHasher>(&k, Some(l), root).unwrap(), "live key proof failed");
        }
    }

    #[test]
    fn test_200_elements_order_independence() {
        let mut rng1 = StdRng::seed_from_u64(777);
        let entries: Vec<(Hash, Hash)> = (0..200).map(|_| (Hash::from_bytes(rng1.r#gen()), Hash::from_bytes(rng1.r#gen()))).collect();

        let mut tree1 = Smt::new();
        for &(k, l) in &entries {
            tree1.insert(k, l);
        }

        let mut tree2 = Smt::new();
        for &(k, l) in entries.iter().rev() {
            tree2.insert(k, l);
        }

        let mut tree3 = Smt::new();
        let n = entries.len();
        for i in 0..n {
            let &(k, l) = &entries[(i + 73) % n];
            tree3.insert(k, l);
        }

        assert_eq!(tree1.root(), tree2.root(), "forward vs reverse");
        assert_eq!(tree1.root(), tree3.root(), "forward vs shuffled");
    }

    // ========================================================================
    // 11. Security tests
    // ========================================================================

    #[test]
    fn test_empty_hash_not_valid_leaf() {
        let mut tree = Smt::new();
        let key = test_key(b"k");
        tree.insert(key, ZERO_HASH);
        assert!(tree.is_empty());
        assert_eq!(tree.get(&key), None);
        assert_eq!(tree.root(), TestHasher::empty_root());
    }

    #[test]
    fn test_proof_for_zero_key() {
        let mut tree = Smt::new();
        let zero_key = Hash::from_bytes([0u8; 32]);
        let leaf = test_leaf(b"zero_key_leaf");
        tree.insert(zero_key, leaf);
        assert_inclusion(&tree, &zero_key, leaf);
    }

    #[test]
    fn test_proof_for_max_key() {
        let mut tree = Smt::new();
        let max_key = Hash::from_bytes([0xFF; 32]);
        let leaf = test_leaf(b"max_key_leaf");
        tree.insert(max_key, leaf);
        assert_inclusion(&tree, &max_key, leaf);
    }

    // ========================================================================
    // 12. Golden value test
    // ========================================================================

    #[test]
    fn test_empty_root_golden_value() {
        let root = TestHasher::empty_root();
        let root_hex = std::format!("{root}");
        let root2 = TestHasher::empty_root();
        assert_eq!(std::format!("{root2}"), root_hex);
    }

    // ========================================================================
    // 13. Proof structure tests
    // ========================================================================

    #[test]
    fn test_proof_sibling_count_bounds() {
        let mut tree = Smt::new();
        let mut keys = Vec::new();
        for i in 0u32..50 {
            let k = test_key(&i.to_le_bytes());
            tree.insert(k, test_leaf(&i.to_le_bytes()));
            keys.push(k);
        }
        for k in &keys {
            let proof = tree.prove(k).unwrap();
            assert!(proof.non_empty_count() <= DEPTH);
            assert!(proof.non_empty_count() <= 50);
            assert_eq!(proof.non_empty_count() + proof.empty_count(), DEPTH);
        }
    }

    #[test]
    fn test_proof_bitmap_consistency() {
        let mut tree = Smt::new();
        for i in 0u32..10 {
            tree.insert(test_key(&i.to_le_bytes()), test_leaf(&i.to_le_bytes()));
        }
        let proof = tree.prove(&test_key(&0u32.to_le_bytes())).unwrap();

        let bitmap_empty_count: usize = proof.bitmap.iter().map(|b| b.count_ones() as usize).sum();
        assert_eq!(bitmap_empty_count, proof.empty_count());
        assert_eq!(DEPTH - bitmap_empty_count, proof.non_empty_count());
        assert_eq!(proof.siblings.len(), proof.non_empty_count());
    }

    // ========================================================================
    // 14. Proof error tests
    // ========================================================================

    #[test]
    fn test_malformed_proof_too_many_siblings() {
        let proof = OwnedSmtProof { bitmap: [0xFF; 32], siblings: Vec::from([ZERO_HASH]), terminal: ProofTerminal::Full };
        let key = test_key(b"k");
        let err = proof.compute_root::<TestHasher>(&key, None).unwrap_err();
        assert_eq!(err, SmtProofError::SiblingCountMismatch { expected: 0, actual: 1 });
    }

    #[test]
    fn test_malformed_proof_too_few_siblings() {
        let proof = OwnedSmtProof { bitmap: [0x00; 32], siblings: Vec::new(), terminal: ProofTerminal::Full };
        let key = test_key(b"k");
        let err = proof.compute_root::<TestHasher>(&key, None).unwrap_err();
        assert_eq!(err, SmtProofError::SiblingCountMismatch { expected: 256, actual: 0 });
    }

    // ========================================================================
    // SLO (Suffix-Only Leaf) top-down algorithm tests
    // ========================================================================

    #[test]
    fn test_slo_single_leaf_collapsed() {
        let k1 = test_key(b"1");
        let l1 = test_leaf(b"a");

        let store = BTreeSmtStore::new();
        let (root, changes) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1)])).unwrap();

        // Should produce a single Collapsed entry at the root level (depth 0)
        assert_eq!(changes.len(), 1, "single leaf should produce one collapsed node");
        let (&bk, &nk) = changes.iter().next().unwrap();
        assert_eq!(bk.depth, 0);
        assert!(matches!(nk, Some(Node::Collapsed(cl)) if cl.lane_key == k1 && cl.leaf_hash == l1));

        // Root should not be the empty root
        assert_ne!(root, TestHasher::empty_root());
    }

    #[test]
    fn test_slo_two_leaves_internal() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        let store = BTreeSmtStore::new();
        let (root, changes) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();

        assert_ne!(root, TestHasher::empty_root());

        // There should be collapsed nodes for each leaf and internal nodes above
        let collapsed_count = changes.values().filter(|n| matches!(n, Some(Node::Collapsed(_)))).count();
        let internal_count = changes.values().filter(|n| matches!(n, Some(Node::Internal(_)))).count();
        assert_eq!(collapsed_count, 2, "two leaves should produce two collapsed nodes");
        assert!(internal_count >= 1, "at least one internal node above the divergence point");
    }

    #[test]
    fn test_slo_expire_sole_leaf() {
        let k1 = test_key(b"1");
        let l1 = test_leaf(b"a");

        // Insert one leaf
        let store = BTreeSmtStore::new();
        let (root1, changes1) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1)])).unwrap();
        assert_ne!(root1, TestHasher::empty_root());

        // Apply changes to store
        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Expire the leaf
        let (root2, _changes2) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k1, ZERO_HASH)])).unwrap();
        assert_eq!(root2, TestHasher::empty_root(), "expiring sole leaf should return to empty root");
    }

    #[test]
    fn test_slo_expire_one_of_two() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        // Insert two leaves
        let store = BTreeSmtStore::new();
        let (root1, changes1) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();

        // Apply to store
        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Expire k1 — k2 should collapse upward
        let (root2, changes2) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k1, ZERO_HASH)])).unwrap();

        // After expiring one of two, we should be back to a single-leaf tree
        // The remaining leaf should be represented as a single collapsed node at root
        let collapsed_count = changes2.values().filter(|n| matches!(n, Some(Node::Collapsed(_)))).count();
        assert!(collapsed_count >= 1, "surviving leaf should collapse upward");

        // Root should match inserting just k2 from scratch
        let store3 = BTreeSmtStore::new();
        let (root_k2_only, _) = compute_root_update::<TestHasher, _>(&store3, TestHasher::empty_root(), updates([(k2, l2)])).unwrap();
        assert_eq!(root2, root_k2_only, "expiring k1 should produce same root as only inserting k2");
    }

    #[test]
    fn test_slo_expand_collapsed() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        // Insert one leaf (collapsed)
        let store = BTreeSmtStore::new();
        let (root1, changes1) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1)])).unwrap();

        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Insert second leaf — should expand the collapsed node
        let (root2, changes2) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k2, l2)])).unwrap();

        // Should have two collapsed nodes and at least one internal
        let collapsed_count = changes2.values().filter(|n| matches!(n, Some(Node::Collapsed(_)))).count();
        assert!(collapsed_count >= 1, "expansion should produce collapsed nodes");

        // Root should match inserting both from scratch
        let store3 = BTreeSmtStore::new();
        let (root_both, _) =
            compute_root_update::<TestHasher, _>(&store3, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();
        assert_eq!(root2, root_both, "incremental expand should match batch insert");
    }

    #[test]
    fn test_slo_same_key_update() {
        let k1 = test_key(b"1");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");

        // Insert k1 with l1
        let store = BTreeSmtStore::new();
        let (root1, changes1) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1)])).unwrap();

        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Update k1 with l2 (same key, different value — no expansion)
        let (root2, changes2) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k1, l2)])).unwrap();

        assert_ne!(root2, root1, "updating leaf value should change root");

        // Should still be a single collapsed node
        let collapsed_count = changes2.values().filter(|n| matches!(n, Some(Node::Collapsed(_)))).count();
        assert_eq!(collapsed_count, 1, "same-key update should remain collapsed");

        // Match inserting k1 with l2 from scratch
        let store3 = BTreeSmtStore::new();
        let (root_scratch, _) = compute_root_update::<TestHasher, _>(&store3, TestHasher::empty_root(), updates([(k1, l2)])).unwrap();
        assert_eq!(root2, root_scratch);
    }

    #[test]
    fn test_slo_batch_mixed_insert_expire() {
        let k1 = test_key(b"1");
        let k2 = test_key(b"2");
        let k3 = test_key(b"3");
        let l1 = test_leaf(b"a");
        let l2 = test_leaf(b"b");
        let l3 = test_leaf(b"c");

        // Insert k1, k2
        let store = BTreeSmtStore::new();
        let (root1, changes1) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();

        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Batch: expire k1, insert k3
        let (root2, _changes2) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k1, ZERO_HASH), (k3, l3)])).unwrap();

        // Should match inserting k2, k3 from scratch
        let store3 = BTreeSmtStore::new();
        let (root_expected, _) =
            compute_root_update::<TestHasher, _>(&store3, TestHasher::empty_root(), updates([(k2, l2), (k3, l3)])).unwrap();
        assert_eq!(root2, root_expected);
    }

    #[test]
    fn test_slo_deep_shared_prefix() {
        // Create two keys that share a long prefix and diverge late
        let mut bytes1 = [0u8; 32];
        let mut bytes2 = [0u8; 32];
        // Same first 31 bytes, differ only in last byte
        bytes1[31] = 0b00000010; // bit 254 = 1
        bytes2[31] = 0b00000001; // bit 255 = 1
        let k1 = key_from_bytes(bytes1);
        let k2 = key_from_bytes(bytes2);
        let l1 = test_leaf(b"deep1");
        let l2 = test_leaf(b"deep2");

        let store = BTreeSmtStore::new();
        let (root, changes) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();

        // The two keys diverge very late (near leaf level), so we should have
        // internal nodes from the divergence point to the root, but collapsed below
        assert_ne!(root, TestHasher::empty_root());
        assert!(changes.len() >= 3, "deep prefix sharing: 2 collapsed + internal at divergence");
    }

    #[test]
    fn test_slo_collapse_propagates_levels() {
        // Insert 3 keys, expire 2 of them, verify the surviving one collapses all the way up
        let k1 = test_key(b"c1");
        let k2 = test_key(b"c2");
        let k3 = test_key(b"c3");
        let l1 = test_leaf(b"v1");
        let l2 = test_leaf(b"v2");
        let l3 = test_leaf(b"v3");

        let store = BTreeSmtStore::new();
        let (root1, changes1) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2), (k3, l3)])).unwrap();

        let mut store2 = BTreeSmtStore::new();
        for (bk, nk) in &changes1 {
            store2.insert_node(*bk, *nk);
        }

        // Expire k1 and k2
        let (root2, _) = compute_root_update::<TestHasher, _>(&store2, root1, updates([(k1, ZERO_HASH), (k2, ZERO_HASH)])).unwrap();

        // Should match k3-only tree
        let store3 = BTreeSmtStore::new();
        let (root_k3_only, _) = compute_root_update::<TestHasher, _>(&store3, TestHasher::empty_root(), updates([(k3, l3)])).unwrap();
        assert_eq!(root2, root_k3_only, "after expiring 2 of 3, surviving leaf should collapse to root");
    }

    #[test]
    fn test_slo_stress_random() {
        let mut rng = StdRng::seed_from_u64(42);
        let n = 100;

        // Generate random keys and leaf hashes
        let mut keys = Vec::new();
        let mut leaves = Vec::new();
        for _ in 0..n {
            let mut key_bytes = [0u8; 32];
            rng.fill(&mut key_bytes);
            keys.push(Hash::from_bytes(key_bytes));
            let mut leaf_bytes = [0u8; 32];
            rng.fill(&mut leaf_bytes);
            leaves.push(Hash::from_bytes(leaf_bytes));
        }

        // Insert all at once (batch)
        let all_updates: Vec<(Hash, Hash)> = keys.iter().copied().zip(leaves.iter().copied()).collect();
        let store = BTreeSmtStore::new();
        let (root_batch, _) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates(all_updates.clone())).unwrap();

        // Insert one by one (incremental)
        let mut store_incr = BTreeSmtStore::new();
        let mut root_incr = TestHasher::empty_root();
        for &(k, l) in &all_updates {
            let (new_root, changes) = compute_root_update::<TestHasher, _>(&store_incr, root_incr, updates([(k, l)])).unwrap();
            for (bk, nk) in &changes {
                store_incr.insert_node(*bk, *nk);
            }
            root_incr = new_root;
        }

        assert_eq!(root_batch, root_incr, "batch and incremental should produce identical roots");

        // Expire half randomly
        let to_expire: Vec<(Hash, Hash)> = keys[..n / 2].iter().map(|k| (*k, ZERO_HASH)).collect();
        let remaining: Vec<(Hash, Hash)> = keys[n / 2..].iter().copied().zip(leaves[n / 2..].iter().copied()).collect();

        let (root_after_expire, changes_expire) =
            compute_root_update::<TestHasher, _>(&store_incr, root_incr, updates(to_expire)).unwrap();

        // Apply expire changes
        let mut store_remaining = store_incr;
        for (bk, nk) in &changes_expire {
            store_remaining.insert_node(*bk, *nk);
        }

        // Insert remaining from scratch
        let store_fresh = BTreeSmtStore::new();
        let (root_fresh, _) =
            compute_root_update::<TestHasher, _>(&store_fresh, TestHasher::empty_root(), updates(remaining)).unwrap();

        assert_eq!(root_after_expire, root_fresh, "expire half should match inserting only the remaining half");
    }

    // ========================================================================
    // walk_up vs compute_root_update consistency
    // ========================================================================

    /// Single leaf: walk_up (insert) must produce the same root as compute_root_update (SLO).
    #[test]
    fn walk_up_vs_slo_single_leaf() {
        let k = test_key(b"solo");
        let l = test_leaf(b"solo_val");

        let mut tree = Smt::new();
        tree.insert(k, l);

        let store = BTreeSmtStore::new();
        let (slo_root, _) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k, l)])).unwrap();

        assert_eq!(tree.root(), slo_root, "walk_up and SLO must agree on single-leaf root");
    }

    /// Multiple leaves inserted incrementally: walk_up must match incremental SLO.
    #[test]
    fn walk_up_vs_slo_incremental_multi() {
        let keys_and_leaves: Vec<(Hash, Hash)> = (0u8..10).map(|i| (test_key(&[i]), test_leaf(&[i + 100]))).collect();

        // walk_up path
        let mut tree = Smt::new();
        for &(k, l) in &keys_and_leaves {
            tree.insert(k, l);
        }

        // SLO incremental path
        let mut store = BTreeSmtStore::new();
        let mut slo_root = TestHasher::empty_root();
        for &(k, l) in &keys_and_leaves {
            let (new_root, changes) = compute_root_update::<TestHasher, _>(&store, slo_root, updates([(k, l)])).unwrap();
            apply_changes(&mut store, &changes);
            slo_root = new_root;
        }

        assert_eq!(tree.root(), slo_root, "walk_up and incremental SLO must agree");
    }

    /// Batch SLO must match walk_up for the same leaf set.
    #[test]
    fn walk_up_vs_slo_batch() {
        let keys_and_leaves: Vec<(Hash, Hash)> = (0u8..5).map(|i| (test_key(&[i]), test_leaf(&[i + 50]))).collect();

        let mut tree = Smt::new();
        for &(k, l) in &keys_and_leaves {
            tree.insert(k, l);
        }

        let store = BTreeSmtStore::new();
        let (slo_root, _) =
            compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates(keys_and_leaves.clone())).unwrap();

        assert_eq!(tree.root(), slo_root, "walk_up and batch SLO must agree");
    }

    /// walk_up update (overwrite existing leaf) must match SLO incremental update.
    #[test]
    fn walk_up_vs_slo_update_existing() {
        let k1 = test_key(b"upd1");
        let k2 = test_key(b"upd2");
        let l1 = test_leaf(b"v1");
        let l2 = test_leaf(b"v2");
        let l1_new = test_leaf(b"v1_new");

        // walk_up: insert both, then update k1
        let mut tree = Smt::new();
        tree.insert(k1, l1);
        tree.insert(k2, l2);
        tree.insert(k1, l1_new);

        // SLO: same sequence
        let mut store = BTreeSmtStore::new();
        let (r1, c1) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();
        apply_changes(&mut store, &c1);
        let (r2, _) = compute_root_update::<TestHasher, _>(&store, r1, updates([(k1, l1_new)])).unwrap();

        assert_eq!(tree.root(), r2, "walk_up and SLO must agree after update");
    }

    /// walk_up remove must match SLO expire (ZERO_HASH).
    #[test]
    fn walk_up_vs_slo_remove() {
        let k1 = test_key(b"rm1");
        let k2 = test_key(b"rm2");
        let l1 = test_leaf(b"rv1");
        let l2 = test_leaf(b"rv2");

        // walk_up: insert both, then remove k1
        let mut tree = Smt::new();
        tree.insert(k1, l1);
        tree.insert(k2, l2);
        tree.remove(&k1);

        // SLO: same sequence
        let mut store = BTreeSmtStore::new();
        let (r1, c1) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates([(k1, l1), (k2, l2)])).unwrap();
        apply_changes(&mut store, &c1);
        let (r2, _) = compute_root_update::<TestHasher, _>(&store, r1, updates([(k1, ZERO_HASH)])).unwrap();

        assert_eq!(tree.root(), r2, "walk_up remove and SLO expire must agree");
    }

    /// Randomized: N inserts via walk_up must match batch SLO.
    #[test]
    fn walk_up_vs_slo_random() {
        let mut rng = StdRng::seed_from_u64(0xdead_beef);
        for n in [1, 2, 3, 5, 10, 20, 50] {
            let kv: Vec<(Hash, Hash)> = (0..n)
                .map(|_| {
                    let mut kb = [0u8; 32];
                    let mut vb = [0u8; 32];
                    rng.fill(&mut kb);
                    rng.fill(&mut vb);
                    (Hash::from_bytes(kb), Hash::from_bytes(vb))
                })
                .collect();

            let mut tree = Smt::new();
            for &(k, l) in &kv {
                tree.insert(k, l);
            }

            let store = BTreeSmtStore::new();
            let (slo_root, _) = compute_root_update::<TestHasher, _>(&store, TestHasher::empty_root(), updates(kv)).unwrap();

            assert_eq!(tree.root(), slo_root, "walk_up vs batch SLO mismatch for n={n}");
        }
    }

    // ========================================================================
    // SLO-promotion regression: zombie Collapsed at the originating child
    //
    // Scenario:
    //
    //   1. Two leaves K1, K2 share a long prefix and diverge at some depth `d`.
    //      After building, the tree has Internal at depth `d-1` and a
    //      `Collapsed(K1)` / `Collapsed(K2)` at depth `d`.
    //   2. K2 is expired. `merged_node` at depth `d-1` sees
    //      `(Collapsed(K1), Empty)` and promotes the surviving Collapsed
    //      upward — depth `d-1` now holds `Collapsed(K1)`. Without the fix
    //      in `compute_subtree`, depth `d` retains the old `Collapsed(K1)`
    //      value (read by `read_sibling_result` / `compute_subtree(child)`)
    //      — a zombie.
    //   3. A new leaf K3 is inserted whose path shares K1's bits past `d`,
    //      forcing depth `d-1` to split back into `Internal`. The descent
    //      reads depth `d` and resurrects the zombie, producing a wrong tree.
    //
    // The fix emits a `None` tombstone at the originating child position when
    // promotion happens, so the resplit reads `Empty` at the child and the
    // tree converges to what a fresh recompute would produce. These tests
    // pin that property at multiple depths and across multi-step promotions.
    // ========================================================================

    /// Build a 32-byte key with the supplied high-order bit pattern. Bits
    /// past `pattern.len()` are zero. Bit 0 is the MSB of byte 0 (matching
    /// `bit_at`'s convention used by the tree code).
    fn key_with_bits(pattern: &[bool]) -> Hash {
        let mut bytes = [0u8; 32];
        for (i, &b) in pattern.iter().enumerate() {
            if b {
                bytes[i / 8] |= 0x80 >> (i % 8);
            }
        }
        Hash::from_bytes(bytes)
    }

    /// Build the live tree state on `store` after applying a sequence of
    /// `compute_root_update` calls. Returns the final root.
    fn build_state(store: &mut BTreeSmtStore, updates_seq: &[Vec<(Hash, Hash)>]) -> Hash {
        let mut root = TestHasher::empty_root();
        for batch in updates_seq {
            let (new_root, changes) = compute_root_update::<TestHasher, _>(store, root, updates(batch.iter().copied())).unwrap();
            apply_changes(store, &changes);
            root = new_root;
        }
        root
    }

    /// Three keys K1, K2, K3 chosen so that:
    ///   - K1 and K2 share `d_split` bits and diverge at bit `d_split`
    ///   - K1 and K3 share `d_resplit` bits (with `d_resplit > d_split`),
    ///     so a later K3 insert forces a re-split inside the K1 subtree at
    ///     depth `d_resplit` after K2 has been expired.
    ///
    /// Choosing `d_resplit > d_split` is what surfaces the bug: the
    /// post-promotion `Collapsed(K1)` ends up at depth `d_split`, and the
    /// K3 insert descends past that into the depth `d_split + 1..d_resplit`
    /// range — exactly where the zombie lives.
    fn three_keys_for_promote_then_resplit(d_split: usize, d_resplit: usize) -> (Hash, Hash, Hash) {
        assert!(d_split < d_resplit);
        assert!(d_resplit < DEPTH);
        // Common prefix: all zeros. K1 keeps zero bit at d_split.
        let k1_bits = vec![false; d_resplit + 1];
        let mut k2_bits = vec![false; d_resplit + 1];
        let mut k3_bits = vec![false; d_resplit + 1];
        // K1 and K2 diverge at d_split: K1 = 0, K2 = 1.
        k2_bits[d_split] = true;
        // K1 and K3 share through bit d_resplit - 1, diverge at d_resplit.
        // K3 = 1 at d_resplit; K1 = 0 there. Both have 0 at d_split (so K3
        // is in the same subtree as K1, distinct from K2).
        k3_bits[d_resplit] = true;
        (key_with_bits(&k1_bits), key_with_bits(&k2_bits), key_with_bits(&k3_bits))
    }

    /// Property: after `[insert K1+K2; expire K2; insert K3]`, the resulting
    /// root must equal a fresh recompute of `[K1, K3]`. This catches the
    /// zombie-Collapsed bug because the bug produces a tree containing
    /// `K1` *twice* — once at the live depth and once at the stale child
    /// depth — so the root diverges from the fresh recompute.
    fn run_promote_then_resplit(d_split: usize, d_resplit: usize) {
        let (k1, k2, k3) = three_keys_for_promote_then_resplit(d_split, d_resplit);
        let l1 = test_leaf(b"v1");
        let l2 = test_leaf(b"v2");
        let l3 = test_leaf(b"v3");

        let mut store = BTreeSmtStore::new();
        let root = build_state(&mut store, &[vec![(k1, l1), (k2, l2)], vec![(k2, ZERO_HASH)], vec![(k3, l3)]]);

        let mut fresh_store = BTreeSmtStore::new();
        let fresh_root = build_state(&mut fresh_store, &[vec![(k1, l1), (k3, l3)]]);

        assert_eq!(
            root, fresh_root,
            "promote-then-resplit at d_split={d_split} d_resplit={d_resplit} produced a zombie-Collapsed: stateful root != fresh-recompute root"
        );
    }

    /// Parametrized sweep of the promote-then-resplit scenario at various
    /// `(d_split, d_resplit)` pairs. Each case exercises a distinct
    /// structural shape that the fix's `child_branch_key` arithmetic and
    /// `bit_at` indexing must handle correctly:
    ///   - shallowest (0, 1): bit 0 / bit 1 — root-adjacent split.
    ///   - byte boundary (7, 8) and (7, 16): the originating child sits
    ///     across a byte boundary; verifies the byte/bit math doesn't
    ///     misindex when bit `d_split + 1` is in a different byte.
    ///   - intermediate Internals (9, 13): the zombie sits four levels
    ///     below the surviving Collapsed and is only reached after a deep
    ///     descent past Internals at depths 9..12.
    ///   - mid-tree sweep (`d_split` in {1..30} × `delta` in {1, 2, 4, 8,
    ///     16}): broad coverage to catch any off-by-one across byte
    ///     boundaries.
    ///   - near leaf depth (DEPTH-5..DEPTH-2): exercises the
    ///     `if depth < DEPTH - 1` guard at the bottom of the tree.
    #[test]
    fn slo_promote_then_resplit_parametrized() {
        // Hand-picked structural cases.
        for &(d_split, d_resplit) in &[(0usize, 1usize), (7, 8), (7, 16), (9, 13), (DEPTH - 5, DEPTH - 3), (DEPTH - 4, DEPTH - 2)] {
            run_promote_then_resplit(d_split, d_resplit);
        }
        // Mid-tree sweep across byte boundaries.
        for d_split in [1, 2, 3, 4, 5, 8, 16, 24, 30] {
            for delta in [1, 2, 4, 8, 16] {
                let d_resplit = d_split + delta;
                if d_resplit < DEPTH {
                    run_promote_then_resplit(d_split, d_resplit);
                }
            }
        }
    }

    /// A chain of promotions: build a tree with several siblings on the
    /// same path, then expire them one by one, each expiration triggering
    /// a single-step promotion. The remaining lane should ultimately match
    /// a fresh recompute, no matter how many intermediate zombies the
    /// pre-fix code would have left behind.
    #[test]
    fn slo_chain_of_promotions_collapses_to_fresh_recompute() {
        // Construct 5 leaves sharing the prefix `0000…` but each diverges
        // at a different depth from the previous one, building a "spine"
        // of nested Internals. After expiring 4 of them, only K0 remains.
        let depths = [3usize, 7, 12, 18, 25];
        let k0 = key_with_bits(&[false; 32]); // all-zero high bits
        let mut other_keys: Vec<Hash> = Vec::new();
        for &d in &depths {
            let mut bits = vec![false; d + 1];
            bits[d] = true;
            other_keys.push(key_with_bits(&bits));
        }
        let leaves: Vec<Hash> = (0..=other_keys.len()).map(|i| test_leaf(&[i as u8])).collect();

        let mut initial = vec![(k0, leaves[0])];
        for (i, k) in other_keys.iter().enumerate() {
            initial.push((*k, leaves[i + 1]));
        }

        let mut steps: Vec<Vec<(Hash, Hash)>> = vec![initial];
        for k in &other_keys {
            steps.push(vec![(*k, ZERO_HASH)]);
        }
        // Final touch: re-insert one diverging key to force a fresh resplit
        // through the spine of zombies the pre-fix code would have left.
        let resplit_depth = 30;
        let mut split_bits = vec![false; resplit_depth + 1];
        split_bits[resplit_depth] = true;
        let k_split = key_with_bits(&split_bits);
        let l_split = test_leaf(b"split");
        steps.push(vec![(k_split, l_split)]);

        let mut store = BTreeSmtStore::new();
        let stateful_root = build_state(&mut store, &steps);

        let mut fresh_store = BTreeSmtStore::new();
        let fresh_root = build_state(&mut fresh_store, &[vec![(k0, leaves[0]), (k_split, l_split)]]);

        assert_eq!(stateful_root, fresh_root, "chain of promotions diverged from fresh recompute");
    }

    /// Promotion via batch (insert + expire in the same `compute_root_update`
    /// call) — same `merged_node` code path is taken, so the tombstone
    /// emit must fire here too. This catches the case where the fix only
    /// works for sequential-step promotion but fails inside batch operations.
    #[test]
    fn slo_promote_in_single_batch_then_resplit() {
        let (k1, k2, k3) = three_keys_for_promote_then_resplit(10, 14);
        let l1 = test_leaf(b"v1");
        let l2 = test_leaf(b"v2");
        let l3 = test_leaf(b"v3");

        let mut store = BTreeSmtStore::new();
        let root = build_state(&mut store, &[vec![(k1, l1), (k2, l2)], vec![(k2, ZERO_HASH), (k3, l3)]]);

        let mut fresh_store = BTreeSmtStore::new();
        let fresh_root = build_state(&mut fresh_store, &[vec![(k1, l1), (k3, l3)]]);
        assert_eq!(root, fresh_root, "batch (expire+insert) did not tombstone the zombie before the resplit");
    }

    /// Surgical post-state assertion: after `insert K1+K2; expire K2`,
    /// reading the live tree along K1's path with `compute_root_update`'s
    /// own reader semantics must yield the same tree as a fresh recompute
    /// of just `K1`. This pins the exact change `record_change(child_key,
    /// None)` is meant to achieve at the storage level.
    #[test]
    fn slo_promotion_leaves_no_collapsed_at_originating_child() {
        let (k1, k2, _k3) = three_keys_for_promote_then_resplit(12, 20);
        let l1 = test_leaf(b"v1");
        let l2 = test_leaf(b"v2");

        let mut store = BTreeSmtStore::new();
        let root_after_expire = build_state(&mut store, &[vec![(k1, l1), (k2, l2)], vec![(k2, ZERO_HASH)]]);

        let mut fresh = BTreeSmtStore::new();
        let fresh_root = build_state(&mut fresh, &[vec![(k1, l1)]]);
        assert_eq!(root_after_expire, fresh_root);

        // For every depth from 0 to DEPTH-1 along K1's path, the live read
        // (the same BTreeSmtStore::get_node interface compute_subtree uses)
        // must match the fresh-recompute store's read. If the zombie
        // Collapsed(K1) survives anywhere, this comparison fires at the
        // depth past the live position.
        let mut current_key = Hash::from_bytes([0u8; 32]);
        for d in 0..DEPTH as u8 {
            let bk = BranchKey::new(d, &current_key);
            let live = store.get_node(&bk).unwrap();
            let fresh_node = fresh.get_node(&bk).unwrap();
            assert_eq!(live, fresh_node, "zombie at depth={d}: live={live:?} fresh={fresh_node:?}");
            // Stop descending once we've reached / passed the K1 leaf — the
            // collapsed at the live position carries the lane and downstream
            // nodes don't matter once both stores agree at the carrier.
            if matches!(live, Some(Node::Collapsed(_))) {
                break;
            }
            if bit_at(&k1, d as usize) {
                let mut k = current_key.as_bytes();
                k[d as usize / 8] |= 0x80 >> (d as usize % 8);
                current_key = Hash::from_bytes(k);
            }
        }
    }

    /// Randomized fuzz: many random-depth promotion-then-resplit trios.
    /// If any zombie escapes the fix the stateful-vs-fresh comparison
    /// fires for that seed. Seed is fixed for deterministic CI.
    #[test]
    fn slo_promote_then_resplit_random_fuzz() {
        let mut rng = StdRng::seed_from_u64(0xC0_11_AB_5E);
        for _ in 0..100 {
            let d_split = rng.gen_range(0..(DEPTH - 8));
            let d_resplit = d_split + 1 + rng.gen_range(0..7.min(DEPTH - 1 - d_split));
            run_promote_then_resplit(d_split, d_resplit);
        }
    }
}
